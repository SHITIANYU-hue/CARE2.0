"""Offline review drafts only: no API client, network, credentials, or replay."""
from __future__ import annotations

import copy
import hashlib
import itertools
import json
import math
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
RECORD = ROOT / "experiments/care_replay/skill_banks/frozen_records/bh_semantic_headline_20260721.json"
STATUS = "REVIEW_DRAFT_NOT_APPROVED_NOT_FROZEN_NO_API_CALL"
HISTORICAL_SYSTEM = (
    "You are a scientific optimization expert. Return one valid JSON object only. "
    "Never invent field names or values outside the supplied catalog."
)
SYSTEM = (
    "You design optimization policies over a finite candidate pool. "
    "Return one valid JSON object only. Never invent field names or values "
    "outside the supplied catalog."
)
RULE_COUNTS = (2, 1, 1, 1, 1)
PARAMETER_RANGES = {
    "ridge": (0.05, 20), "prior_scale": (0, 1.5),
    "semantic_mass_start": (0, 0.85), "semantic_mass_end": (0, 0.85),
    "ucb_weight": (0, 1), "gp_beta_start": (0.2, 4),
    "gp_beta_end": (0.2, 4), "gp_xi": (0, 0.2), "confidence": (0.05, 1),
}


def numeric_leaves(value):
    if isinstance(value, dict):
        return [n for child in value.values() for n in numeric_leaves(child)]
    if isinstance(value, list):
        return [n for child in value for n in numeric_leaves(child)]
    return [value] if type(value) in (int, float) else []


def map_tree(value, aliases):
    if isinstance(value, dict):
        return {aliases.get(key, key): map_tree(child, aliases) for key, child in value.items()}
    if isinstance(value, list):
        return [map_tree(child, aliases) for child in value]
    if isinstance(value, str):
        return aliases.get(value, value)
    return value


def make_aliases(payload):
    fields = set(payload["target"]["public_semantic_fields"])
    values = {v for counts in payload["target"]["public_semantic_fields"].values() for v in counts}
    evidence = payload["source_transfer_evidence"]
    for row in evidence["roles"] + evidence["shared_value_priors"]:
        fields.update((row["source_field"], row["target_field"]))
        if "value" in row:
            values.add(row["value"])
    fields.add(payload["target"]["hidden_target"])
    task_names = {payload["target"]["dataset"], payload["target"]["title"], evidence["source_dataset"]}
    sections = {
        "fields": {s: f"F{i:02d}" for i, s in enumerate(sorted(fields), 1)},
        "values": {s: f"V{i:02d}" for i, s in enumerate(sorted(values), 1)},
        "tasks": {s: f"T{i:02d}" for i, s in enumerate(sorted(task_names), 1)},
        "objectives": {"maximize_yield": "maximize_O01"},
    }
    combined = {k: v for section in sections.values() for k, v in section.items()}
    assert len(set(combined.values())) == len(combined)
    return sections, combined


def common_payload(historical):
    """Common text changes applied to both arms BEFORE the label intervention."""
    payload = copy.deepcopy(historical)
    payload["task"] = (
        "Design a diverse library of executable optimization skills for finite-pool search. "
        "Each skill defines interpretable rule features plus a conservative Bayesian linear "
        "surrogate blended with target-only GP-UCB and GP-EI anchors."
    )
    payload["design_requirements"] = [
        "Return exactly five executable skills in the skills array.",
        "Use only exact field/value pairs listed in target.public_semantic_fields.",
        "Each conditions object maps actual catalog field names directly to legal values for those fields; placeholder keys are not valid output.",
        "The first skill must have exactly two rules. Each of the second through fifth skills must have exactly one rule. This matches the number of rules in each historical executable library slot.",
        "Each rule is a conjunction of one or more legal catalog conditions, with no field repeated within one rule. This retains the existing executor's condition grammar.",
        "Keep all execution parameters within allowed_ranges and supply every parameter shown in output_contract.",
        "Include at least one conservative low-semantic-mass skill.",
        "Include at least one proposal grounded in the supplied source evidence and one independent proposal.",
        "Include a counter-hypothesis that reverses or downweights an uncertain source relation.",
        "Prefer interpretable relationships supported by the supplied representation over arbitrary coverage rules.",
        "Use positive weights for conditions expected to improve the target objective and negative weights for risks.",
        "Do not claim access to target outcomes and do not output candidate identifiers.",
        "Use unique lowercase ASCII skill_id values; rules within each skill must have unique lowercase ASCII rule_id values. IDs may contain digits and underscores.",
        "Supply exactly the keys shown in output_contract. Keep each rationale at most 400 characters and each hypothesis at most 800 characters, the executor's existing text limits.",
        "Return one JSON object only. All numeric values must be finite JSON numbers, not strings or booleans.",
        "The output is checked before any evaluation; invalid output will not be silently shortened, repaired, clamped, or expanded.",
    ]
    payload["source_transfer_evidence"]["boundary"] = (
        "Only source outcomes and public source/target fields are summarized. "
        "No target outcomes are present."
    )
    example = payload["output_contract"]["skills"][0]
    example["skill_id"] = "unique_skill_identifier"
    example["rules"][0]["rule_id"] = "unique_rule_identifier"
    example["rules"][0]["conditions"] = {"catalog_field": "legal_value_for_that_field"}
    example["rules"][0]["rationale"] = "short rationale using the supplied representation"
    example["hypothesis"] = "what this skill transfers and when it may fail"
    assert "care_knowledge_context" not in payload
    return payload


def messages(payload):
    return [
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    ]


def strict_validate_library(payload, catalog):
    """Proposed fail-closed validator, not an approved generation policy."""
    errors = []
    skills = payload.get("skills") if isinstance(payload, dict) else None
    if not isinstance(skills, list) or len(skills) != 5:
        return ["Expected exactly five skills; nothing is trimmed or filled."]
    if set(payload) != {"skills"}:
        errors.append("Only the skills top-level key is permitted.")
    seen = set()
    for i, skill in enumerate(skills):
        path = f"skills[{i}]"
        if not isinstance(skill, dict):
            errors.append(path + ": not an object")
            continue
        if set(skill) != {"skill_id", "rules", "hypothesis", *PARAMETER_RANGES}:
            errors.append(path + ": unexpected or missing skill keys")
        identifier = skill.get("skill_id")
        if not isinstance(identifier, str) or re.fullmatch("[a-z0-9_]{1,64}", identifier) is None:
            errors.append(path + ": invalid skill_id")
        if isinstance(identifier, str) and identifier in seen:
            errors.append(path + ": repeated skill_id")
        if isinstance(identifier, str):
            seen.add(identifier)
        for name, (low, high) in PARAMETER_RANGES.items():
            value = skill.get(name)
            if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
                errors.append(path + ": invalid " + name)
        if not isinstance(skill.get("hypothesis"), str) or len(skill["hypothesis"]) > 800:
            errors.append(path + ": hypothesis must be a string no longer than 800 characters")
        rules = skill.get("rules")
        if not isinstance(rules, list) or len(rules) != RULE_COUNTS[i]:
            errors.append(path + ": expected exactly " + str(RULE_COUNTS[i]) + " rules in this slot")
            continue
        rule_ids = set()
        for j, rule in enumerate(rules):
            rpath = f"{path}.rules[{j}]"
            if not isinstance(rule, dict):
                errors.append(rpath + ": not an object")
                continue
            if set(rule) != {"rule_id", "conditions", "weight", "rationale"}:
                errors.append(rpath + ": unexpected or missing rule keys")
            rule_id = rule.get("rule_id")
            if not isinstance(rule_id, str) or re.fullmatch("[a-z0-9_]{1,64}", rule_id) is None:
                errors.append(rpath + ": invalid rule_id")
            if isinstance(rule_id, str):
                if rule_id in rule_ids:
                    errors.append(rpath + ": repeated rule_id")
                rule_ids.add(rule_id)
            conditions = rule.get("conditions")
            if not isinstance(conditions, dict) or not conditions:
                errors.append(rpath + ": nonempty conditions object required")
            else:
                for field, value in conditions.items():
                    if field not in catalog or not isinstance(value, str) or value not in catalog[field]:
                        errors.append(rpath + ": unknown field/value")
            weight = rule.get("weight")
            if type(weight) not in (int, float) or not math.isfinite(weight) or not -1 <= weight <= 1:
                errors.append(rpath + ": invalid weight")
            if not isinstance(rule.get("rationale"), str) or len(rule["rationale"]) > 400:
                errors.append(rpath + ": rationale must be a string no longer than 400 characters")
    return errors


def parse_strict_json(text):
    def reject_constant(value):
        raise ValueError("Nonfinite JSON constant: " + value)

    def unique_object(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate JSON key: " + key)
            result[key] = value
        return result

    return json.loads(text, parse_constant=reject_constant, object_pairs_hook=unique_object)


def decode_conditions_only(payload, reverse_fields, reverse_values):
    """Decode executable conditions; prose/IDs are metadata and not reinterpreted."""
    decoded = copy.deepcopy(payload)
    for skill in decoded["skills"]:
        for rule in skill["rules"]:
            rule["conditions"] = {
                reverse_fields[field]: reverse_values[value]
                for field, value in rule["conditions"].items()
            }
    return decoded


def self_checks(record, labeled, coded, sections, aliases):
    inverse = {v: k for k, v in aliases.items()}
    assert map_tree(coded, inverse) == labeled
    assert numeric_leaves(record["prompt_payload"]) == numeric_leaves(labeled) == numeric_leaves(coded)
    catalog = labeled["target"]["public_semantic_fields"]
    # Test all 2,592 possible categorical states, without reading any target outcomes.
    fields = list(catalog)
    states = [dict(zip(fields, values)) for values in itertools.product(*(catalog[f] for f in fields))]
    normalized = copy.deepcopy(record["normalized_skills"])
    for skill in normalized:
        for rule in skill["rules"]:
            rule["conditions"] = dict(rule["conditions"])
    original_library = {"skills": normalized}
    assert strict_validate_library(original_library, catalog) == []
    coded_library = copy.deepcopy(original_library)
    mask_comparisons = 0
    for skill in coded_library["skills"]:
        for rule in skill["rules"]:
            original_conditions = rule["conditions"]
            coded_conditions = {aliases[f]: aliases[v] for f, v in original_conditions.items()}
            for state in states:
                coded_state = {aliases[f]: aliases[v] for f, v in state.items()}
                before = all(state[f] == v for f, v in original_conditions.items())
                after = all(coded_state[f] == v for f, v in coded_conditions.items())
                assert before == after
                mask_comparisons += 1
            rule["conditions"] = coded_conditions
    assert strict_validate_library(coded_library, coded["target"]["public_semantic_fields"]) == []
    decoded = decode_conditions_only(
        coded_library, {v: k for k, v in sections["fields"].items()},
        {v: k for k, v in sections["values"].items()},
    )
    assert decoded == original_library
    tamper_results = {}
    for name in ("too_few", "wrong_rule_count", "unknown_field", "nonfinite", "bad_condition",
                 "duplicate_id", "nonstring_id", "extra_field", "overlong_text"):
        bad = copy.deepcopy(original_library)
        if name == "too_few":
            bad["skills"].pop()
        elif name == "wrong_rule_count":
            bad["skills"][0]["rules"].pop()
        elif name == "unknown_field":
            bad["skills"][0]["rules"][0]["conditions"]["unknown_field"] = "bad"
        elif name == "nonfinite":
            bad["skills"][0]["prior_scale"] = float("nan")
        elif name == "bad_condition":
            bad["skills"][0]["rules"][0]["conditions"] = {}
        elif name == "nonstring_id":
            bad["skills"][0]["skill_id"] = []
        elif name == "extra_field":
            bad["skills"][0]["extra"] = "would otherwise be silently discarded"
        elif name == "overlong_text":
            bad["skills"][0]["hypothesis"] = "x" * 801
        else:
            bad["skills"][1]["skill_id"] = bad["skills"][0]["skill_id"]
        assert strict_validate_library(bad, catalog)
        tamper_results[name] = "rejected"
    for invalid_json in ('{"x": 1, "x": 2}', '{"x": NaN}', '```json\n{}\n```'):
        try:
            parse_strict_json(invalid_json)
        except (ValueError, json.JSONDecodeError):
            continue
        raise AssertionError("Invalid JSON accepted")
    wire = json.dumps(messages(coded), ensure_ascii=False).lower()
    forbidden = (
        "buchwald", "hartwig", "dreher", "doyle", "suzuki", "miyaura",
        "ligand", "reagent", "aryl", "additive", "phosph", "amidine",
        "guanidine", "bromide", "chloride", "iodide", "tpsa", "mw_",
        "smiles", "chemical", "chemically", "scientific", "scientist", "yield_value", "maximize_yield",
    )
    leaks = [term for term in forbidden if term in wire]
    assert not leaks, leaks
    return {
        "status": "offline_checks_passed", "model_api_calls": 0,
        "round_trip_exact": True, "all_numeric_leaves_equal": True,
        "numeric_leaf_count": len(numeric_leaves(labeled)),
        "synthetic_categorical_states_checked": len(states),
        "condition_truth_comparisons": mask_comparisons,
        "decoded_historical_library_exact": True,
        "strict_validator_tamper_checks": tamper_results,
        "duplicate_key_nonfinite_json_and_markdown_rejected": True,
        "explicit_label_denylist_hits_in_outbound_messages": leaks,
        "limitation": "Denylist is a practical explicit-label check, not proof of information-theoretic anonymity. Cardinalities, frequencies, source evidence and task structure remain visible.",
    }


def save(name, payload):
    path = HERE / name
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def main():
    record = json.loads(RECORD.read_text(encoding="utf-8"))
    historical_path = "experiments/care_replay/results/2026-07-21-cross-domain-semantic-skills/model_calls/suzuki_to_bh_semantic_record.json"
    historical_blob = subprocess.run(
        ["git", "show", "c1b976ec:" + historical_path], cwd=ROOT, capture_output=True, check=True,
    ).stdout
    assert historical_blob == RECORD.read_bytes()
    historical_source = subprocess.run(
        ["git", "show", "c1b976ec:experiments/care_replay/scripts/generate_llm_semantic_skills.py"],
        cwd=ROOT, capture_output=True, check=True,
    ).stdout.decode("utf-8")
    assert "You are a scientific optimization expert. Return one valid JSON object only." in historical_source
    assert "Never invent field names or values outside the supplied catalog." in historical_source
    labeled = common_payload(record["prompt_payload"])
    sections, aliases = make_aliases(labeled)
    coded = map_tree(labeled, aliases)
    checks = self_checks(record, labeled, coded, sections, aliases)
    save("paired_labeled_messages.draft.json", messages(labeled))
    save("paired_coded_messages.draft.json", messages(coded))
    save("paired_labeled_payload.draft.json", labeled)
    save("paired_coded_payload.draft.json", coded)
    save("paired_alias_map.LOCAL_ONLY.draft.json", {
        "status": STATUS, "never_send_to_model": True, **sections,
        "policy": "Sorted labels for review readability only. Final permutation/randomization policy remains unapproved.",
    })
    save("paired_message_offline_checks.json", checks)
    save("generation_contract_review.json", {
        "status": STATUS,
        "confirmed_by_user": ["OpenRouter provider", "Same model identifier as historical BH: openai/gpt-4o-mini", "Semantic field/category/task anonymization", "Preserve numerical source statistics", "Regenerate both labeled and coded arms"],
        "scientific_differences_requiring_review": [
            "Historical prompt asked for 8 skills with 3-10 rules each; returned 8 skills with 1-2 rules, normalized to 5 executable skills. Draft now requests exactly 5 without silent deletion.",
            "Draft requires exactly [2,1,1,1,1] rules in the five skill slots, matching the retained historical executable library. This is a new paired-generation constraint awaiting confirmation, not a reproduction of the original 3-10-rule text instruction.",
            "Each rule retains the executor's arbitrary nonempty conjunction of legal catalog field/value conditions. Rule slots do not bind the old field names, weight signs, weights or execution parameter values; those remain model choices within the same historical ranges in both arms.",
            "Chemical free-text instructions are neutralized identically in both arms; this is a necessary shared prompt change compared with historical generation.",
            "OpenRouter differs from historical CommonStack; the recorded model alias is unchanged, but exact model snapshot/provider routing equivalence cannot be established from the historical record.",
        ],
        "historical_system_message": HISTORICAL_SYSTEM,
        "shared_neutral_system_message": SYSTEM,
        "proposed_skill_rule_counts_not_yet_approved": list(RULE_COUNTS),
        "shared_parameter_proposal_not_frozen": {
            "model": record["model"], "temperature": record["api_configuration"]["temperature"],
            "response_format": {"type": "json_object"}, "max_tokens": 5000,
            "repetitions_n": None, "dollar_cap": None, "retry_cap": None,
        },
        "proposed_invalid_output_policy_not_approved": {
            "before_any_replay": "Strictly parse and validate the whole library in its own catalog; preserve raw response and usage.",
            "invalid_library": "Stop the paired batch for review; do not silently drop proposals, repair conditions, clamp values, take first five of eight, or automatically resample.",
            "reporting": "Retain invalid attempts and their labels as generation-validity outcomes. Do not silently analyze only successful pairs.",
            "api_transport_failure": "Stop and account for the attempt; any retries must use an explicitly approved resource policy.",
            "after_approval": "If a repair or retry is authorized, define it symmetrically before the next batch and do not inspect held-out results.",
        },
        "knowledge_retrieval": "Disabled by construction: no runtime generator, database access or knowledge card field is used by these drafts.",
        "model_side_files": ["paired_labeled_messages.draft.json", "paired_coded_messages.draft.json"],
        "local_only_files": ["paired_alias_map.LOCAL_ONLY.draft.json", "generation_contract_review.json"],
        "provenance": {
            "historical_git_commit_prefix": "c1b976ec", "record_matches_historical_git_blob_exactly": True,
            "record_sha256": hashlib.sha256(RECORD.read_bytes()).hexdigest(),
            "system_message_source": "Historical generator at the same commit; the record itself did not store the system message.",
        },
    })
    print(json.dumps(checks, ensure_ascii=False))


if __name__ == "__main__":
    main()
