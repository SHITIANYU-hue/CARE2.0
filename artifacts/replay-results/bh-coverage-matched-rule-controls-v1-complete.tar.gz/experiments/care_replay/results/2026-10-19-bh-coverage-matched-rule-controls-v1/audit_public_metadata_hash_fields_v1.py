#!/usr/bin/env python3
"""Independent public-metadata audit of frozen BH coverage-matched draws.

Reads no calibration/held-out metrics and imports no null generator, selector,
or coverage implementation. The dataset adapter loads the local reaction table;
after loading, this audit copies only the manifest catalog's public columns.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from contextlib import contextmanager
from decimal import Decimal, ROUND_FLOOR
import hashlib
import json
from pathlib import Path
import socket
from statistics import mean
import sys


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RUN = ROOT / "experiments/care_replay/results/2026-10-19-bh-coverage-matched-rule-controls-v1"


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def file_digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@contextmanager
def offline_guard():
    original = socket.socket.connect, socket.socket.connect_ex, socket.create_connection

    def reject(*args, **kwargs):
        raise RuntimeError("Network access disabled during the metadata audit")

    socket.socket.connect = socket.socket.connect_ex = socket.create_connection = reject
    try:
        yield
    finally:
        socket.socket.connect, socket.socket.connect_ex, socket.create_connection = original


def executor_inputs(skill):
    value = {key: item for key, item in skill.items()
             if key not in {"skill_id", "hypothesis", "rules"}}
    value["rules"] = [{key: item for key, item in rule.items()
                       if key not in {"rule_id", "rationale"}}
                      for rule in skill["rules"]]
    return value


def audit(manifest, public_rows):
    config = manifest["config"]
    catalog = manifest["public_catalog"]
    types = config["field_types"]
    libraries = manifest["libraries"]
    templates = libraries["llm"]
    count = len(public_rows)
    allowed = int((Decimal("0.005") * count).to_integral_value(rounding=ROUND_FLOOR))
    errors = []

    def check(condition, message):
        if not condition:
            errors.append(message)

    check(config["coverage_matching"]["absolute_fraction_tolerance"] == 0.005,
          "Protocol coverage tolerance is not 0.005")
    check(count == config["expected_candidate_count"] == 3955, "Unexpected BH candidate count")
    check(len(templates) == 5, "LLM library does not contain five skills")
    check([skill["skill_id"] for skill in templates] == config["expected_skill_ids"],
          "LLM template order differs from frozen configuration")
    expected_names = {"llm"} | {f"{family}_{index:03d}" for family in ("r1", "r2")
                                 for index in range(1, 101)}
    check(set(libraries) == expected_names, "Expected one LLM and 100 libraries per random family")
    check(set(types) == set(catalog), "Field types do not cover exactly public catalog fields")
    for field in catalog:
        actual = dict(Counter(row[field].strip() for row in public_rows if row[field].strip()))
        check(actual == catalog[field], f"Public catalog counts differ for {field}")
    for kind in set(types.values()):
        check(len({len(catalog[field]) for field in catalog if types[field] == kind}) == 1,
              f"Unequal value cardinality within field type {kind}")

    # Deliberately evaluate Boolean predicates row by row, independently of the
    # generator's integer-bitset implementation. Cache only identical conditions.
    activation_cache = {}

    def profile(skill):
        vectors = []
        for rule in skill["rules"]:
            conditions = tuple(tuple(pair) for pair in rule["conditions"])
            if conditions not in activation_cache:
                activation_cache[conditions] = bytes(
                    all(row[field] == value for field, value in conditions)
                    for row in public_rows)
            vectors.append(activation_cache[conditions])
        supports = [sum(vector) for vector in vectors]
        joint = Counter(sum(int(active) << index for index, active in enumerate(pattern))
                        for pattern in zip(*vectors))
        activation_inputs = executor_inputs(skill)
        for rule, vector in zip(activation_inputs["rules"], vectors):
            rule["conditions"] = {"ordered_public_activation_sha256": hashlib.sha256(vector).hexdigest()}
        return supports, joint, digest(activation_inputs)

    original_profiles = [profile(skill) for skill in templates]
    original_exact = {digest(executor_inputs(skill)): skill["skill_id"] for skill in templates}
    original_activation = {prof[2]: skill["skill_id"]
                           for skill, prof in zip(templates, original_profiles)}
    families = {}
    combined_exact, combined_activation = [], []
    by_template = defaultdict(lambda: {"support_counts": [], "support_deviations": [],
                                       "joint_deviations": []})
    all_draws = []
    for family in ("llm", "r1", "r2"):
        names = [name for name in sorted(libraries) if name.split("_")[0] == family]
        exacts, activations = [], []
        exact_matches, activation_matches = {}, {}
        exact_by_llm, activation_by_llm = Counter(), Counter()
        rule_occurrences = zero_support = full_support = 0
        for name in names:
            bank = libraries[name]
            check(len(bank) == 5, f"{name}: selection budget differs from five")
            exact_matches[name], activation_matches[name] = [], []
            for index, (skill, template) in enumerate(zip(bank, templates)):
                prefix = f"{name}/{skill['skill_id']}"
                base = {key: value for key, value in template.items()
                        if key not in {"skill_id", "rules", "hypothesis"}}
                params = {key: value for key, value in skill.items()
                          if key not in {"skill_id", "rules", "hypothesis"}}
                check(params == base, f"{prefix}: executor hyperparameters changed")
                check(len(skill["rules"]) == len(template["rules"]), f"{prefix}: rule count changed")
                mapping = {}
                for before, after in zip(template["rules"], skill["rules"]):
                    check(abs(after["weight"]) == abs(before["weight"]), f"{prefix}: weight magnitude changed")
                    check(len(after["conditions"]) == len(before["conditions"]), f"{prefix}: rule arity changed")
                    for (source, _), (target, value) in zip(before["conditions"], after["conditions"]):
                        check(target in catalog and value in catalog.get(target, {}), f"{prefix}: condition outside catalog")
                        check(types.get(source) == types.get(target), f"{prefix}: field type changed")
                        if family in {"llm", "r1"}:
                            check(source == target, f"{prefix}: R1 or LLM field changed")
                        check(source not in mapping or mapping[source] == target,
                              f"{prefix}: skill-wide source field reuse violated")
                        mapping[source] = target
                check(len(set(mapping.values())) == len(mapping), f"{prefix}: field map is not injective")
                supports, joint, activation = profile(skill)
                source_supports, source_joint, _ = original_profiles[index]
                support_deviations = [abs(left - right) for left, right in zip(supports, source_supports)]
                joint_deviation = max(abs(joint.get(cell, 0) - source_joint.get(cell, 0))
                                      for cell in set(joint) | set(source_joint))
                check(max(support_deviations) <= allowed, f"{prefix}: ordered rule coverage mismatch")
                check(joint_deviation <= allowed, f"{prefix}: joint activation histogram mismatch")
                key = (family, template["skill_id"])
                by_template[key]["support_counts"].append(supports)
                by_template[key]["support_deviations"].extend(support_deviations)
                by_template[key]["joint_deviations"].append(joint_deviation)
                all_draws.append({"library": name, "skill_id": skill["skill_id"],
                                  "template_id": template["skill_id"], "rule_support_counts": supports,
                                  "joint_activation_counts": {str(cell): number for cell, number in sorted(joint.items())},
                                  "max_support_count_deviation": max(support_deviations),
                                  "max_joint_count_deviation": joint_deviation})
                exact = digest(executor_inputs(skill))
                exacts.append(exact)
                activations.append(activation)
                if exact in original_exact:
                    matched = original_exact[exact]
                    exact_matches[name].append(matched)
                    exact_by_llm[matched] += 1
                if activation in original_activation:
                    matched = original_activation[activation]
                    activation_matches[name].append(matched)
                    activation_by_llm[matched] += 1
                rule_occurrences += len(supports)
                zero_support += sum(support == 0 for support in supports)
                full_support += sum(support == count for support in supports)
        combined_exact.extend(exacts)
        combined_activation.extend(activations)
        headline = templates[0]["skill_id"]
        families[family] = {
            "library_count": len(names), "sampled_skills": len(exacts),
            "exact_unique_skills": len(set(exacts)), "exact_duplicate_draws": len(exacts) - len(set(exacts)),
            "activation_equivalent_unique_skills": len(set(activations)),
            "activation_equivalent_duplicate_draws": len(activations) - len(set(activations)),
            "exact_llm_matches_by_library": exact_matches,
            "activation_llm_matches_by_library": activation_matches,
            "per_original_llm_exact_draws": {skill["skill_id"]: exact_by_llm[skill["skill_id"]] for skill in templates},
            "per_original_llm_activation_equivalent_draws": {skill["skill_id"]: activation_by_llm[skill["skill_id"]] for skill in templates},
            "libraries_containing_any_llm_exact": sum(bool(matches) for matches in exact_matches.values()),
            "libraries_containing_any_llm_exact_fraction": mean(bool(matches) for matches in exact_matches.values()),
            "libraries_containing_high_mw_headline_exact": sum(headline in matches for matches in exact_matches.values()),
            "libraries_containing_any_llm_activation_equivalent": sum(bool(matches) for matches in activation_matches.values()),
            "libraries_containing_high_mw_headline_activation_equivalent": sum(headline in matches for matches in activation_matches.values()),
            "exact_llm_match_count_histogram": dict(Counter(len(matches) for matches in exact_matches.values())),
            "rule_occurrences": rule_occurrences, "zero_support_rule_occurrences": zero_support,
            "universal_support_rule_occurrences": full_support,
        }
    coverage = {}
    for (family, template_id), values in by_template.items():
        per_rule = []
        for numbers in zip(*values["support_counts"]):
            per_rule.append({"min_count": min(numbers), "mean_count": mean(numbers), "max_count": max(numbers),
                             "min_fraction": min(numbers) / count, "mean_fraction": mean(numbers) / count,
                             "max_fraction": max(numbers) / count})
        coverage.setdefault(family, {})[template_id] = {
            "per_rule_support": per_rule,
            "max_rule_support_count_deviation": max(values["support_deviations"]),
            "max_joint_activation_count_deviation": max(values["joint_deviations"]),
            "max_rule_support_fraction_deviation": max(values["support_deviations"]) / count,
            "max_joint_activation_fraction_deviation": max(values["joint_deviations"]) / count,
        }
    return {
        "audit_id": "bh_coverage_matched_v1_independent_public_metadata_audit", "passed": not errors,
        "errors": errors, "candidate_count": count, "absolute_fraction_tolerance": 0.005,
        "allowed_count_deviation": allowed, "public_fields_read": sorted(catalog),
        "model_api_calls": 0, "metrics_read": False, "independent_algorithm": "Boolean row predicates and Counter joint histogram",
        "family_coverage": coverage, "families": families, "draws": all_draws,
        "combined": {"sampled_skills": len(combined_exact), "exact_unique_skills": len(set(combined_exact)),
                     "activation_equivalent_unique_skills": len(set(combined_activation))},
        "interpretation": "Activation equivalence preserves ordered per-rule activations, signed weights and all executor parameters. It is not inferred from outcome agreement.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, default=DEFAULT_RUN)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    run = args.run_dir.resolve()
    output = args.output or run / "metadata_audit.json"
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite {output}")
    manifest_path = run / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest["config"]["target_dataset"] != "real_buchwald_hartwig":
        raise ValueError("This audit is for the frozen Buchwald-Hartwig pool")
    for relative, expected in manifest["data_sha256"].items():
        if file_digest(ROOT / relative) != expected:
            raise ValueError(f"Data hash mismatch: {relative}")
    with offline_guard():
        sys.path.insert(0, str(ROOT / "experiments/care_replay/scripts"))
        import run_synthetic_suzuki as replay
        adapter = replay.real_buchwald_hartwig_adapter()
        public_rows = [{field: str(candidate.metadata.get(field, ""))
                        for field in manifest["public_catalog"]} for candidate in adapter.candidates]
        del adapter
        report = audit(manifest, public_rows)
    report["manifest_sha256"] = file_digest(manifest_path)
    report["script_sha256"] = file_digest(Path(__file__))
    report["config_canonical_sha256"] = digest(manifest["config"])
    report["manifest_config_file_sha256"] = manifest["config_sha256"]
    report["libraries_sha256"] = digest(manifest["libraries"])
    report["data_sha256"] = manifest["data_sha256"]
    with output.open("x", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
    print(json.dumps({"passed": report["passed"], "errors": report["errors"],
                      "combined": report["combined"], "output": str(output)}, ensure_ascii=False))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
