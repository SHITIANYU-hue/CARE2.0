"""Reconstruct recorded replay metrics; run with --repo and --run absolute paths."""
import argparse
from collections import defaultdict
import csv
import hashlib
import json
import math
from statistics import mean
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--run', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.repo / 'experiments/care_replay/scripts'))
import run_matched_random_rule_controls as runner

load = lambda name: json.loads((args.run / name).read_text(encoding='utf-8'))
manifest = load('manifest.json')
summary = load('summary.json')
lock = load('selection_lock.json')
assert summary['status'] == 'complete'
assert runner.file_digest(args.run / 'selection_lock.json') == summary['selection_lock_sha256']
assert runner.file_digest(args.run / 'manifest.json') == lock['manifest_sha256']
assert runner.file_digest(args.run / 'calibration_metrics.csv') == lock['calibration_metrics_sha256']
for kind in ('source_sha256', 'data_sha256'):
    for name, expected in manifest[kind].items():
        assert runner.file_digest(args.repo / name) == expected, name

with runner.offline_guard():
    adapter = runner.replay.DATASET_BUILDERS[manifest['config']['target_dataset']]()
by_id = {c.candidate_id: c for c in adapter.candidates}
top10 = {c.candidate_id for c in sorted(adapter.candidates,
                                       key=lambda c: c.objective_value, reverse=True)[:10]}
calibration, heldout = runner.validate_config(manifest['config'])
libraries = {name: runner.semantic.normalize_skills({'skills': bank},
              manifest['public_catalog'], 100) for name, bank in manifest['libraries'].items()}
modes = (*runner.BASELINES, *(runner.semantic.skill_mode(s)
                             for bank in libraries.values() for s in bank))
trajectory_count = decision_count = 0
for split, seeds in [('calibration', calibration), ('heldout', heldout)]:
    with (args.run / f'{split}_metrics.csv').open(encoding='utf-8', newline='') as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row['seed'] = int(row['seed'])
    runner.validate_rows(rows, modes, seeds, split)
    traces = defaultdict(list)
    with (args.run / f'{split}_traces.jsonl').open(encoding='utf-8') as handle:
        for line in handle:
            event = json.loads(line)
            traces[(event['mode'], event['seed'])].append(event)
    assert set(traces) == {(mode, seed) for mode in modes for seed in seeds}
    for row in rows:
        events = sorted(traces[(row['mode'], row['seed'])], key=lambda e: e['round_index'])
        assert len(events) == manifest['config']['reveal_rounds']
        initial = manifest['initial_candidates'][str(row['seed'])]
        seen = set(initial)
        best = max(by_id[c].objective_value for c in initial)
        best_trace = []
        for index, event in enumerate(events):
            assert event['round_index'] == index
            assert event['public_observed_count'] == len(seen)
            candidate = event['selected_candidate']
            assert candidate not in seen
            seen.add(candidate)
            value = by_id[candidate].objective_value
            assert math.isclose(event['revealed_value'], value, abs_tol=1e-9)
            best = max(best, value)
            assert math.isclose(event['best_so_far'], best, abs_tol=1e-9)
            best_trace.append(best)
        expected = {'final_best': round(best, 4),
                    'best_so_far_auc': round(mean(best_trace), 4),
                    'top10_hit': int(bool(seen & top10))}
        for key, value in expected.items():
            assert math.isclose(float(row[key]), value, abs_tol=1e-8), (row, key, value)
        trajectory_count += 1
        decision_count += len(events)
    if split == 'calibration':
        selected = runner.freeze_selection(rows, libraries, calibration, manifest['config'])
        assert selected == lock['selections'], 'Selection reconstruction differs'
    else:
        rebuilt = runner.summarize(rows, libraries, lock['selections'], heldout)
        assert rebuilt['libraries'] == summary['libraries']
        assert rebuilt['all_skill_effects'] == summary['all_skill_effects']

assert trajectory_count == manifest['planned_trajectories'] == summary['completed_trajectories']
report = {'status': 'passed', 'trajectories_reconstructed': trajectory_count,
          'decisions_reconstructed': decision_count, 'duplicate_queries': 0,
          'metric_mismatches': 0, 'selection_reconstructed_from_calibration_only': True,
          'source_and_data_hashes_unchanged': True, 'summary_reconstructed': True,
          'boundary': 'This audit checks recorded choices, outcomes, metrics and selection. '
                      'It does not rerun acquisition ranking or establish scientific generalization.'}
runner.save_json(args.run / 'audit_report.json', report)
print(json.dumps(report, indent=2))
