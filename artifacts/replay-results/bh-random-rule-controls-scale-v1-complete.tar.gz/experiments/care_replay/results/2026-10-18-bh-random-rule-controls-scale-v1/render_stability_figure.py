#!/usr/bin/env python3
"""Render the frozen stability.json estimates; never recompute statistics.

Run after analyze_matched_rule_stability.py has written stability.json. The
--input option exists to test the renderer with synthetic fixtures. Default
outputs are stability_figure.png and stability_figure.pdf beside the input.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import MaxNLocator  # noqa: E402


PANELS = (
    ("primary_ungated_auc", "Primary: ungated calibration winners", 0.975, "#245987"),
    ("secondary_deployed_auc", "Secondary: gate-deployed policies", 0.95, "#9B5827"),
)
FAMILIES = ("r1", "r2")


def finite_number(value, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{field} must be a finite number")
    return float(value)


def extract_estimates(payload):
    """Read only saved means/intervals; do not inspect policies or trajectories."""
    estimates = {}
    for endpoint, _title, expected_confidence, _color in PANELS:
        estimates[endpoint] = {}
        for family in FAMILIES:
            saved = payload["families"][family][endpoint]
            interval = saved["interval"]
            confidence = finite_number(interval["confidence_level"], "confidence_level")
            if not math.isclose(confidence, expected_confidence, rel_tol=0, abs_tol=1e-12):
                raise ValueError(f"Unexpected confidence level for {endpoint}: {confidence}")
            mean = finite_number(saved["mean_delta"], "mean_delta")
            lower = finite_number(interval["lower"], "lower")
            upper = finite_number(interval["upper"], "upper")
            if lower > upper:
                raise ValueError("Interval bounds are reversed")
            estimates[endpoint][family] = (mean, lower, upper)
    return estimates


def render(input_path: Path, output_prefix: Path):
    source = input_path.read_bytes()
    payload = json.loads(source)
    estimates = extract_estimates(payload)
    source_hash = hashlib.sha256(source).hexdigest()
    coordinates = [0.0, *(value for panel in estimates.values()
                          for estimate in panel.values() for value in estimate)]
    left, right = min(coordinates), max(coordinates)
    span = max(right - left, 1.0)
    limits = (left - 0.12 * span, right + 0.12 * span)
    style = {
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.labelcolor": "#30343A", "text.color": "#20252B",
        "xtick.color": "#49515A", "ytick.color": "#30343A",
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "savefig.facecolor": "white", "figure.facecolor": "white",
    }
    with plt.rc_context(style):
        figure, axes = plt.subplots(1, 2, figsize=(11.2, 4.5), sharex=True, sharey=True)
        figure.subplots_adjust(left=0.07, right=0.98, top=0.72, bottom=0.30, wspace=0.23)
        figure.suptitle("Frozen LLM vs random-rule libraries", x=0.07, y=0.96,
                        ha="left", fontsize=16, fontweight="bold")
        figure.text(0.07, 0.875, "Conditional on the BH pool, historical LLM library and frozen calibration choices",
                    fontsize=10.5, color="#4C5661")
        for axis, (endpoint, title, _confidence, color) in zip(axes, PANELS):
            axis.set_title(title, loc="left", fontsize=11, fontweight="bold", pad=17)
            axis.axvline(0, color="#656C74", linewidth=1, linestyle=(0, (4, 3)), zorder=1)
            for family, y in zip(FAMILIES, (1, 0)):
                mean, lower, upper = estimates[endpoint][family]
                # A percentile interval need not contain the point estimate;
                # hlines avoids falsely imposing that condition via xerr.
                axis.hlines(y, lower, upper, color=color, linewidth=2.4, zorder=3)
                axis.vlines((lower, upper), y - 0.07, y + 0.07, color=color, linewidth=1.4, zorder=3)
                axis.scatter([mean], [y], color=color, s=52, edgecolor="white", linewidth=0.6, zorder=4)
                axis.text(0.98, y + 0.25, f"{mean:+.3f}  [{lower:+.3f}, {upper:+.3f}]",
                          transform=axis.get_yaxis_transform(), ha="right", va="center",
                          fontsize=9.5, color=color)
            axis.set_yticks([1, 0], ["R1", "R2"])
            axis.tick_params(axis="y", length=0, labelleft=True, pad=9)
            axis.set_ylim(-0.45, 1.55)
            axis.set_xlim(limits)
            axis.xaxis.set_major_locator(MaxNLocator(nbins=5))
            axis.grid(axis="x", color="#E9ECF0", linewidth=0.7)
            axis.set_axisbelow(True)
            for side in ("top", "right", "left"):
                axis.spines[side].set_visible(False)
            axis.spines["bottom"].set_color("#CCD2D8")
        figure.supxlabel("LLM − random-library best-so-far AUC  (yield percentage points)",
                         x=0.525, y=0.19, fontsize=11)
        figure.text(0.07, 0.115,
                    "Primary: 97.5% intervals, Bonferroni for two families (approx. familywise 95%).  "
                    "Secondary: exploratory, unadjusted 95%.", fontsize=8.4, color="#515A63")
        figure.text(0.07, 0.065,
                    "Crossed bootstrap over library draws and shared held-out starts. "
                    "Positive values favour LLM. Estimates and intervals read directly from stability.json.",
                    fontsize=8.4, color="#515A63")
        output_prefix.parent.mkdir(parents=True, exist_ok=True)
        png_path = Path(str(output_prefix) + ".png")
        pdf_path = Path(str(output_prefix) + ".pdf")
        title = "Frozen LLM vs random-rule libraries, conditional on the BH pool"
        provenance = f"Saved statistical estimates only; no reanalysis. Input SHA256: {source_hash}"
        figure.savefig(png_path, dpi=300, metadata={"Title": title, "Description": provenance})
        figure.savefig(pdf_path, metadata={"Title": title, "Subject": provenance,
                                           "Creator": Path(__file__).name})
        plt.close(figure)
    return png_path, pdf_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path(__file__).with_name("stability.json"))
    parser.add_argument("--output-prefix", type=Path)
    args = parser.parse_args()
    output_prefix = args.output_prefix or args.input.with_name("stability_figure")
    png, pdf = render(args.input, output_prefix)
    print(json.dumps({"png": str(png.resolve()), "pdf": str(pdf.resolve())}, indent=2))


if __name__ == "__main__":
    main()
