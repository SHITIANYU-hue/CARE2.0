"""Descriptive rankings of already frozen BH policies; no replay or model calls."""
import argparse
from collections import defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def signature(skill):
    value = {key: val for key, val in skill.items() if key not in ('skill_id', 'hypothesis', 'rules')}
    value['rules'] = [{key: val for key, val in rule.items() if key not in ('rule_id', 'rationale')}
                      for rule in skill['rules']]
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def compare(reference, scores):
    if not scores:
        raise ValueError('Empty control distribution')
    better = sum(score > reference for score in scores)
    tied = sum(score == reference for score in scores)
    worse = len(scores) - better - tied
    return {'control_count': len(scores), 'controls_higher_auc': better,
            'controls_equal_auc': tied, 'controls_lower_auc': worse,
            'llm_inserted_rank_best': better + 1,
            'llm_inserted_rank_worst': better + tied + 1,
            'llm_inserted_rank_denominator': len(scores) + 1,
            'llm_midrank_percentile_vs_controls': 100 * (worse + 0.5 * tied) / len(scores)}


def analyze(run):
    names = ('manifest.json', 'selection_lock.json', 'heldout_metrics.csv', 'audit_report.json')
    integrity = json.loads((run / 'integrity.json').read_text(encoding='utf-8'))
    hashes = {name: sha(run / name) for name in names}
    for name, digest in hashes.items():
        if integrity.get(name) != digest:
            raise ValueError(f'Input integrity mismatch: {name}')
    manifest = json.loads((run / 'manifest.json').read_text(encoding='utf-8'))
    lock = json.loads((run / 'selection_lock.json').read_text(encoding='utf-8'))
    audit = json.loads((run / 'audit_report.json').read_text(encoding='utf-8'))
    if audit['status'] != 'passed' or lock['manifest_sha256'] != hashes['manifest.json']:
        raise ValueError('Run has not passed its independent audit or selection chain changed')
    config = manifest['config']
    seeds = set(range(config['heldout_seed_start'], config['heldout_seed_start'] + config['heldout_seed_count']))
    policies, template_indices = {}, {}
    for bank, skills in manifest['libraries'].items():
        if len(skills) != len(manifest['libraries']['llm']):
            raise ValueError('Unequal library size')
        for index, skill in enumerate(skills):
            mode = 'llm_semantic_' + skill['skill_id']
            if mode in policies:
                raise ValueError('Duplicate policy mode')
            policies[mode] = (bank, skill)
            template_indices[mode] = index
    observations = defaultdict(dict)
    with (run / 'heldout_metrics.csv').open(encoding='utf-8', newline='') as handle:
        for row in csv.DictReader(handle):
            if row['mode'] not in policies:
                continue
            seed = int(row['seed'])
            if seed not in seeds or row['split'] != 'heldout' or seed in observations[row['mode']]:
                raise ValueError('Unexpected/duplicate held-out cell')
            score = Decimal(row['best_so_far_auc'])
            if not score.is_finite():
                raise ValueError('Nonfinite score')
            observations[row['mode']][seed] = score
    if set(observations) != set(policies) or any(set(rows) != seeds for rows in observations.values()):
        raise ValueError('Missing held-out cells')
    means = {mode: sum(rows.values()) / len(rows) for mode, rows in observations.items()}
    signatures = {mode: signature(skill) for mode, (_, skill) in policies.items()}
    by_signature = defaultdict(list)
    for mode, sig in signatures.items():
        by_signature[sig].append(mode)
    for modes in by_signature.values():
        if any(observations[mode] != observations[modes[0]] for mode in modes):
            raise ValueError('Exact execution aliases have different metrics')
    selected = lock['selections']['llm']['ungated_calibration_winner']
    result = {'protocol_id': config['protocol_id'], 'run_dir': str(run.resolve()),
              'input_sha256': hashes, 'heldout_seed_count': len(seeds),
              'frozen_llm_calibration_winner': selected, 'templates': [],
              'all_policy_means': [{'mode': mode, 'library': policies[mode][0],
                                   'template_index': template_indices[mode],
                                   'exact_execution_signature': signatures[mode],
                                   'heldout_mean_auc_decimal': str(score)}
                                  for mode, score in sorted(means.items())]}
    for index, skill in enumerate(manifest['libraries']['llm']):
        mode = 'llm_semantic_' + skill['skill_id']
        for family in ('r1', 'r2'):
            family_modes = [candidate for candidate, (bank, _) in policies.items() if bank.startswith(family + '_')]
            for scope, candidates in (
                ('same_template', [candidate for candidate in family_modes if template_indices[candidate] == index]),
                ('all_five_templates', family_modes)):
                unique = {}
                for candidate in candidates:
                    unique.setdefault(signatures[candidate], candidate)
                result['templates'].append({
                    'template': skill['skill_id'], 'llm_mode': mode, 'family': family, 'scope': scope,
                    'is_frozen_calibration_winner': mode == selected,
                    'llm_heldout_mean_auc_decimal': str(means[mode]),
                    'sample_draw_weighted': compare(means[mode], [means[c] for c in candidates]),
                    'distinct_execution_weighted': compare(means[mode], [means[c] for c in unique.values()])})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, action='append', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise ValueError('Refusing to overwrite output')
    runs = [analyze(path) for path in args.run_dir]
    result = {'analysis_status': 'retrospective_descriptive_only', 'model_api_calls': 0,
              'new_replay_trajectories': 0, 'new_rules_generated': 0, 'policy_reselection': False,
              'metric': 'Mean of the archived per-seed best_so_far_auc over all frozen held-out seeds.',
              'rank_definition': 'Insert each LLM strategy into observed controls; rank 1 is highest AUC. Ties reported as full inclusive rank interval. Both sampled-draw and distinct-execution weights are shown.',
              'boundary': 'Observed random draws only, not the entire grammar or an exact randomization p-value. Rankings were requested after results were seen. No new confirmatory claims, selection or pooling across the two different seed panels.',
              'source_sha256': sha(Path(__file__)), 'runs': runs}
    args.output_dir.mkdir(parents=True)
    (args.output_dir / 'rankings.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    rows = []
    for run in runs:
        for item in run['templates']:
            for weighting in ('sample_draw_weighted', 'distinct_execution_weighted'):
                rows.append({'protocol_id': run['protocol_id'],
                             **{k: v for k, v in item.items() if not isinstance(v, dict)},
                             'weighting': weighting, **item[weighting]})
    with (args.output_dir / 'rankings.csv').open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    print(json.dumps([{'protocol': run['protocol_id'], 'winner_rankings': [item for item in run['templates']
                       if item['is_frozen_calibration_winner'] and item['scope'] == 'same_template']}
                      for run in runs], indent=2))


if __name__ == '__main__':
    main()
