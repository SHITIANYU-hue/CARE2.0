import os
os.environ.update(OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1",MKL_NUM_THREADS="1")
from pathlib import Path
import sys,json,gzip
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"experiments/care_replay/protocols/suzuki_continuation_amendment2"))
import continuation_integrity as I
import continuation_receipts as R
import evaluation as E
from threadpoolctl import threadpool_info
with E.matched.offline_guard():
    config,lock,_=I.verify();outcomes,payloads,_=R.verify_generation(I.CONFIG,I.LOCK,I.NEW,config,lock)
    libraries,_,_=E.make_libraries(payloads,config);skills=tuple(s for b in libraries.values() for s in b)
    reps,_=E.matched.execution_plan(skills,True);seed=config["calibration_seed_start"]
    before=I.common.load(I.EVALUATION/f"calibration_seeds/{seed}.json")
    before_traces=json.loads(gzip.decompress((I.EVALUATION/f"calibration_seeds/{seed}.traces.json.gz").read_bytes()))
    pools=threadpool_info()
    if any(pool["num_threads"]!=1 for pool in pools):raise ValueError("Numerical thread limit differs")
    rows,traces,seconds=E.seed_job(seed,"calibration",config,reps)
    same_rows=json.loads(json.dumps(rows))==before["rows"]
    same_traces=json.loads(json.dumps(traces))==before_traces
    record={"purpose":"Verify reuse of prior single-live-thread checkpoints after setting BLAS=1 before imports; verification replay does not enter selection a second time.","seed":seed,"policy_count":len(reps)+3,"threadpool_info":pools,"metrics_exactly_equal":same_rows,"entire_traces_exactly_equal":same_traces,"verification_seconds":seconds,"model_api_calls":0}
    I.common.save(Path(__file__).with_name("runtime_checkpoint_verification.json"),record,exclusive=True)
    if not(same_rows and same_traces):raise ValueError("Checkpoint differs under explicit single-thread runtime")
    print(json.dumps(record))
