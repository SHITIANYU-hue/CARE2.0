from pathlib import Path
import json,hashlib,tarfile
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/"experiments/care_replay";OUT=Path(__file__).resolve().parent
proof=json.loads((OUT/"final_audit.json").read_text())
if proof.get("status")!="verified":raise ValueError("Final verified audit required")
lock=json.loads((BASE/"preregistrations/suzuki_second_dataset_v1.lock.json").read_text())
entries=[BASE/"protocols/suzuki_continuation_amendment2",BASE/"configs/suzuki_continuation_amendment2.json",BASE/"configs/suzuki_second_dataset_v1.json",BASE/"preregistrations/suzuki_continuation_amendment2.lock.json",BASE/"preregistrations/suzuki_second_dataset_v1.lock.json",BASE/"results/2026-10-20-suzuki-second-dataset-v1-freeze",BASE/"results/2026-10-20-suzuki-continuation-amendment2-freeze",BASE/"results/2026-10-20-suzuki-continuation-amendment2-generation",BASE/"results/2026-10-20-suzuki-continuation-amendment2-evaluation",BASE/"SUZUKI_SECOND_DATASET_V1_RESULTS.md",BASE/"SUZUKI_SECOND_DATASET_V1_STATUS.md",OUT]
for group in ("source_sha256","input_sha256","data_sha256"):
    for rel,sha in lock[group].items():
        path=ROOT/rel
        if hashlib.sha256(path.read_bytes()).hexdigest()!=sha:raise ValueError("Original frozen input changed")
        entries.append(path)
files=set()
for entry in entries:
    for f in (entry.rglob("*") if entry.is_dir() else [entry]):
        if f.is_symlink():raise ValueError("Symlink in archive inputs")
        if f.is_file() and not f.name.endswith((".tar.gz",".tmp",".pyc")) and "__pycache__" not in f.parts and f.name!="final_archive_verification.json":
            if f.name==".env" or ".git" in f.parts or ".venv" in f.parts:raise ValueError("Sensitive/unneeded archive path")
            files.add(f)
hashes={f.relative_to(ROOT).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
archive=OUT/"suzuki-completed-experiment-evidence.tar.gz"
with tarfile.open(archive,"x:gz") as t:
    for f in sorted(files):t.add(f,arcname=f.relative_to(ROOT).as_posix(),recursive=False)
with tarfile.open(archive,"r:gz") as t:
    if set(t.getnames())!=set(hashes):raise ValueError("Archive member inventory differs")
    for name,sha in hashes.items():
        if hashlib.sha256(t.extractfile(name).read()).hexdigest()!=sha:raise ValueError("Archive member hash differs")
record={"archive":str(archive.relative_to(ROOT)),"archive_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"member_count":len(hashes),"all_members_verified":True,"contains_env_or_git_or_venv":False,"files_sha256":hashes}
(OUT/"final_archive_verification.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({k:v for k,v in record.items() if k!="files_sha256"}))
