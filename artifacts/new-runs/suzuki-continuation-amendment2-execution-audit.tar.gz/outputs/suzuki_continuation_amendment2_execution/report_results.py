"""Post-completion reporting only; no fitting, selection changes, or network access."""
from pathlib import Path
import sys,json,hashlib,copy
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"experiments/care_replay/protocols/suzuki_continuation_amendment2"))
import continuation_integrity as I
import continuation_receipts as receipts
import evaluation,analysis

def main():
    with evaluation.matched.offline_guard():
        config,lock,amendment=I.verify();base=I.EVALUATION;out=Path(__file__).resolve().parent
        complete=I.common.load(base/"completion.json")
        outcomes,payloads,hashes=receipts.verify_generation(I.CONFIG,I.LOCK,I.NEW,config,lock)
        manifest=I.common.load(base/"manifest.json");selection=I.common.load(base/"selection_lock.json")
        result=I.common.load(base/"analysis.json");rows=I.common.load(base/"heldout_metrics.json")
        if manifest["generation_files_sha256"]!=hashes: raise ValueError("Generation manifest changed")
        if selection["manifest_sha256"]!=I.common.file_hash(base/"manifest.json"): raise ValueError("Manifest hash changed")
        if selection["calibration_sha256"]!=I.common.file_hash(base/"calibration_metrics.json"): raise ValueError("Calibration changed")
        if complete["selection_sha256"]!=I.common.file_hash(base/"selection_lock.json"): raise ValueError("Selection changed")
        if complete["analysis_sha256"]!=I.common.file_hash(base/"analysis.json"): raise ValueError("Analysis changed")
        reproduced=analysis.analyze(rows,selection["choices"],outcomes,selection["anchor"],config)
        if reproduced!=result: raise ValueError("Final analysis not reproducible")
        checkpoint_counts={}
        for split,count in [("calibration",50),("heldout",100)]:
            files=list((base/(split+"_seeds")).glob("*.json"))
            if len(files)!=count: raise ValueError("Wrong checkpoint count")
            for f in files:
                data=I.common.load(f)
                if data["context_sha256"]!=complete[split]["context_sha256"] or I.common.file_hash(f.with_suffix(".traces.json.gz"))!=data["trace_sha256"]: raise ValueError("Checkpoint changed")
            checkpoint_counts[split]=len(files)
        runtime=I.common.load(out/"runtime_checkpoint_verification.json")
        if not(runtime["metrics_exactly_equal"] and runtime["entire_traces_exactly_equal"]): raise ValueError("Runtime verification failed")
        restart=I.common.load(out/"local_runtime_restart.json")
        for rel,sha in restart["completed_checkpoints_sha256"].items():
            if I.common.file_hash(base/rel)!=sha: raise ValueError("Preserved checkpoint changed after restart")
        evidence={"runtime_checkpoint_metrics_and_traces_exactly_reproduced":True,"preserved_calibration_checkpoints":48,"status":"verified","all_original_evidence_unchanged":True,"actual_post_attempts":21,"logical_terminal_slots":20,"generation_model_calls_in_verification":0,"checkpoint_counts":checkpoint_counts,"analysis_reproduced_exactly":True,"original_lock_sha256":I.common.file_hash(I.LOCK),"amendment_lock_sha256":I.common.file_hash(I.AMENDMENT_LOCK),"selection_sha256":complete["selection_sha256"],"analysis_sha256":complete["analysis_sha256"]}
        if (out/"final_audit.json").exists():
            if I.common.load(out/"final_audit.json")!=evidence: raise ValueError("Existing final audit differs")
        else: I.common.save(out/"final_audit.json",evidence,exclusive=True)
        keys=["labeled_minus_r1_valid_parents","labeled_minus_r2_valid_parents","labeled_minus_anonymous_all_pairs"]
        labels=["有标签 − R1（6 个有效父库）","有标签 − R2（6 个有效父库）","有标签 − 匿名化（全部 10 对）"]
        lines=[]
        for key,label in zip(keys,labels):
            x=result["primary"][key];ci=x["interval_adjusted"]
            lines.append(f"| {label} | {x['mean_delta']:+.4f} | [{ci[0]:+.4f}, {ci[1]:+.4f}] | {'通过' if x['stable_advantage'] else '未通过'} |")
        passed=[label for key,label in zip(keys,labels) if result["primary"][key]["stable_advantage"]]
        conclusion="按冻结标准，"+("、".join(passed)+"的优势稳定。" if passed else "三项比较均未达到稳定优势标准。")
        blocks="\n".join(f"- {label}："+"、".join(f"{v:+.4f}" for v in result["primary"][key]["heldout_block_means"]) for key,label in zip(keys,labels))
        secondary=result["secondary_descriptive"]
        valid=result["valid_counts"];gate=result["gate_acceptance"]
        performance_rows=[]
        for name,key in [("有标签，主策略","labeled_primary_mode"),("匿名化，主策略","anonymous_primary_mode"),("有标签，gate 后","labeled_selected_mode"),("匿名化，gate 后","anonymous_selected_mode")]:
            v=secondary[key];performance_rows.append(f"| {name} | {v['mean_auc']:.4f} | {v['mean_delta_anchor']:+.4f} |")
        text=f"""# BH→Suzuki 第二数据集验证结果（续跑修订 2）

{conclusion}三项区间均跨过 0，同时容许收益与损失，不能据此宣称等效或确定劣势。这是冻结的 50 种子校准、100 种子留出回放结果；未根据结果调整阈值、种子、规则库或主分析。

## 与投稿计划待补实验的关系

本轮直接对应投稿计划“实验二”的随机规则、匿名化和第二个反应任务（Suzuki）验证。它补充非 RSI 部分的第二数据集迁移与机制对照：把 BH 512 条源观察形成的证据用于 Suzuki 规则生成，检验候选规则经过同预算筛选后，是否比覆盖匹配随机规则有更稳定的收益；语义标签/匿名化成对比较检验端到端标签信息带来的差异。这里不进行规则修订循环，也不能据此宣称 RSI 有效。

实验二仍缺化学成员在不看结果的前提下独立编写的规则对照及化学解释。本轮也不能代替实验一的跨模型复现、实验三要求的 20 条以上蛋白迁移上的 gate 误收/误拒评估，或实验四的模型未见新数据验证。以上属于后续独立工作，不会借本轮结果自动更改方案或调用 API。

## 冻结主结果

生成使用 OpenRouter 的 `{config['model']['id']}`，仅 OpenAI 路由，温度 {config['model']['temperature']}，输出上限 {config['model']['max_tokens']} token。每库 5 条策略，原子规则数为 2、1、1、1、1；语义匿名化同时编码字段、类别和任务标签，保留数值统计及规则空间。本轮生成提示词未提供 Suzuki 目标产率。此轮只覆盖这一个模型，不构成跨模型复现。

AUC 指每轮 best-so-far 产率的均值，单位为产率百分点，**不是 ROC AUC**。正差表示有标签组更好。主结果采用未经过 gate 回退的每库校准赢家；无效生成库按预定方案整库使用共同校准基线。

| 比较 | 留出 ΔAUC | 三重比较校正的 98.3333% 区间 | 稳定优势判定 |
|---|---:|---:|---|
{chr(10).join(lines)}

稳定优势需同时满足：校正区间下界 > 0，且按原顺序划分的 5 个 20 种子留出块均值全部 > 0。预定 10,000 次 bootstrap 同时重采样父库与共享种子；R1/R2 还在父库内重采样随机库。五个块依次为：

{blocks}

随机对照只在有效有标签父库 0、1、5、6、7、8 上比较；每个父库 R1/R2 各 10 个随机库，因此每类 60 库、300 条候选策略、360 条原子规则。这些随机库是嵌套重复，不能当成 60 个独立父库。

## 生成合法率与 gate（描述性）

- 有标签组有效 {valid['labeled']}/10，匿名组有效 {valid['anonymous']}/10。6 个无效库均因出现契约之外的字段/类别而整库回退，未修补或补抽。全部 10 对进入标签比较，差异同时包含生成合法率和规则效果，不能解释为纯化学语义因果效应。
- 共同校准基线为 `{result['anchor']}`，留出平均 AUC 为 {result['anchor_mean_auc']:.4f}。
- gate 通过库数：有标签 {gate['labeled']}/10、匿名 {gate['anonymous']}/10、R1 {gate['r1']}/60、R2 {gate['r2']}/60。各有效库仍为五选一；无效库没有候选策略获 gate 接受。
- gate 后有标签−R1 ΔAUC：{secondary['gated_labeled_minus_r1']['mean_delta']:+.4f}；有标签−R2：{secondary['gated_labeled_minus_r2']['mean_delta']:+.4f}；有标签−匿名：{secondary['gated_labeled_minus_anonymous']['mean_delta']:+.4f}。前两项仍限定于 6 个有效有标签父库，第三项包含全部 10 对。这些是次要描述，不替代主分析。

以下四行是全 10 对、包含无效库共同基线回退的描述性均值，不增加新的显著性主张：

| 部署方式 | 留出平均 AUC | 相对共同基线 ΔAUC |
|---|---:|---:|
{chr(10).join(performance_rows)}

## 对照的匹配程度及边界

两类随机对照的每条规则支持比例与策略联合触发分布均精确匹配（实际最大偏差 0，预定容差 0.005）。模板规则数量、条件数量、权重绝对值、执行器参数及每库五选一预算保持不变。R1 在原字段上随机化类别/符号；R2 还允许同类型同基数字段的一一交换，保留合法的恒等映射与重复抽样。

配体结构按获批修订更正，原分箱阈值不变。R2 仅剩两个布尔字段可互换：30 个有效模板中，类型约束允许 6 个模板尝试两种字段映射，24 个仅能尝试一种；R1/R2 各有 4 个模板的覆盖匹配条件配置仅剩一种（仍可随机化符号）。进一步核对通过覆盖匹配的配置池发现，**30/30 个模板的 R1/R2 可抽样配置池哈希完全一致**：额外字段交换均未通过本轮覆盖条件。因此本轮 R2 退化为与 R1 相同的条件随机分布，只使用不同的冻结抽样种子。两列结果是同一条件随机对照的两批抽样，不能作为两种独立机制证据；三项主比较及原多重校正仍按冻结方案保留。详见 `outputs/suzuki_continuation_amendment2_execution/r1_r2_pool_equivalence.json`。

校准和留出是**同一 5,760 条反应池上的不同随机起点/种子**，不是独立留出的反应数据集。本轮提示词仅包含 BH 源证据及 Suzuki 公共描述统计，未提供 Suzuki 目标产率。该 Suzuki 数据集曾用于历史工作；本结果是事先冻结的新协议验证，不能称作首次外部新数据发现、前瞻化学实验或普适化学知识证明。有限的 6 个有效有标签父库及其条件筛选应一并报告。此外，本轮没有去掉 BH 源证据的成对生成对照，因此不能单独归因或量化 BH 源信息带来的增量迁移收益。

## 执行、费用与可复核文件

原运行第 10 次请求发生传输失败，没有可核验的响应 ID。用户批准一次指定替补，总上限由 20 改为 21。前 9 个终态和全部原证据原样保留；独立续跑执行器先完成 98 项断网测试并冻结，再执行 11 次请求。续跑无新增传输失败、无第二次替补、无无效库补抽。基础设施中断导致配对生成不完全相邻，作为执行偏离披露。

本地评估在完成 48 个校准种子后重启一次，以在导入 NumPy 之前显式设置原定的单线程 BLAS 环境。重启前四个工作进程各只有一个实际线程；48 个已完成检查点逐字节保留。另用显式单线程环境完整复算首个种子的 222 条策略轨迹，全部指标和每轮轨迹精确一致；这一次审计复算不额外进入统计，未改变冻结代码、种子或科学配置。

- 实际 POST 共 21 次，逻辑终态 20 个；有效库 14 个，整库回退 6 个。
- 已确认费用 **$0.0180612**；失败请求未知费用预留 **$0.045**；保守占用 **$0.0630612 < $1**。不能把未知费用记为 0，也不能把已知费用称为最终完整账单。
- 本地评估 API 调用 0；校准 50/50、留出 100/100。正式分析的校准逻辑轨迹 {complete['calibration']['logical_trajectories']}，去重轨迹 {complete['calibration']['physical_trajectories']}；留出逻辑轨迹 {complete['heldout']['logical_trajectories']}，去重轨迹 {complete['heldout']['physical_trajectories']}。完全相同的执行输入复用轨迹，逻辑筛选预算不变。
- 原协议锁：`{I.common.file_hash(I.LOCK)}`。
- 续跑锁：`{I.common.file_hash(I.AMENDMENT_LOCK)}`。
- 选择锁：`{complete['selection_sha256']}`。
- 结果：`results/2026-10-20-suzuki-continuation-amendment2-evaluation/analysis.json`。
- 生成收据与真实尝试账本：`results/2026-10-20-suzuki-continuation-amendment2-generation/`。
- 最终核验：`outputs/suzuki_continuation_amendment2_execution/final_audit.json`，包含 150 个种子检查点/轨迹哈希核验及主分析精确重现。

任何新增生成、规则空间扩大、阈值调整或后续验证协议应另行决策；本轮结果不会触发自动改方案。
"""
        report=I.BASE/"SUZUKI_SECOND_DATASET_V1_RESULTS.md";report.write_text(text,encoding="utf-8")
        # Static scientific plot from the already frozen primary analysis only.
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(8,3.5),layout="constrained")
        names=["Labeled − R1 (6 parents)","Labeled − R2 (6 parents)","Labeled − anonymous (10 pairs)"]
        for idx,key in enumerate(keys):
            x=result["primary"][key];lo,hi=x["interval_adjusted"];v=x["mean_delta"]
            ax.plot([lo,hi],[idx,idx],color="#235c91",linewidth=2);ax.scatter([v],[idx],color="#235c91",s=40,zorder=3)
        ax.axvline(0,color="#777777",linestyle="--",linewidth=1)
        ax.set_yticks(range(3),names);ax.invert_yaxis();ax.set_xlabel("Held-out Δ mean best-so-far yield (percentage points)")
        ax.set_title("BH → Suzuki: frozen primary comparisons\nBonferroni-adjusted 98.3333% bootstrap intervals",fontsize=11)
        ax.spines[["top","right"]].set_visible(False)
        fig.savefig(out/"primary_auc_comparisons.png",dpi=180);fig.savefig(out/"primary_auc_comparisons.pdf");plt.close(fig)
        print(json.dumps({"report":str(report),"conclusion":conclusion,"primary":result["primary"],"audit":evidence},ensure_ascii=False))

if __name__=="__main__":main()
