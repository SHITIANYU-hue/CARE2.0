# 论文主张与本次审计证据

本表只补归档事实，不重新检验效应，不扩展 AUC 纳入范围。2026-10-21。

| 主张 | 可用表述 | 证据文件 | 限制／修改处 |
|---|---|---|---|
| 模型是否真正影响动作 | 受限一轮试点 0/6；高权限 v1 46/110、v2 6/10 改变当轮 GP 首选 | online_actions.json；online_trajectories.json | 分母为完成轨迹中的已执行决策轮；不能混同 gate 回退或证明收益 |
| 受限试点调用量 | 6 个决策轮；12 次有效响应，另 2 次无效响应后修复，共 14 次有响应尝试；99,243 token | online_response_attempts.json；online_suites.json | 原“6 次调用”需改写；54 轮回退不算模型同意 |
| 在线成本 | 成功 1,886,429 token；失败已记录 259,296；合计下界 2,145,725 | online_suites.json；online_response_attempts.json | 不含所有未知收费；美元未知，不是全项目账单 |
| 复用初始设计成本 | 17 份历史记录共 82,564 token，单独报告 | online_initial_records.json | 不能逐轨迹重复计费；未覆盖所有开发提案 |
| 规则库生成费用 | BH 累计已知 $0.0343659；Suzuki 已知 $0.0180612＋$0.045 未知费用预留 | chemistry_generation_attempts.json；source_manifest.json | 已含无效生成；预留非实付，旧预算非新授权 |
| 7 条迁移中 2 条通过且可由暖启动复现 | 以 2026-08-07 机制对照为准；通过两条的 100 个留出种子逐一复现 final 与 AUC | historical_budget_audit.json；mechanism_budget_traces.json | 不是较早 4/7 那批；同有限池回放；本审计不新增区间 |
| 三条置乱对照同预算 | 路线明确为 2＋13、2＋13、5＋10，总数均 15 | falsification_budget_jobs.json；falsification_budget_traces.json；历史 runner 快照 | 63 条完整轨迹，其余只有 job 指标/初始ID/指纹；不称全量逐步核验 |
| 当前 AUC 三面板结论 | 沿用上一版 RESULTS.md；本审计未修改 | ../auc_reanalysis_execution_v1/RESULTS.md | 未吸收历史额外迁移；归一化不是独立复现 |
| 训练不可见、专家优势或模型普适性 | 仍为待补证据 | 投稿计划新版 | 本次审计不能替代专家、新数据或跨模型实验 |

机器可读行数是审计量，不是独立生成、独立任务或家族样本量。所有比例只描述所列归档范围。
