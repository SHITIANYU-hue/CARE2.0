"""Verify archived budgets only; do not normalize, rerun policies or change inclusion."""
from audit_actions_costs import *
import subprocess,io,csv
GIT={}
def gitfile(commit,rel):
 x=subprocess.check_output(['git','show',commit+':'+rel],cwd=R);GIT[commit+':'+rel]=digest(x);return x

def falsification():
 a=Archive(R/'artifacts/replay-results/replay-2026-08-24-source-outcome-falsification-v1.tar.gz')
 report=a.j(a.suffix('/falsification_report.json'));configraw=read(B/'configs/source_outcome_falsification_v1.json');config=json.loads(configraw)
 check(digest(configraw)==report['config_sha256'],'falsification exact config hash')
 rel='experiments/care_replay/scripts/run_source_outcome_falsification.py'
 commits=subprocess.check_output(['git','log','--all','--format=%H','--',rel],cwd=R,text=True).splitlines();matched=None
 for c in commits:
  x=gitfile(c,rel)
  if digest(x)==report['implementation']['files']['runner']:matched=c;break
 check(matched is not None,'historical falsification runner hash located')
 (O/'falsification_runner_historical.py.txt').write_bytes(x)
 # Static evidence, no import/execution of experiment runner.
 check(b'policy.get("initial_observations", protocol["initial_observations"])' in x and b'policy.get("reveal_rounds", protocol["reveal_rounds"])' in x,'route override present in exact archived implementation')
 pairs={p['pair_id']:p for p in config['pairs']};stats={};jobrecs=[];tracerecs=[]
 manifest=a.j(a.suffix('/job_manifest.json'));mh={j['path']:j['sha256'] for j in manifest['jobs']}
 for n in a.names:
  if '/jobs/' not in n or not n.endswith('.json'):continue
  raw=a.raw(n);j=json.loads(raw);pid=j['pair_id'];cfg=pairs[pid];ip=cfg.get('frozen_policy',{}).get('initial_observations',config['protocol']['initial_observations']);rd=cfg.get('frozen_policy',{}).get('reveal_rounds',config['protocol']['reveal_rounds'])
  check(digest(raw)==mh['jobs/'+Path(n).name],'job manifest hash '+Path(n).name)
  check(j['config_sha256']==report['config_sha256'] and j['implementation_sha256']==report['implementation']['sha256'],'job implementation identity '+Path(n).name)
  idsizes={len(row['selected_initial_ids'].split('|')) for row in j['rows']}
  check(idsizes=={ip},'all conditions initial count '+Path(n).name)
  check(len(j['rows'])==21,'all frozen conditions present '+Path(n).name)
  jobrecs.append({'pair':pid,'seed':j['target_seed'],'conditions':len(j['rows']),'initial_count':ip,'expected_reveals_from_exact_config':rd,'audit_conditions_available':len(j['audits']),'member':n})
  for cond,ev in j['audits'].items():
   check(len(ev)==rd and [e['round_index'] for e in ev]==list(range(rd)),'retained falsification round sequence '+pid+cond)
   row=next(row for row in j['rows'] if row['condition']==cond)
   initial=row['selected_initial_ids'].split('|');selected=[e['selected_candidate'] for e in ev]
   check(len(set(initial+selected))==ip+rd,'unique revealed candidates '+pid+cond)
   check(abs(statistics.mean(e['best_so_far'] for e in ev)-row['best_so_far_auc'])<=0.000051,'stored AUC horizon '+pid+cond)
   tracerecs.append({'pair':pid,'seed':j['target_seed'],'condition':cond,'initial':ip,'observed_reveals':len(ev),'total_target_observations':ip+len(ev),'auc_matches_stored':True})
 for pid,pair in pairs.items():
  rows=[x for x in jobrecs if x['pair']==pid];tr=[x for x in tracerecs if x['pair']==pid]
  stats[pid]={'global_default_initial':5,'global_default_reveals':10,'route_override':pair['frozen_policy'],'jobs_checked':len(rows),'condition_rows_checked':sum(x['conditions'] for x in rows),'initial_counts_observed':sorted(set(x['initial_count'] for x in rows)),'fully_retained_trajectories':len(tr),'retained_trajectory_seeds':sorted(set(x['seed'] for x in tr)),'observed_reveal_counts':sorted(set(x['observed_reveals'] for x in tr)),'status':'route override verified; not a total-budget mismatch','limitation':'Only first target seed has full per-step audits; remaining jobs have initial IDs/metrics and matching config/implementation fingerprints, not full archived trajectories.'}
 write('falsification_budget_jobs.json',jobrecs);write('falsification_budget_traces.json',tracerecs)
 return {'study':'2026-08-24-source-outcome-falsification-v1','historical_runner_commit':matched,'routes':stats,'normalization_admission':'NOT CHANGED: pool certification and appended analysis require a separate decision.'}

def mechanism():
 arcs=[Archive(R/'artifacts/replay-results'/('replay-2026-08-07-mechanism-controls-part'+i+'.tar.gz')) for i in ['01','02','03']];a=arcs[-1]
 config=a.j(a.suffix('/configs/source_outcome_benchmark.json'));run=a.j(a.suffix('/run_manifest.json'));pairs=config['pairs'];traces=[];routes=[]
 for rel in ['experiments/care_replay/scripts/run_source_outcome_suite.py','experiments/care_replay/scripts/run_calibrated_source_outcome_transfer.py']:
  raw=gitfile(run['code_commit'],rel);(O/('historical_'+Path(rel).name+'.txt')).write_bytes(raw)
 for pair in pairs:
  pid=pair['pair_id'];pol=pair['frozen_policy'];ip=pol['initial_observations'];rd=pol['reveal_rounds']
  sn=next(n for n in a.names if '/raw_summaries/' in n and n.endswith('_'+pid+'_summary.json'));summary=a.j(sn)
  check(summary['initial_observations']==ip and summary['rounds']==rd,'mechanism summary budget '+pid)
  mn=sn.replace('/raw_summaries/','/raw_metrics/').replace('_summary.json','_metrics.csv')
  metrics=list(csv.DictReader(io.StringIO(a.raw(mn).decode())));lookup={(x['mode'],int(x['seed'])):x for x in metrics}
  outer=next(ar for ar in arcs if any(n.endswith('/audit_archives/'+pid+'.tar.gz') for n in ar.names));nested=outer.suffix('/audit_archives/'+pid+'.tar.gz');data=outer.raw(nested)
  start=len(traces)
  with tarfile.open(fileobj=io.BytesIO(data),mode='r|gz') as t:
   for m in t:
    if not m.isfile() or not m.name.endswith('.jsonl'):continue
    raw=t.extractfile(m).read();MEMBERS[str(outer.p)+'::'+nested+'::'+m.name]=digest(raw)
    ev=[json.loads(x) for x in raw.decode().splitlines() if x.strip()];mode=ev[0]['mode'];seed=ev[0]['seed']
    check(len(ev)==rd and [e['round_index'] for e in ev]==list(range(rd)),'mechanism rounds '+pid+mode+str(seed))
    observed=[e.get('public_observed_count') for e in ev];direct=all(v is not None for v in observed)
    if direct:check(observed==list(range(ip,ip+rd)),'mechanism pre-reveal counts '+pid+mode+str(seed))
    check(len({e['selected_candidate'] for e in ev})==rd,'mechanism unique reveals '+pid+mode+str(seed))
    metric=lookup.get((mode,seed));matched=False
    if metric:
     check(abs(statistics.mean(e['best_so_far'] for e in ev)-float(metric['best_so_far_auc']))<=0.000051,'mechanism AUC horizon '+pid+mode+str(seed));matched=True
    traces.append({'pair':pid,'mode':mode,'seed':seed,'split':ev[0].get('split'),'expected_initial':ip,'initial_directly_observed':observed[0] if direct else None,'reveals':len(ev),'total_budget_by_config':ip+rd,'auc_matches_metric':matched,'member':m.name})
  rr=traces[start:]
  check(len(rr)==len(metrics) and len({(x['mode'],x['seed']) for x in rr})==len(rr) and {(x['mode'],x['seed']) for x in rr}==set(lookup),'metric to trace bijection '+pid)
  post_init_matches=sum(lookup[('llm_transfer_router',seed)]['best_so_far_auc']==lookup[('source_warmstart_only',seed)]['best_so_far_auc'] and lookup[('llm_transfer_router',seed)]['final_best']==lookup[('source_warmstart_only',seed)]['final_best'] for seed in range(run['heldout_seed_start'],run['heldout_seed_start']+run['heldout_seed_count']))
  accepted=summary['selection'].get('selected_mode') or summary['selection'].get('deployed_mode')
  routes.append({'pair':pid,'route_initial':ip,'route_reveals':rd,'total_target_budget':ip+rd,'summary_member':sn,'selection':{k:v for k,v in summary['selection'].items() if not isinstance(v,(dict,list))},'heldout_full_vs_warmstart_equal_final_and_auc_count':post_init_matches,'metric_rows':len(metrics),'archived_traces':len(rr),'traces_with_initial_count_logged':sum(x['initial_directly_observed'] is not None for x in rr),'traces_with_metric_match':sum(x['auc_matches_metric'] for x in rr),'modes':sorted(set(x['mode'] for x in rr)),'calibration_seeds':len(set(x['seed'] for x in rr if x['split']=='calibration')),'heldout_seeds':len(set(x['seed'] for x in rr if x['split']=='heldout'))})
  print('Checked mechanism route '+pid+': '+str(len(rr))+' traces',flush=True)
 write('mechanism_budget_traces.json',traces)
 return {'study':'2026-08-07-mechanism-controls','run_manifest':run,'routes':routes,'route_budgets_match':True,'normalization_admission':'NOT CHANGED: no new normalized effect or pooled inference computed.'}
if __name__=='__main__':
 result={'falsification':falsification(),'mechanism':mechanism()}
 write('historical_budget_audit.json',result);write('budget_audit_checks.json',CHECKS);write('budget_source_manifest.json',{'files':SOURCES,'members':MEMBERS,'git_objects_sha256':GIT,'model_api_calls':0,'new_policy_runs':0})
 print(json.dumps({'falsification':result['falsification'],'mechanism_routes':result['mechanism']['routes'],'checks':len(CHECKS)},ensure_ascii=False,indent=2))
