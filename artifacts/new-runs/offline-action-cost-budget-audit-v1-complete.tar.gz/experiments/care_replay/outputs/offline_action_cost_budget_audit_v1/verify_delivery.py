"""Independent reconciliation and immutable-source checks, no network."""
from pathlib import Path
import hashlib,json,csv,collections,ast,subprocess,socket
O=Path(__file__).parent; B=O.parents[1];R=B.parents[1]
def deny(*a,**k):raise RuntimeError('offline verification')
socket.socket=deny;socket.create_connection=deny
checks=[]
def require(v,name):
 checks.append({'name':name,'passed':bool(v)})
 if not v:raise AssertionError(name)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(n):return json.loads((O/n).read_text())
for p in O.glob('*.py'):ast.parse(p.read_text())
for name in ['audit_checks.json','budget_audit_checks.json']:require(all(x['passed'] for x in load(name)),name)
files={};git={}
for name in ['source_manifest.json','budget_source_manifest.json']:
 d=load(name)
 for k,v in d['files'].items():
  require(k not in files or files[k]==v,'consistent source snapshot '+k);files[k]=v
 git.update(d.get('git_objects_sha256',{}))
for p,expected in files.items():require(h(Path(p))==expected,'source unchanged '+p)
for spec,expected in git.items():require(hashlib.sha256(subprocess.check_output(['git','show',spec],cwd=R)).hexdigest()==expected,'historical Git object '+spec)
auc=B/'outputs/auc_reanalysis_execution_v1';d=json.loads((auc/'DELIVERY_MANIFEST.json').read_text())
for rel,expected in d['files_sha256'].items():require(h(auc/rel)==expected,'frozen AUC unchanged '+rel)
ss=load('online_suites.json');aa=load('online_actions.json');cc=load('online_response_attempts.json');tt=load('online_trajectories.json')
for s in ss:
 done=[x for x in aa if x['suite']==s['suite'] and x['trajectory_status']=='completed'];llm=[x for x in done if x['kind']=='llm_decision'];calls=[x for x in cc if x['suite']==s['suite']]
 require(sum(x['executed']!=x['gp_default'] for x in llm)==s['completed_final_overrides'],'ID-based override re-count '+s['suite'])
 for kind,key in [('completed','completed_usage'),('failed','failed_recorded_usage')]:
  require(sum(x['usage']['total_tokens'] for x in calls if x['trajectory_status']==kind)==s[key]['total_tokens'],'response-based token re-count '+s['suite']+kind)
 require(s['completed_recorded_response_attempts']==2*len(llm)+s['completed_invalid_response_attempts'],'valid stages plus repairs '+s['suite'])
require(len(tt)==34 and sum(x['status']=='failed' for x in tt)==16,'18 completed and 16 failed trajectories')
require(sum(s['failed_recorded_usage']['total_tokens'] for s in ss)==259296,'additional failed usage')
require(sum(s['all_recorded_usage_lower_bound']['total_tokens'] for s in ss)==2145725,'all known online usage lower bound')
jobs=load('falsification_budget_jobs.json');bt=load('mechanism_budget_traces.json');budget=load('historical_budget_audit.json')
for pid in budget['falsification']['routes']:
 rows=[x for x in jobs if x['pair']==pid]
 require(len(rows)==100 and {x['seed'] for x in rows}==set(range(73000,73100)),'all falsification job seeds '+pid)
for route in budget['mechanism']['routes']:
 rows=[x for x in bt if x['pair']==route['pair']]
 require(len(rows)==1300 and len({(x['mode'],x['seed']) for x in rows})==1300,'distinct mechanism mode-seed audit rows '+route['pair'])
 for split,expected in [('calibration',set(range(64000,64050))),('heldout',set(range(65000,65100)))]:require({x['seed'] for x in rows if x['split']==split}==expected,'mechanism split seeds '+route['pair']+split)
require(len(bt)==9100 and sum(x['initial_directly_observed'] is not None for x in bt)==8050,'full trace counts and direct initialization evidence')
require(len(load('falsification_budget_traces.json'))==63,'falsification retained full trace count')
for p in O.glob('*.csv'):
 with p.open() as f:require(len(list(csv.DictReader(f)))>0,'nonempty readable CSV '+p.name)
require('__ACTION__' not in (O/'RESULTS.md').read_text(),'report placeholders replaced')
verification={'status':'passed','checks':checks,'source_file_count':len(files),'frozen_auc_files_verified':len(d['files_sha256']),'model_api_calls':0,'new_policy_runs':0,'new_statistical_tests':0}
(O/'delivery_verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
manifest={'date':'2026-10-21','status':'complete_offline_audit','scope':'Three online suites plus their reused initial records; BH v1/v2 and Suzuki generation; 7 archived mechanism routes and 3 archived falsification routes. Not an account-wide cost audit.','model_api_calls':0,'new_policy_runs':0,'analysis_protocol_changes':0,'auc_inclusion_changes':0,'audit_checks':len(load('audit_checks.json')),'budget_checks':len(load('budget_audit_checks.json')),'independent_delivery_checks':len(checks),'source_files_unchanged':True,'auc_frozen_files_unchanged':len(d['files_sha256']),'known_limitations':['Missing online USD billing and some failed-response usage','1050 mechanism portfolio traces do not log initialization count directly','Only 63 falsification full trajectories retained; other jobs retain initial IDs, metrics and fingerprints','No new historical-route normalization admission'],'files_sha256':{str(p.relative_to(O)):h(p) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='DELIVERY_MANIFEST.json'}}
(O/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files_sha256'},ensure_ascii=False,indent=2))
