"""Read-only archive audit. No repository experiment modules or network clients imported."""
from pathlib import Path
import json,tarfile,hashlib,collections,re,statistics,socket
from decimal import Decimal
R=Path('/home/tangchao/projects/care2.0'); B=R/'experiments/care_replay'; O=Path(__file__).parent
SOURCES={}; MEMBERS={}; CHECKS=[]
def deny(*a,**k): raise RuntimeError('Network disabled in offline audit')
socket.socket=deny; socket.create_connection=deny

def digest(x): return hashlib.sha256(x).hexdigest()
def read(p):
 p=Path(p); x=p.read_bytes(); SOURCES[str(p)]=digest(x); return x
def js(p): return json.loads(read(p))
def write(name,x): (O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
class Archive:
 def __init__(self,p):
  self.p=p;read(p);self.t=tarfile.open(p);self.names=[m.name for m in self.t.getmembers() if m.isfile()]
 def raw(self,n):
  x=self.t.extractfile(n).read(); MEMBERS[str(self.p)+'::'+n]=digest(x);return x
 def j(self,n):return json.loads(self.raw(n))
 def suffix(self,s):return next(n for n in self.names if n.endswith(s))
def usage_sum(us):
 return {k:sum(int(u.get(k,0) or 0) for u in us) for k in ['prompt_tokens','completion_tokens','total_tokens']}
def check(ok,name):
 CHECKS.append({'check':name,'passed':bool(ok)})
 if not ok: raise AssertionError(name)

def online():
 suites=[];trajs=[];actions=[];calls=[];aliases=[]
 names=['2026-08-23-online-llm-repeated-confirmation-v1','2026-08-23-online-llm-repeated-confirmation-v2','2026-08-24-online-llm-bounded-authority-route-disjoint-confirmation-v1']
 inventory=js(B/'results/2026-10-20-submission-nonrsi-offline-preparation-v1/review_materials/archive_reanalysis_inventory.json')
 failures={(Path(x['archive']).name,x['case_id'],x['replicate_id']):x['failure_kind'] for x in inventory['failed_trajectory_inventory']}
 for name in names:
  a=Archive(R/'artifacts/replay-results'/('replay-'+name+'.tar.gz'))
  agg=a.j(a.suffix('/aggregate/repeated_confirmation.json')); root=a.suffix('/aggregate/repeated_confirmation.json').split('/aggregate/')[0]
  dirs=sorted(set(n.split('/attempts/')[0].rsplit('/',1)[0] if '/attempts/' not in n else n.split('/attempts/')[0] for n in a.names if re.search(r'/trajectory_\d+/',n)))
  # Canonical top-level trajectory and individual attempt copies are NOT separate API calls.
  dirs=sorted(set(re.match(r'(.*?/trajectory_\d+)/',n).group(1) for n in a.names if re.search(r'/trajectory_\d+/',n)))
  suite_start=len(trajs);action_start=len(actions);call_start=len(calls)
  for d in dirs:
   case=d.split('/')[-2];rep=int(d.split('_')[-1]); summary=a.j(d+'/summary.json') if d+'/summary.json' in a.names else None
   attempt_traces=[n for n in a.names if n.startswith(d+'/attempts/') and n.endswith('/llm_trace.jsonl')]
   canonical=d+'/llm_trace.jsonl';chosen=attempt_traces or ([canonical] if canonical in a.names else [])
   if attempt_traces and canonical in a.names:
    raw=a.raw(canonical);same=[n for n in attempt_traces if a.raw(n)==raw]
    check(bool(same),'canonical trace has exact attempt copy '+d)
    aliases.append({'canonical':canonical,'same_attempt':same,'reason':'canonical copy excluded from call counts'})
   if summary is None:
    error=a.j(d+'/error.json'); et=error.get('error_type',''); msg=str(error.get('error','')).lower()
    actual_kind='model_validation_failure' if et=='LLMValidationError' else 'operator_interrupted' if et=='OperatorInterruptedError' else 'inactive_key_401' if '401' in msg else 'cost_cap_429' if '429' in msg and ('limit' in msg or 'cap' in msg) and 'balance' not in msg else 'balance_429' if '429' in msg and 'balance' in msg else 'unclassified'
    check(actual_kind==failures.get((a.p.name,case,rep)),'actual failure classification '+d)
   ts=len(actions);cs=len(calls); total_requests=0; pending=0
   for n in chosen:
    events=[json.loads(x) for x in a.raw(n).decode().splitlines() if x.strip()]
    requests={};proposals={};final={};fallback={};round_calls={}
    for ix,e in enumerate(events):
     typ=e.get('event');ri=e.get('round_index'); key=(n,ri)
     if typ=='llm_round_request':requests[ri]=e
     if typ=='llm_round_proposal_response': proposals[ri]=e['normalized_decision'].get('selected_candidate_id')
     if typ=='llm_round_response':final[ri]=e['normalized_decision'].get('selected_candidate_id')
     if typ=='calibration_gate_target_gp_decision':fallback[ri]=e.get('selected_candidate')
     if typ in ['llm_round_request','llm_round_critic_request']:total_requests+=1
     if typ in ['llm_round_proposal_response','llm_round_critic_response','llm_round_error']:
      ats=e.get('api_attempts',[])
      if not ats and e.get('usage'):ats=[{'usage':e['usage'],'valid':None,'attempt':None}]
      if typ!='llm_round_error' and ats:
       check(usage_sum([x.get('usage',{}) for x in ats])==usage_sum([e['usage']]),'attempt usage matches event '+n+str(ix))
      for ai,x in enumerate(ats):
       u=x.get('usage',{});calls.append({'suite':name,'case':case,'replicate':rep,'trajectory_status':'completed' if summary else 'failed','trace':n,'event_index':ix,'event':typ,'round':ri,'attempt_index':x.get('attempt',ai),'valid':x.get('valid'),'usage':{k:u.get(k) for k in ['prompt_tokens','completion_tokens','total_tokens']},'known_cost_usd':u.get('cost'),'usage_details':{k:v for k,v in u.items() if k.endswith('_details')}})
     if typ=='target_reveal':
      req=requests.get(ri,{});ctx=req.get('prompt',{}).get('decision_context',{})
      gp=ctx.get('gp_default_candidate') or req.get('menu_diagnostics',{}).get('gp_incumbent_candidate')
      selected=e['selected_candidate'];is_llm=ri in final
      if is_llm:
       check(final[ri]==selected,'final decision executed '+n+str(ri));check(gp is not None,'GP comparator exists '+n+str(ri))
       check((selected!=gp)==(e.get('gp_rank_at_selection')!=1),'GP ID and rank agree '+n+str(ri))
      if ri in fallback:check(fallback[ri]==selected,'gate decision executed '+n+str(ri))
      actions.append({'suite':name,'case':case,'replicate':rep,'trajectory_status':'completed' if summary else 'failed','trace':n,'round':ri,'kind':'llm_decision' if is_llm else 'gate_fallback' if ri in fallback else 'other','gp_default':gp,'proposal':proposals.get(ri),'final_decision':final.get(ri),'executed':selected,'proposal_override':None if not is_llm else proposals.get(ri)!=gp,'final_override':None if not is_llm else selected!=gp,'critic_changed_choice':None if not is_llm else proposals.get(ri)!=selected,'gp_rank_at_execution':e.get('gp_rank_at_selection')})
    # Request events without a corresponding valid response are tracked, not assigned zero tokens.
    pending+=sum(e['event'] in ['llm_round_request','llm_round_critic_request'] for e in events)-sum(e['event'] in ['llm_round_proposal_response','llm_round_critic_response'] for e in events)
   aa=actions[ts:];cc=calls[cs:];u=usage_sum([c['usage'] for c in cc])
   row={'suite':name,'case':case,'replicate':rep,'status':'completed' if summary else 'failed','failure_kind':failures.get((a.p.name,case,rep)), 'trace_files':chosen,'logical_request_stages':total_requests,'stages_without_successful_response':pending,'recorded_response_attempts':len(cc),'executed_rounds':len(aa),'llm_decision_rounds':sum(x['kind']=='llm_decision' for x in aa),'gate_fallback_rounds':sum(x['kind']=='gate_fallback' for x in aa),'final_overrides':sum(x['final_override'] is True for x in aa),'proposal_overrides':sum(x['proposal_override'] is True for x in aa),'critic_changes':sum(x['critic_changed_choice'] is True for x in aa),'known_usage':u,'known_cost_usd':None,'upstream_initial_generation_cost_included':False}
   if summary:
    check(u==summary['usage'],'trace usage matches completed summary '+d)
    met=summary['metrics']['online_llm_scientist'];check(len(aa)==summary['actual_reveal_rounds'],'reveal count matches summary '+d)
    check(abs(row['final_overrides']/len(aa)-met['llm_gp_override_rate'])<1e-12,'override matches summary '+d)
    row.update({'model_recorded':summary['online_model'],'initial_model_recorded':summary['initial_model'],'initial_observations':met['initial_observations'],'requested_reveals':summary['requested_reveal_rounds'],'summary_path':d+'/summary.json','summary_usage':summary['usage']})
   trajs.append(row)
  tt=trajs[suite_start:];done=[x for x in tt if x['status']=='completed'];fail=[x for x in tt if x['status']=='failed']
  check(len(done)==agg['completed_trajectory_count'],'completed count '+name);check(len(fail)==agg['failed_trajectory_count'],'failed count '+name)
  expected=agg['expected_case_count']*agg['expected_replicates_per_case']
  sr={'suite':name,'protocol_complete':agg['protocol_complete'],'planned':expected,'completed':len(done),'failed':len(fail),'not_completed_or_failed_in_archive':expected-len(tt),'completed_usage':usage_sum([x['known_usage'] for x in done]),'failed_recorded_usage':usage_sum([x['known_usage'] for x in fail]),'all_recorded_usage_lower_bound':usage_sum([x['known_usage'] for x in tt]),'completed_logical_decisions':sum(x['llm_decision_rounds'] for x in done),'completed_proposal_overrides':sum(x['proposal_overrides'] for x in done),'completed_final_overrides':sum(x['final_overrides'] for x in done),'completed_critic_changes':sum(x['critic_changes'] for x in done),'completed_gate_fallbacks':sum(x['gate_fallback_rounds'] for x in done),'completed_recorded_response_attempts':sum(x['recorded_response_attempts'] for x in done),'completed_invalid_response_attempts':sum(c['valid'] is False for c in calls[call_start:] if c['trajectory_status']=='completed'),'failed_recorded_response_attempts':sum(x['recorded_response_attempts'] for x in fail),'failed_executed_rounds':sum(x['executed_rounds'] for x in fail),'known_cost_usd':None,'cost_limitation':'No complete billed USD evidence in audited traces; missing failed-call usage and reused initial-generation costs are not zero.'}
  suites.append(sr)
 write('online_suites.json',suites);write('online_trajectories.json',trajs);write('online_actions.json',actions);write('online_response_attempts.json',calls);write('online_trace_aliases.json',aliases)
 return suites

def chemistry():
 groups=[];allrows=[]
 dirs=['2026-10-20-bh-semantic-anonymization-v1-generation-runtime-amendment-v1','2026-10-20-bh-semantic-anonymization-v2-generation','2026-10-20-suzuki-continuation-amendment2-generation']
 seen=set()
 for dn in dirs:
  p=B/'results'/dn/'ledger.json';d=js(p);rows=d['attempts']
  for x in rows:
   rid=x.get('response_id');check(rid not in seen if rid else True,'distinct generation response '+str(rid))
   if rid:
    seen.add(rid)
    receipt=p.parent/'receipts'/x['identifier']/'response.json';resp=js(receipt)
    check(resp['id']==rid,'receipt identity '+dn+x['identifier'])
    check(resp['usage']==x['usage'],'receipt usage '+dn+x['identifier'])
    check(Decimal(str(resp['usage']['cost']))==Decimal(str(x['cost_usd'])),'receipt billed cost '+dn+x['identifier'])
    bill=receipt.with_name('billing.json')
    if not bill.exists():bill=receipt.with_name('response_usage_billing.json')
    billing=js(bill);check(billing['response_id']==rid and Decimal(billing['cost_usd'])==Decimal(str(x['cost_usd'])),'billing receipt '+dn+x['identifier'])
   row={k:x.get(k) for k in ['identifier','status','response_id','started_at','cost_usd','reservation_usd','usage']};row['group']=dn;allrows.append(row)
  us=[x['usage'] for x in rows if x.get('usage')];known=sum((Decimal(str(x['cost_usd'])) for x in rows if x.get('cost_usd') is not None),Decimal(0))
  check(known==Decimal(d.get('known_new_cost_usd',d.get('known_cost_usd'))),'ledger cost sums '+dn)
  groups.append({'group':dn,'actual_attempts_including_reused_prior_within_group':len(rows),'responses_with_usage':len(us),'status_counts':dict(collections.Counter(x['status'] for x in rows)),'usage':usage_sum(us),'known_new_cost_usd':str(known),'prior_cost_usd_not_added_again':d.get('prior_cost_usd'),'unknown_reservation_usd':d.get('unknown_reservation_usd','0'),'dollar_evidence':'archived API response / generation receipt, not account-wide invoice','upstream_model': 'openai/gpt-4o-mini'})
 # Assert earlier ledger entries were reused, not new calls. Match response identity, not prompt hashes.
 old=js(B/'results/2026-10-20-suzuki-second-dataset-v1-generation/ledger.json')
 new=js(B/'results'/dirs[2]/'ledger.json')
 oldids={x['response_id'] for x in old['attempts'] if x.get('response_id')};newids={x['response_id'] for x in new['attempts'] if x.get('response_id')}
 check(oldids<=newids,'Suzuki original receipts reused')
 oldbh=B/'results/2026-10-20-bh-semantic-anonymization-v1-generation/receipts/pair_00_labeled'
 for p in oldbh.glob('*.json'):
  if 'response' in p.name:
   z=js(p)
   if z.get('id'):check(z['id'] in seen,'BH first response reused')
 write('chemistry_generation_groups.json',groups);write('chemistry_generation_attempts.json',allrows)
 return groups

def initial_records():
 configs=['online_llm_repeated_confirmation_v1.json','online_llm_repeated_confirmation_v2.json','online_llm_bounded_authority_route_disjoint_confirmation_v1.json']
 mappings={};cfg_sources={}
 for cf in configs:
  d=js(B/'configs'/cf)
  for c in d['cases']:
   mappings.setdefault(c['initial_record'],[]).append({'suite_config':cf,'case':c['case_id']})
 archives=[Archive(R/'artifacts/replay-results'/n) for n in ['replay-2026-08-15-opus5-generalization-study.tar.gz','replay-2026-08-16-opus48-high-authority-chemistry-holdout-v1.tar.gz']]
 rows=[]
 for rel,uses in mappings.items():
  candidates=[(a,n) for a in archives for n in a.names if n.endswith('experiments/care_replay/'+rel)]
  check(bool(candidates),'initial record found in archive '+rel)
  a,n=candidates[0];raw=a.raw(n);d=json.loads(raw)
  if (B/rel).exists():check(read(B/rel)==raw,'initial local equals archive '+rel)
  u=usage_sum([x.get('usage',{}) for x in d.get('api_attempts',[])])
  check(u==d['usage'],'initial attempt usage '+rel)
  rows.append({'record':rel,'record_sha256':digest(raw),'archive':str(a.p),'member':n,'uses':uses,'model_as_recorded':d.get('model'),'usage':u,'response_attempts':len(d.get('api_attempts',[])),'cost_usd':None,'accounting':'One-time historical generation; reused in subsequent online searches, do not charge once per trajectory.'})
 write('online_initial_records.json',rows)
 result={'unique_initial_records':len(rows),'recorded_usage':usage_sum([x['usage'] for x in rows]),'recorded_response_attempts':sum(x['response_attempts'] for x in rows),'usd_known':None,'scope':'Historical one-time initial-generation records referenced by audited suite configs, not newly incurred online costs and not full development cost.'}
 write('online_initial_record_summary.json',result);return result

if __name__=='__main__':
 result={'online':online(),'chemistry':chemistry(),'reused_initial_records':initial_records()}
 write('audit_checks.json',CHECKS);write('source_manifest.json',{'files':SOURCES,'members':MEMBERS,'model_api_calls':0,'network':'blocked in audit process','new_policy_runs':0})
 print(json.dumps(result,ensure_ascii=False,indent=2))
