# AUC 可比性矩阵（离线盘点，尚未归一化）

32行＝原四固定任务＋五批化学实验＋23条蛋白路线；不是32个独立数据集。所有主行的uniform random正式分母均尚未认证。完整证据路径、种子范围、pool hash在同目录JSON/CSV。

| 条目 | 面板 | 池规模* | 起点＋后续 | 留出种子 | 记录内oracle | 随机搜索状态 |
|---|---|---:|---:|---:|---:|---|
| Fixed_BH | original_fixed | 3955 | 5＋10 | 500 | 100.0 | 未认证；需补参考期望 |
| Fixed_bandgap | original_fixed | 4604 | 5＋10 | 500 | 100.0 | 未认证；需补参考期望 |
| Fixed_FreeSolv | original_fixed | 642 | 5＋10 | 500 | 100.0 | 未认证；需补参考期望 |
| Fixed_Lipophilicity | original_fixed | 4200 | 5＋10 | 300 | 93.75 | 未认证；需补参考期望 |
| BH_pilot | recent_chemistry | 3955 | 5＋10 | 20 | 100.0 | 未认证；需补参考期望 |
| BH_scale | recent_chemistry | 3955 | 5＋10 | 100 | 100.0 | 未认证；需补参考期望 |
| BH_coverage | recent_chemistry | 3955 | 5＋10 | 100 | 100.0 | 未认证；需补参考期望 |
| BH_anon_v2 | recent_chemistry | 3955 | 5＋10 | 100 | 100.0 | 未认证；需补参考期望 |
| Suzuki_v1 | recent_chemistry | 5760 | 5＋10 | 100 | 100.0 | 未认证；需补参考期望 |
| A4_HUMAN_Seuma_2022__hash_domain | experiment3 | 2963 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| CAPSD_AAV2S_Sinai_2021__hash_domain | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| CAPSD_AAV2S_Sinai_2021__order_extrapolation | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| CATR_CHLRE_Tsuboyama_2023_2AMI__hash_domain | experiment3 | 381 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| CATR_CHLRE_Tsuboyama_2023_2AMI__order_extrapolation | experiment3 | 563 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| D7PM05_CLYGR_Somermeyer_2022__hash_domain | experiment3 | 2688 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| D7PM05_CLYGR_Somermeyer_2022__order_extrapolation | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| DLG4_HUMAN_Faure_2021__hash_domain | experiment3 | 1396 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| DLG4_HUMAN_Faure_2021__order_extrapolation | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| F7YBW8_MESOW_Aakre_2015__hash_domain | experiment3 | 1168 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| F7YBW8_MESOW_Aakre_2015__order_extrapolation | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| GCN4_YEAST_Staller_2018__hash_domain | experiment3 | 398 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| GCN4_YEAST_Staller_2018__order_extrapolation | experiment3 | 1007 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| HIS7_YEAST_Pokusaeva_2019__hash_domain | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| HIS7_YEAST_Pokusaeva_2019__order_extrapolation | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| PABP_YEAST_Melamed_2013__hash_domain | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| PHOT_CHLRE_Chen_2023__hash_domain | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| PHOT_CHLRE_Chen_2023__order_extrapolation | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| RASK_HUMAN_Weng_2022_abundance__hash_domain | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| RASK_HUMAN_Weng_2022_abundance__order_extrapolation | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| SPG1_STRSG_Wu_2016__hash_domain | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| SPG1_STRSG_Wu_2016__order_extrapolation | experiment3 | 5000 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |
| YAP1_HUMAN_Araya_2012__hash_domain | experiment3 | 2015 | 3＋12 | 200 | 未记录 | 未认证；需补参考期望 |

* 原四任务池规模为预期历史规模，尚未用归档完整有序候选集认证；近期化学规模来自冻结配置；蛋白来自冻结route结果，另有实际episode pool hash。encoded oracle只是final_best＋simple_regret的一致性，不等于本轮已核验全池最优。

同一条目内部可保留原来的配对差值；跨面板需先批准分母与汇总方式。R1/R2、GP、Never均不得替代uniform random。历史迁移预算冲突及额外纳入条件见REANALYSIS_PLAN.md第5节。
