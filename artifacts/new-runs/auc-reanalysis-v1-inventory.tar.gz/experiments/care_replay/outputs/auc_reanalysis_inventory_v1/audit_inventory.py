"""Read-only AUC inventory. No policy execution, normalization, or network access."""
from pathlib import Path
import csv,gzip,hashlib,io,json,tarfile,socket,collections,statistics
ROOT=Path('/home/tangchao/projects/care2.0'); B=ROOT/'experiments/care_replay'; R=ROOT/'artifacts/replay-results'; OUT=Path(__file__).parent
socket.socket=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('network disabled'))
inputs={}; members={}; metric_inventory=[]; baseline_candidates=[]; matrix=[]
def digest(x): return hashlib.sha256(x).hexdigest()
def read(p):
 data=p.read_bytes(); inputs[str(p)]=digest(data); return data
def jd(p): return json.loads(read(p))
def write(n,d): (OUT/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def inspect_metrics(rows,ref):
 groups=collections.defaultdict(list)
 for x in rows: groups[(x.get('dataset',x.get('target_dataset','unknown')),x.get('split','unspecified'),x.get('mode','unknown'))].append(x)
 gs=[]
 for (dataset,split,mode),items in sorted(groups.items()):
  seeds=sorted({int(x['seed']) for x in items if x.get('seed') not in [None,'']})
  oracle=[float(x['final_best'])+float(x['simple_regret']) for x in items if x.get('simple_regret') not in [None,'']]
  gs.append(dict(dataset=dataset,split=split,mode=mode,rows=len(items),seed_count=len(seeds),seed_min=min(seeds) if seeds else None,seed_max=max(seeds) if seeds else None,encoded_oracle_min=min(oracle) if oracle else None,encoded_oracle_max=max(oracle) if oracle else None))
 d=dict(reference=ref,rows=len(rows),groups=gs,uniform_random_present=any(g['mode']=='random' for g in gs));metric_inventory.append(d)
 if d['uniform_random_present']: baseline_candidates.append(d)
 return d
archives=sorted({p for p in R.glob('replay-2026-*.tar.gz') if p.name<'replay-2026-07-13'} | {R/'replay-2026-07-21-low-cost-llm-transfer.tar.gz',R/'replay-2026-07-21-cross-domain-semantic-skills.tar.gz',R/'replay-2026-07-24-source-outcome-transfer.tar.gz'})
for p in archives:
 read(p)
 with tarfile.open(p) as t:
  for m in t.getmembers():
   if not m.isfile():continue
   name=Path(m.name).name
   wanted=name.endswith('_metrics.csv') or name in ['run_manifest.json','pair_summary.csv','policy_summary.csv'] or (name.endswith('_summary.json') and 'surrogate' in name)
   if not wanted:continue
   data=t.extractfile(m).read();ref=str(p)+'::'+m.name;members[ref]=digest(data)
   if name.endswith('_metrics.csv'):
    rows=list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))));d=inspect_metrics(rows,ref)
    label=None
    if 'kernel_transfer_preselected_confirm_500seed' in name:label='Fixed_FreeSolv'
    if 'universal_schedule_lipophilicity_300seed' in name:label='Fixed_Lipophilicity'
    if 'semantic_highmw_confirm500' in name:label='Fixed_BH'
    if 'semantic_countertm_confirm500' in name:label='Fixed_bandgap'
    if label:
     held=[x for x in d['groups'] if x['split']=='heldout'];seeds=max(x['seed_count'] for x in held)
     matrix.append(dict(id=label,panel='original_fixed',pool_n={'Fixed_FreeSolv':642,'Fixed_Lipophilicity':4200,'Fixed_BH':3955,'Fixed_bandgap':4604}[label],pool_n_status='expected historical pool size; not certified against archived ordered candidates',init=5,rounds=10,heldout_seeds=seeds,seed_min=min(x['seed_min'] for x in held),seed_max=max(x['seed_max'] for x in held),scale='legacy adapter objective; not universal raw units',uniform_random='absent in selected run',oracle_status='encoded final_best+simple_regret; full-pool identity not yet certified',encoded_oracle=held[0]['encoded_oracle_min'],pool_identity='archive metrics and manifests; ordered ID/value hash not certified',initial_ids='nested audit reveals available; explicit initial IDs not established',dependency='seeds conditional on one selected rule/schedule',reference=ref))
   elif name=='policy_summary.csv':
    rr=[x for x in csv.DictReader(io.StringIO(data.decode())) if x.get('mode')=='random']
    if rr:baseline_candidates.append(dict(reference=ref,aggregate_only=True,rows=rr))
current=[('BH_pilot','2026-10-18-bh-random-rule-controls-pilot-v1-rerun'),('BH_scale','2026-10-18-bh-random-rule-controls-scale-v1'),('BH_coverage','2026-10-19-bh-coverage-matched-rule-controls-v1'),('BH_anon_v2','2026-10-20-bh-semantic-anonymization-v2-evaluation-recovery-1'),('Suzuki_v1','2026-10-20-suzuki-continuation-amendment2-evaluation')]
for label,folder in current:
 p=B/'results'/folder
 conf=jd(p/'config.json') if (p/'config.json').exists() else jd(B/'configs/suzuki_second_dataset_v1.json')
 for file in ['manifest.json','selection_lock.json','protocol_lock.json','frozen_protocol.json','integrity.json','completion.json']:
  if (p/file).exists():read(p/file)
 for phase in ['calibration','heldout']:
  f=p/(phase+'_metrics.csv');f=f if f.exists() else p/(phase+'_metrics.json');data=read(f)
  rows=list(csv.DictReader(io.StringIO(data.decode()))) if f.suffix=='.csv' else json.loads(data)
  d=inspect_metrics(rows,str(f))
  if phase=='heldout':held=d
 matrix.append(dict(id=label,panel='recent_chemistry',pool_n=conf['expected_candidate_count'],pool_n_status='frozen config',init=conf['initial_observations'],rounds=conf['reveal_rounds'],heldout_seeds=conf['heldout_seed_count'],seed_min=conf['heldout_seed_start'],seed_max=conf['heldout_seed_start']+conf['heldout_seed_count']-1,scale='legacy normalized reaction yield score',uniform_random='present' if held['uniform_random_present'] else 'absent; R1/R2 and GP are not uniform random',oracle_status='encoded oracle; verify against exact frozen full pool',encoded_oracle=held['groups'][0]['encoded_oracle_min'],pool_identity='frozen source/data manifests; requires canonical ordered ID/value export',initial_ids='reveal traces plus frozen deterministic initializer; reconstruct and verify',dependency='shared seeds crossed with libraries/pairs; selected aliases reused',reference=str(p)))
routes=list(csv.DictReader(io.StringIO(read(B/'outputs/experiment3_execution_v1/route_results.csv').decode())))
expchecks=[]
for route in routes:
 root=B/'outputs/experiment3_execution_v1/episodes'/route['route']/'heldout'
 seeds=[];hashes=set();maxdiff=0.;initial_match=True;ntrace=set();nobs=set()
 for f in sorted(root.glob('*.json')):
  d=jd(f)['payload'];seeds.append(d['context']['seed']);hashes.add(d['context']['pool_ids_sha256']);r=d['result']
  initial_match &= r['Always']['observed_indices'][:3]==r['Never']['observed_indices'][:3]
  for x in r.values():
   ntrace.add(len(x['best_trace']));nobs.add(x['observations']);maxdiff=max(maxdiff,abs(statistics.mean(x['best_trace'])-x['auc_full_precision']))
 expchecks.append(dict(route=route['route'],files=len(seeds),pool_id_hashes=sorted(hashes),initial_always_never_match=initial_match,trace_lengths=sorted(ntrace),observations=sorted(nobs),max_auc_reconstruction_error=maxdiff))
 matrix.append(dict(id=route['route'],panel='experiment3',pool_n=int(route['target_n']),pool_n_status='frozen route results and episode pool hash',init=3,rounds=12,heldout_seeds=len(seeds),seed_min=min(seeds),seed_max=max(seeds),scale='100*(raw-source_fit_median)/source_fit_IQR; legacy primary reports source IQR',uniform_random='absent; Never is target GP',oracle_status='not in episode records; needs analysis-only full frozen subpool outcome export',encoded_oracle=None,pool_identity=','.join(sorted(hashes)),initial_ids='all heldout Always/Never initial indices explicitly recorded and equal',dependency='paired seeds; 23 routes within 13 groups; target pools may overlap',reference=str(root)))
for p in [B/'SUBMISSION_NONRSI_ROADMAP_20261021.md',B/'protocols/experiment3_execution_v1/FREEZE.json',B/'scripts/run_surrogate_baselines.py']:
 if p.exists():read(p)
assert len(matrix)==32
assert all(x['files']==200 and x['initial_always_never_match'] and x['trace_lengths']==[12] and x['observations']==[15] and x['max_auc_reconstruction_error']<1e-9 for x in expchecks)
assert len({r['group'] for r in routes})==13
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in inputs.items())
write('metric_inventory.json',metric_inventory);write('random_baseline_candidates.json',baseline_candidates);write('comparability_matrix.json',matrix);write('experiment3_trace_checks.json',expchecks)
with (OUT/'comparability_matrix.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(matrix[0]));w.writeheader();w.writerows(matrix)
write('source_manifest.json',dict(audit_script_sha256=digest(Path(__file__).read_bytes()),inputs=inputs,archive_members=members,inputs_unchanged=True,network_disabled=True,model_api_calls=0,new_policy_runs=0,normalized_effects_computed=False))
write('audit_summary.json',dict(matrix_rows=len(matrix),archive_count=len(archives),metric_tables=len(metric_inventory),random_candidate_tables=len(baseline_candidates),experiment3_heldout_episode_files=sum(x['files'] for x in expchecks),experiment3_checks_passed=True,scope='Original four fixed-rule headlines; five recent chemistry suites; 23 protein routes. Historical baseline search through 2026-07-12 plus specified headline/source archives. No claim of exhaustive absence outside these inputs.'))
print(json.dumps(json.loads((OUT/'audit_summary.json').read_text()),indent=2))
