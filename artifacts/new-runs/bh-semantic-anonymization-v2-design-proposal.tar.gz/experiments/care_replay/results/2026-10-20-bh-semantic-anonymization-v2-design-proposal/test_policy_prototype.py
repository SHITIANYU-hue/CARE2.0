"""Offline executable specification, with V1 fixtures clearly limited to tests."""
from copy import deepcopy
from decimal import Decimal
import builtins
import io
import json
import os
from pathlib import Path
import socket
import sys
import urllib.request
from unittest.mock import patch

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import policy_prototype as policy

ANCHOR = "shared_calibration_only_target_anchor_TEST_FIXTURE"
V1 = policy.ROOT / "experiments/care_replay/results/2026-10-20-bh-semantic-anonymization-v1-generation-runtime-amendment-v1"


@pytest.fixture(autouse=True)
def block_network_and_any_key_read(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Offline policy tests prohibit network and key reads")
    for name in ("connect", "connect_ex"):
        monkeypatch.setattr(socket.socket, name, forbidden)
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(socket, "getaddrinfo", forbidden)
    monkeypatch.setattr(urllib.request, "urlopen", forbidden)
    real_builtin_open, real_io_open, real_os_open = builtins.open, io.open, os.open
    def is_secret_path(path):
        if isinstance(path, int):
            return False
        text = os.fsdecode(path).lower()
        name = Path(text).name
        return (name.startswith(".env") or name in ("credentials", "environ")
                or any(part in name for part in ("api_key", "api-key", "secret", "token")))
    def checked_open(original):
        def guarded(path, *args, **kwargs):
            if is_secret_path(path):
                return forbidden()
            return original(path, *args, **kwargs)
        return guarded
    monkeypatch.setattr(builtins, "open", checked_open(real_builtin_open))
    monkeypatch.setattr(io, "open", checked_open(real_io_open))
    monkeypatch.setattr(os, "open", checked_open(real_os_open))
    environ_type = type(os.environ)
    real_getitem = environ_type.__getitem__
    def env_getitem(self, key):
        if any(word in str(key).upper() for word in ("KEY", "TOKEN", "SECRET")):
            return forbidden()
        return real_getitem(self, key)
    monkeypatch.setattr(environ_type, "__getitem__", env_getitem)


@pytest.fixture
def material():
    # New aliases for synthetic offline fixtures only: no frozen V2 generation.
    return policy.contract.build_pair(0, 202610207000)


@pytest.fixture
def library():
    record = json.loads(policy.contract.RECORD.read_text(encoding="utf-8"))
    result = {"skills": deepcopy(record["normalized_skills"])}
    for skill in result["skills"]:
        for rule in skill["rules"]:
            rule["conditions"] = dict(rule["conditions"])
    return result


def envelope(library, material, arm):
    content = deepcopy(library)
    if arm == "anonymous":
        mapping = material["private_mapping"]["forward"]
        for skill in content["skills"]:
            for rule in skill["rules"]:
                rule["conditions"] = {mapping["fields"][f]: mapping["values"][v]
                                      for f, v in rule["conditions"].items()}
    return {"id": "offline-synthetic-fixture-NOT-A-GENERATION",
            "object": "chat.completion", "model": "openai/gpt-4o-mini", "provider": "OpenAI",
            "usage": {"cost": 0, "is_byok": False},
            "choices": [{"finish_reason": "stop", "message": {
                "role": "assistant", "content": json.dumps(content, allow_nan=False)}}]}


def pins(response, material):
    return {"response_sha256": policy.object_sha256(response),
            "material_sha256": policy.object_sha256(material)}


def classify(response, material, arm, **kwargs):
    return policy.classify_generation(response, arm, material, anchor_mode=ANCHOR,
                                      **pins(response, material), **kwargs)


@pytest.mark.parametrize("arm", policy.ARMS)
def test_valid_preserves_entire_five_strategy_library(material, library, arm):
    response = envelope(library, material, arm)
    before = deepcopy(response)
    decision = classify(response, material, arm)
    assert decision.status == policy.VALID and decision.library == library
    assert [len(skill["rules"]) for skill in decision.library["skills"]] == [2, 1, 1, 1, 1]
    assert decision.reasons == () and response == before


@pytest.mark.parametrize("arm", policy.ARMS)
def test_nine_contract_failures_have_symmetric_whole_library_fallback(material, library, arm):
    cases = ("source_only_field", "wrong_field_value", "missing_parameter", "extra_key",
             "too_few_skills", "wrong_rule_count", "duplicate_id", "boolean_number", "text_limit")
    response = envelope(library, material, arm)
    for case in cases:
        changed = deepcopy(response)
        payload = json.loads(changed["choices"][0]["message"]["content"])
        skill = payload["skills"][0]
        mapping = material["private_mapping"]["forward"]
        if case == "source_only_field":
            field = "reactant_1_halide_type" if arm == "labeled" else mapping["fields"]["reactant_1_halide_type"]
            value = "chloride" if arm == "labeled" else mapping["values"]["chloride"]
            skill["rules"][0]["conditions"] = {field: value}
        elif case == "wrong_field_value":
            field = "ligand_mw_bin" if arm == "labeled" else mapping["fields"]["ligand_mw_bin"]
            value = "chloride" if arm == "labeled" else mapping["values"]["chloride"]
            skill["rules"][0]["conditions"] = {field: value}
        elif case == "missing_parameter":
            del skill["ridge"]
        elif case == "extra_key":
            skill["uncontracted"] = True
        elif case == "too_few_skills":
            payload["skills"].pop()
        elif case == "wrong_rule_count":
            skill["rules"].pop()
        elif case == "duplicate_id":
            payload["skills"][1]["skill_id"] = skill["skill_id"]
        elif case == "boolean_number":
            skill["ridge"] = True
        elif case == "text_limit":
            skill["hypothesis"] = "x" * 801
        changed["choices"][0]["message"]["content"] = json.dumps(payload)
        decision = classify(changed, material, arm)
        assert decision.status == policy.INVALID, case
        assert decision.library is None and decision.anchor_mode == ANCHOR, case
        assert decision.reasons[0] == "invalid_library_contract", case


@pytest.mark.parametrize("arm", policy.ARMS)
def test_bad_json_duplicates_nonfinite_and_markdown_are_invalid_not_repaired(material, library, arm):
    for text in ('{"skills":[],"skills":[]}', '{"x":NaN}', '{"x":1e999}',
                 '```json\n{}\n```', 'not json', '[1,2]', 'null'):
        response = envelope(library, material, arm)
        response["choices"][0]["message"]["content"] = text
        decision = classify(response, material, arm)
        assert decision.status == policy.INVALID and decision.library is None
        assert response["choices"][0]["message"]["content"] == text


@pytest.mark.parametrize("arm", policy.ARMS)
def test_known_output_termination_failures_are_invalid(material, library, arm):
    for case in ("length", "content_filter", "refusal", "tool_calls", "stop_tool_calls", "empty", "null"):
        response = envelope(library, material, arm)
        choice = response["choices"][0]
        if case in ("length", "content_filter"):
            choice["finish_reason"] = case
        elif case == "refusal":
            choice["message"]["refusal"] = "offline refusal fixture"
        elif case in ("tool_calls", "stop_tool_calls"):
            choice["message"]["tool_calls"] = [{"id": "offline", "type": "function", "function": {"name": "unused", "arguments": "{}"}}]
            if case == "tool_calls":
                choice["finish_reason"] = "tool_calls"
        else:
            choice["message"]["content"] = " \n " if case == "empty" else None
        decision = classify(response, material, arm)
        assert decision.status == policy.INVALID and decision.library is None, case


@pytest.mark.parametrize("arm", policy.ARMS)
def test_unknown_finish_bad_envelope_or_unestablished_source_halt(material, library, arm):
    for case in ("unknown_finish", "missing_choice", "two_choices", "bad_message", "bad_role",
                 "bad_content", "bad_refusal", "bad_tools", "bare_tool_finish",
                 "missing_id", "wrong_provider", "wrong_model", "api_error"):
        response = envelope(library, material, arm)
        choice = response["choices"][0]
        if case == "unknown_finish": choice["finish_reason"] = "future_unknown_reason"
        elif case == "missing_choice": response["choices"] = []
        elif case == "two_choices": response["choices"].append(deepcopy(choice))
        elif case == "bad_message": choice["message"] = []
        elif case == "bad_role": choice["message"]["role"] = "tool"
        elif case == "bad_content": choice["message"]["content"] = {"text": "not text"}
        elif case == "bad_refusal": choice["message"]["refusal"] = True
        elif case == "bad_tools": choice["message"]["tool_calls"] = "not a list"
        elif case == "bare_tool_finish": choice["finish_reason"] = "tool_calls"
        elif case == "missing_id": response.pop("id")
        elif case == "wrong_provider": response["provider"] = "Unknown"
        elif case == "wrong_model": response["model"] = "another-model"
        elif case == "api_error": response["error"] = {"code": 500}
        with pytest.raises(policy.Halt): classify(response, material, arm)


@pytest.mark.parametrize("arm", policy.ARMS)
def test_billing_failure_halts_even_for_invalid_model_content(material, library, arm):
    for usage in ({}, {"cost": 0}, {"cost": 0, "is_byok": True},
                  {"cost": -1, "is_byok": False}, {"cost": "NaN", "is_byok": False},
                  {"cost": True, "is_byok": False}, []):
        response = envelope(library, material, arm)
        response["usage"] = usage
        response["choices"][0]["finish_reason"] = "length"
        with pytest.raises(policy.Halt): classify(response, material, arm)
    response = envelope(library, material, arm)
    response["usage"]["cost"] = 0.1
    with pytest.raises(policy.Halt):
        classify(response, material, arm, receipt_cost_limit=Decimal("0.045"))


@pytest.mark.parametrize("arm", policy.ARMS)
def test_pins_and_material_errors_never_become_invalid_model_output(material, library, arm):
    response = envelope(library, material, arm)
    response["choices"][0]["finish_reason"] = "length"
    expected = pins(response, material)
    response["usage"]["cost"] = 0.001
    with pytest.raises(policy.Halt, match="response integrity"):
        policy.classify_generation(response, arm, material, anchor_mode=ANCHOR, **expected)
    corrupted = deepcopy(material)
    corrupted["private_mapping"]["inverse"]["fields"].pop(next(iter(corrupted["private_mapping"]["inverse"]["fields"])))
    with pytest.raises(policy.Halt, match="pair material"):
        classify(response, corrupted, arm)
    with patch.object(policy.contract, "build_pair", side_effect=ValueError("fixture builder fault")):
        with pytest.raises(policy.Halt, match="builder"):
            classify(response, material, arm)


@pytest.mark.parametrize("arm", policy.ARMS)
def test_internal_validator_exceptions_always_halt(material, library, arm):
    response = envelope(library, material, arm)
    for error in (policy.contract.ValidationError(["Invalid pair material"]),
                  RuntimeError("internal decoder fault")):
        with patch.object(policy.contract, "validate_and_decode", side_effect=error):
            with pytest.raises(policy.Halt, match="decoder/internal"):
                classify(response, material, arm)
    with patch.object(policy.contract, "strict_validate_library", side_effect=RuntimeError("validator bug")):
        with pytest.raises(policy.Halt, match="contract-validator"):
            classify(response, material, arm)
    with patch.object(policy.contract, "parse_strict_json", side_effect=RuntimeError("parser bug")):
        # build_pair also uses this parser: either material HALT or parser HALT is correct.
        with pytest.raises(policy.Halt): classify(response, material, arm)
    dropped = deepcopy(library)
    dropped["skills"].pop()
    with patch.object(policy.contract, "validate_and_decode", return_value=dropped):
        with pytest.raises(policy.Halt, match="decoder/internal"):
            classify(response, material, arm)


def test_twenty_slots_include_invalids_once_without_repair_or_replacement(library):
    order = [(i, arm) for i in range(10) for arm in policy.ARMS]
    batch = policy.TwentySlotPrototype(order, ANCHOR)
    for pair, arm in order:
        material = policy.contract.build_pair(pair, 202610207000 + pair)
        response = envelope(library, material, arm)
        invalid = (pair % 2 == 0 and arm == "anonymous") or (pair == 4 and arm == "labeled")
        if invalid: response["choices"][0]["message"]["content"] = ""
        decision = batch.consume(pair, arm, response, material, **pins(response, material))
        assert decision.status == (policy.INVALID if invalid else policy.VALID)
        assert (decision.library is None) == invalid
    assert batch.state == "COMPLETE" and len(batch.records) == 20
    assert sum(r["status"] == policy.INVALID for r in batch.records) == 6
    assert [(r["pair_index"], r["arm"]) for r in batch.records] == order
    with pytest.raises(policy.Halt, match="terminal"):
        batch.consume(0, "labeled", response, material, **pins(response, material))
    assert len(batch.records) == 20


def test_halt_is_terminal_and_invalid_slot_cannot_be_resampled(material, library):
    order = [(i, arm) for i in range(10) for arm in policy.ARMS]
    batch = policy.TwentySlotPrototype(order, ANCHOR)
    response = envelope(library, material, "labeled")
    response["choices"][0]["finish_reason"] = "unknown"
    with pytest.raises(policy.Halt):
        batch.consume(0, "labeled", response, material, **pins(response, material))
    assert batch.state == "HALTED" and len(batch.records) == 1
    with pytest.raises(policy.Halt, match="terminal"):
        batch.consume(0, "anonymous", response, material, **pins(response, material))
    assert len(batch.records) == 1
    batch = policy.TwentySlotPrototype(order, ANCHOR)
    response["choices"][0].update(finish_reason="length")
    batch.consume(0, "labeled", response, material, **pins(response, material))
    with pytest.raises(policy.Halt, match="next prespecified"):
        batch.consume(0, "labeled", response, material, **pins(response, material))
    assert batch.state == "HALTED" and len(batch.records) == 1


def test_common_anchor_gives_exact_zero_when_both_arms_are_invalid(material, library):
    decisions = []
    for arm in policy.ARMS:
        response = envelope(library, material, arm)
        response["choices"][0]["message"]["content"] = ""
        decisions.append(classify(response, material, arm))
    assert policy.contrast_from_supplied_values(*decisions, anchor_value=61.25,
                                               labeled_selected_value=99, anonymous_selected_value=1) == 0
    valid = classify(envelope(library, material, "labeled"), material, "labeled")
    assert policy.contrast_from_supplied_values(valid, decisions[1], anchor_value=61.25,
                                               labeled_selected_value=64.25) == 3


def test_real_v1_failed_response_is_fixture_only_and_not_silently_remapped():
    material = json.loads((V1 / "input_snapshot/pairs/pair_05.json").read_text())
    response = json.loads((V1 / "receipts/pair_05_anonymous/response.json").read_text())
    before = deepcopy(response)
    decision = classify(response, material, "anonymous")
    assert decision.status == policy.INVALID and decision.library is None
    assert "skills[2].rules[0]: unknown field/value" in decision.reasons
    assert response == before
    assert json.loads(response["choices"][0]["message"]["content"])["skills"][2]["rules"][0]["conditions"] == {"F19": "V10"}


def test_offline_guards_block_network_and_key_reads_before_access():
    with pytest.raises(AssertionError): socket.create_connection(("127.0.0.1", 443))
    with pytest.raises(AssertionError): (policy.ROOT / ".env").read_text()
    with pytest.raises(AssertionError): os.getenv("OPENROUTER_API_KEY")
