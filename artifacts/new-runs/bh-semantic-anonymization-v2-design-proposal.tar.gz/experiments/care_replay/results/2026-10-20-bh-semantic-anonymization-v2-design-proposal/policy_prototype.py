"""OFFLINE REVIEW PROTOTYPE: v2 library validity and whole-library fallback.

This is not an API executor or a frozen experimental protocol. No requests,
credentials, generation retries, library repairs, or replay occur here. Pins are
canonical-JSON SHA256 values supplied by a trusted caller; an eventual executor
must establish transport provenance and persist original receipt bytes itself.
V1 records may be used as test fixtures only, never as new v2 generations.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "experiments/care_replay/scripts"))
import paired_semantic_anonymization as contract

VALID = "VALID"
INVALID = "INVALID_ANCHOR_FALLBACK"
ARMS = ("labeled", "anonymous")


class Halt(RuntimeError):
    """A protocol, provenance, billing, material or internal failure; stop."""


def object_sha256(value: Any) -> str:
    """Canonical object hash; distinct from the original receipt byte hash."""
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":"), allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class Decision:
    status: str
    arm: str
    anchor_mode: str
    cost_usd: str
    reasons: tuple[str, ...]
    # INVALID always has library=None; no partial or repaired library survives.
    library: dict[str, Any] | None


def _pin(value: Any, expected: str, label: str) -> None:
    try:
        if not isinstance(expected, str) or len(expected) != 64 or object_sha256(value) != expected:
            raise ValueError("canonical object hash mismatch")
    except Exception as exc:
        raise Halt(f"{label} integrity failure") from exc


def _check_material(material: dict[str, Any], expected_sha256: str) -> None:
    _pin(material, expected_sha256, "pair material")
    try:
        # This checks all mappings, frozen record/code hashes and both catalogs,
        # before any model-content failure can be labeled INVALID.
        rebuilt = contract.build_pair(material["pair_index"], material["alias_seed"])
        if object_sha256(rebuilt) != object_sha256(material):
            raise ValueError("material differs from deterministic builder")
    except Exception as exc:
        raise Halt("pair material or builder failed validation") from exc


def _billing(response: dict[str, Any], limit: Decimal | None) -> Decimal:
    usage = response.get("usage")
    if not isinstance(usage, dict) or usage.get("is_byok") is not False:
        raise Halt("billing/BYOK evidence is missing or incompatible")
    value = usage.get("cost")
    if value is None or isinstance(value, bool):
        raise Halt("billing cost is missing or invalid")
    try:
        cost = Decimal(str(value))
        if not cost.is_finite() or cost < 0:
            raise ValueError("invalid cost")
        if limit is not None:
            if not isinstance(limit, Decimal) or not limit.is_finite() or limit < 0:
                raise ValueError("invalid caller-provided cost limit")
            if cost > limit:
                raise ValueError("receipt exceeds caller-provided cost limit")
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise Halt("billing cost failed validation") from exc
    return cost


def classify_generation(response: Any, arm: str, pair_material: dict[str, Any], *,
                        response_sha256: str, material_sha256: str,
                        anchor_mode: str, expected_model: str = "openai/gpt-4o-mini",
                        expected_provider: str = "OpenAI",
                        receipt_cost_limit: Decimal | None = None) -> Decision:
    """VALID, whole-library INVALID, or Halt; never infer a repair or retry.

    Source/billing/material checks precede model-output classification. A strict
    parser/contract rejection is INVALID. Once those checks pass, *any* failure
    in the final decoder is internal/protocol failure and is HALT, including its
    ValidationError class, which also represents material errors in the v1 API.
    """
    if arm not in ARMS or not isinstance(anchor_mode, str) or not anchor_mode:
        raise Halt("unknown arm or missing shared anchor")
    _pin(response, response_sha256, "response")
    if (not isinstance(response, dict) or response.get("object") != "chat.completion"
            or not isinstance(response.get("id"), str) or not response["id"]
            or response.get("model") != expected_model
            or response.get("provider") != expected_provider or response.get("error")):
        raise Halt("response provenance/envelope cannot be established")
    cost = _billing(response, receipt_cost_limit)
    _check_material(pair_material, material_sha256)
    choices = response.get("choices")
    if not isinstance(choices, list) or len(choices) != 1 or not isinstance(choices[0], dict):
        raise Halt("response must have exactly one well-formed choice")
    choice = choices[0]
    message = choice.get("message")
    if (choice.get("error") or not isinstance(message, dict)
            or message.get("role") != "assistant"):
        raise Halt("malformed choice/message envelope")
    reason = choice.get("finish_reason")
    if reason not in ("stop", "length", "content_filter", "tool_calls"):
        raise Halt("unknown or unsupported finish_reason")
    refusal, tools, content = message.get("refusal"), message.get("tool_calls"), message.get("content")
    if refusal is not None and not isinstance(refusal, str):
        raise Halt("malformed refusal envelope")
    if tools is not None and not isinstance(tools, list):
        raise Halt("malformed tool-call envelope")
    if content is not None and not isinstance(content, str):
        raise Halt("malformed text-content envelope")
    if reason == "tool_calls" and not tools:
        raise Halt("tool-call termination without returned tool calls")

    def invalid(*reasons: str) -> Decision:
        return Decision(INVALID, arm, anchor_mode, str(cost), tuple(reasons), None)

    if reason in ("length", "content_filter"):
        return invalid("finish_reason:" + reason)
    if refusal:
        return invalid("model_refusal")
    if tools:
        return invalid("returned_tool_calls")
    if content is None or not content.strip():
        return invalid("empty_text")
    try:
        payload = contract.parse_strict_json(content)
    except contract.ValidationError as exc:
        return invalid("invalid_json", *exc.errors)
    except Exception as exc:
        raise Halt("unexpected parser failure") from exc
    try:
        catalog = pair_material["arms"][arm]["payload"]["target"]["public_semantic_fields"]
        errors = contract.strict_validate_library(payload, catalog)
        if not isinstance(errors, list) or any(not isinstance(item, str) for item in errors):
            raise TypeError("invalid validator return type")
    except Exception as exc:
        raise Halt("unexpected contract-validator failure") from exc
    if errors:
        return invalid("invalid_library_contract", *errors)
    try:
        decoded = contract.validate_and_decode(content, arm, pair_material)
        # A second explicit check prevents an internal decoder from dropping data.
        labeled_catalog = pair_material["arms"]["labeled"]["payload"]["target"]["public_semantic_fields"]
        if contract.strict_validate_library(decoded, labeled_catalog):
            raise ValueError("decoded library failed its contract")
        expected = deepcopy(payload)
        if arm == "anonymous":
            inverse = pair_material["private_mapping"]["inverse"]
            for skill in expected["skills"]:
                for rule in skill["rules"]:
                    rule["conditions"] = {inverse["fields"][f]: inverse["values"][v]
                                          for f, v in rule["conditions"].items()}
        if decoded != expected:
            raise ValueError("decoder changed output beyond condition-label decoding")
    except Exception as exc:
        raise Halt("decoder/internal validation failed after valid output checks") from exc
    return Decision(VALID, arm, anchor_mode, str(cost), (), decoded)


class TwentySlotPrototype:
    """In-memory logical-slot specification only; not durable execution state.

    All 20 prespecified slots are consumed once, whether VALID or INVALID. HALT
    is terminal and consumes the affected receipt's slot. No hidden retry,
    substitution, partial-library extraction or successful-only filtering.
    """
    def __init__(self, order: list[tuple[int, str]], anchor_mode: str):
        expected = {(p, a) for p in range(10) for a in ARMS}
        try:
            if (len(order) != 20 or set(order) != expected
                    or any(type(p) is not int for p, _ in order)):
                raise ValueError("wrong slot inventory")
        except Exception as exc:
            raise Halt("exactly twenty distinct pair/arm slots are required") from exc
        if not isinstance(anchor_mode, str) or not anchor_mode:
            raise Halt("a common calibration-selected anchor is required")
        self.order = tuple(order)
        self.anchor_mode = anchor_mode
        self.state = "READY"
        self.records: list[dict[str, Any]] = []

    def consume(self, pair_index: int, arm: str, response: Any,
                pair_material: dict[str, Any], **pins_and_constraints: Any) -> Decision:
        if self.state in ("HALTED", "COMPLETE"):
            raise Halt("terminal batch; no automatic continuation or retry")
        if (pair_index, arm) != self.order[len(self.records)]:
            self.state = "HALTED"
            raise Halt("request does not match the next prespecified slot")
        record = {"pair_index": pair_index, "arm": arm, "status": "CONSUMED"}
        self.records.append(record)
        try:
            if pair_material.get("pair_index") != pair_index:
                raise Halt("material belongs to a different pair")
            decision = classify_generation(response, arm, pair_material,
                                           anchor_mode=self.anchor_mode, **pins_and_constraints)
        except Exception as exc:
            record["status"] = "HALT"
            self.state = "HALTED"
            if isinstance(exc, Halt):
                raise
            raise Halt("unexpected slot-processing failure") from exc
        record.update(status=decision.status, decision=decision)
        self.state = "COMPLETE" if len(self.records) == 20 else "READY"
        return decision


def contrast_from_supplied_values(labeled: Decision, anonymous: Decision, *,
                                  anchor_value: float, labeled_selected_value: float | None = None,
                                  anonymous_selected_value: float | None = None) -> float:
    """Pure arithmetic on supplied numbers; no replay, selection or metric load."""
    if (labeled.arm != "labeled" or anonymous.arm != "anonymous"
            or labeled.anchor_mode != anonymous.anchor_mode):
        raise Halt("paired contrast requires one common anchor and both arms")
    def value(decision: Decision, selected: float | None) -> float:
        if decision.status not in (VALID, INVALID):
            raise Halt("cannot analyze an unfinished or halted slot")
        chosen = anchor_value if decision.status == INVALID else selected
        if type(chosen) not in (int, float) or not math.isfinite(chosen):
            raise Halt("finite supplied comparison value is required")
        return float(chosen)
    return value(labeled, labeled_selected_value) - value(anonymous, anonymous_selected_value)
