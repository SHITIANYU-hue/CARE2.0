"""Plot completed, audited frozen results without estimating new effects."""
from pathlib import Path
import argparse, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

parser = argparse.ArgumentParser()
parser.add_argument("--evaluation", type=Path, required=True)
parser.add_argument("--audit", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
assert json.loads((args.evaluation / "summary.json").read_text())["status"] == "complete"
assert json.loads(args.audit.read_text())["status"] == "PASS"
a = json.loads((args.evaluation / "analysis.json").read_text())
m = json.loads((args.evaluation / "manifest.json").read_text())
primary = a["primary_all_pairs_auc"]
fig, axes = plt.subplots(1, 2, figsize=(12, 6.2), gridspec_kw={"width_ratios": [1.05, 1]})
blue, orange, grey = "#245b86", "#c56624", "#545b65"
ax = axes[0]
for i, value in enumerate(primary["pair_mean_deltas"]):
    fallback = m["outcomes"][f"pair_{i:02d}_anonymous"]["status"] != "VALID"
    ax.hlines(i, min(0, value), max(0, value), color=orange if fallback else blue, alpha=.55, lw=2)
    ax.scatter(value, i, color=orange if fallback else blue, s=42, zorder=3)
ax.set_yticks(range(10), [f"Pair {i:02d}" for i in range(10)])
ax.invert_yaxis()
ax.set_title("Each generated pair", loc="left", fontsize=12, fontweight="bold")
fig.legend(handles=[Line2D([], [], color=blue, marker="o", linestyle="", label="Both libraries valid"),
                   Line2D([], [], color=orange, marker="o", linestyle="", label="Anonymous library fallback")],
          loc="lower left", bbox_to_anchor=(.06, .075), frameon=False, fontsize=9, ncol=2)
ax = axes[1]
for y, (label, endpoint) in enumerate([("Primary (all 10 pairs)", primary), ("After gate (secondary)", a["secondary_gated_auc"])]):
    mean, interval = endpoint["mean_delta"], endpoint["interval"]
    ax.errorbar(mean, y, xerr=[[mean-interval["lower"]], [interval["upper"]-mean]],
                fmt="o", color=blue if y == 0 else grey, capsize=4, lw=2, markersize=6)
    ax.annotate(f"{mean:+.3f} [{interval['lower']:+.3f}, {interval['upper']:+.3f}]",
                (mean, y), xytext=(0, 12), textcoords="offset points", ha="center", fontsize=8)
blocks = primary["ordered_seed_blocks"]
for j, block in enumerate(blocks):
    ax.scatter(block["mean_delta"], j+3, marker="s", color=grey, s=30)
ax.set_yticks([0, 1, *range(3, 8)], ["Primary", "After gate", *[f"20-start block {j+1}" for j in range(5)]])
ax.set_ylim(8, -1)
ax.set_title("Aggregate contrasts and stability", loc="left", fontsize=12, fontweight="bold")
for ax in axes:
    ax.axvline(0, color="#777777", linestyle="--", lw=1)
    ax.grid(axis="x", alpha=.15)
    ax.spines[["top", "right"]].set_visible(False)
    ax.set_xlabel("Labeled minus anonymous AUC\n(yield percentage points)", fontsize=10)
fig.suptitle("BH semantic-label ablation: frozen v2", x=.06, ha="left", fontsize=15, fontweight="bold")
fig.text(.06, .91, "10 generated pairs; 100 shared heldout starts; invalid libraries use the common calibration anchor", fontsize=9, color=grey)
fig.text(.06, .025, "Intervals: frozen crossed pair/start bootstrap (95%). Pair and block means are descriptive. AUC is best-so-far yield, not ROC AUC.", fontsize=8, color=grey)
fig.subplots_adjust(left=.08, right=.97, top=.84, bottom=.23, wspace=.48)
args.output.mkdir(parents=True, exist_ok=True)
for ext in ["png", "pdf", "svg"]:
    fig.savefig(args.output / f"bh_anonymization_v2.{ext}", dpi=180, bbox_inches="tight")
plt.close(fig)
