#!/usr/bin/env python3
"""Read completed artifacts only; independently check selection and paired statistics.

This audit never imports the production evaluator, replay code, or API client.
It must not be run against a still-running evaluation.
"""
import argparse
from collections import Counter
import csv
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
from statistics import mean, pstdev

import numpy as np

EXPECTED_PROTOCOL = "4b35575db7a47ac36e2cace37cb65224c6596fdc8e7c9f5eb592595862cbe516"
METRICS = ("final_best", "best_so_far_auc", "top10_hit")
ARMS = ("labeled", "anonymous")


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def same(actual, expected, label):
    assert np.allclose(actual, expected, rtol=0, atol=1e-9), label


def table(path, split, modes, seeds):
    rows = list(csv.DictReader(path.open(newline="")))
    assert len(rows) == len(modes) * len(seeds), f"{split} row count"
    index = {}
    for row in rows:
        assert row["split"] == split
        key = (row["mode"], int(row["seed"]))
        assert key not in index, f"duplicate {split} row"
        index[key] = {metric: float(row[metric]) for metric in METRICS}
        assert all(math.isfinite(value) for value in index[key].values())
    assert set(index) == {(mode, seed) for mode in modes for seed in seeds}
    return index


def selection_from_calibration(calibration, libraries, outcomes, seeds, baselines, config):
    means = {mode: {metric: round(mean(calibration[(mode, seed)][metric] for seed in seeds), 6)
                    for metric in METRICS} for mode in baselines}
    for summary in means.values():
        summary["composite"] = round(summary["final_best"] + summary["best_so_far_auc"], 6)
    anchor = max(baselines, key=lambda mode: (means[mode]["composite"], mode))
    independent = {}
    for identifier, outcome in outcomes.items():
        if outcome["status"] == "INVALID_ANCHOR_FALLBACK":
            assert identifier not in libraries
            independent[identifier] = dict(primary=anchor, gated=anchor, accepted=False,
                                           eligible=[], diagnostics={})
            continue
        assert outcome["status"] == "VALID"
        diagnostics = {}
        for skill in libraries[identifier]:
            mode = "llm_semantic_" + skill["skill_id"]
            final = [calibration[(mode, seed)]["final_best"] -
                     calibration[(anchor, seed)]["final_best"] for seed in seeds]
            auc = [calibration[(mode, seed)]["best_so_far_auc"] -
                   calibration[(anchor, seed)]["best_so_far_auc"] for seed in seeds]
            composite = [a + b for a, b in zip(final, auc, strict=True)]
            final_mean, auc_mean = round(mean(final), 6), round(mean(auc), 6)
            nonloss = round(sum(x >= 0 for x in final) / len(final), 6)
            comp_mean = round(mean(composite), 6)
            comp_se = round(pstdev(composite) / math.sqrt(len(composite)), 6)
            risk = comp_mean - 0.5 * comp_se
            fold_means = [mean(composite[i::5]) for i in range(5)]
            positive = sum(value > 0 for value in fold_means) / 5
            eligible = (final_mean >= 0 and auc_mean >= 0 and nonloss >= 0.55
                        and positive >= config["min_positive_fold_rate"]
                        and risk >= config["min_risk_adjusted_gain"])
            diagnostics[mode] = dict(risk=round(risk, 6), auc=auc_mean, eligible=eligible,
                                     positive_fold_rate=round(positive, 6),
                                     fold_means=[round(value, 6) for value in fold_means])
        rank = lambda mode: (diagnostics[mode]["risk"], diagnostics[mode]["auc"], mode)
        eligible = [mode for mode, detail in diagnostics.items() if detail["eligible"]]
        primary = max(diagnostics, key=rank)
        gated = max(eligible, key=rank) if eligible else anchor
        independent[identifier] = dict(primary=primary, gated=gated, accepted=bool(eligible),
                                       eligible=sorted(eligible), diagnostics=diagnostics)
    return anchor, means, independent


def audit(base):
    # Do not inspect partial metric tables before the formal completed result exists.
    summary = read(base / "summary.json")
    assert summary["status"] == "complete"
    assert not (base / "failure.json").exists()
    integrity = read(base / "integrity.json")
    for relative, expected in integrity.items():
        assert digest(base / relative) == expected, f"integrity: {relative}"
    assert digest(base / "protocol_lock.json") == EXPECTED_PROTOCOL
    manifest, lock = read(base / "manifest.json"), read(base / "selection_lock.json")
    config, analysis = read(base / "config.json"), read(base / "analysis.json")
    start = read(base / "heldout_start.json")
    assert lock["manifest_sha256"] == digest(base / "manifest.json")
    assert lock["calibration_metrics_sha256"] == digest(base / "calibration_metrics.csv")
    assert lock["protocol_lock_sha256"] == EXPECTED_PROTOCOL
    assert lock["heldout_started"] is False
    assert start["selection_lock_sha256"] == summary["selection_lock_sha256"] == digest(base / "selection_lock.json")
    assert datetime.fromisoformat(lock["frozen_at_utc"]) <= datetime.fromisoformat(start["started_at_utc"])
    calibration_seeds = list(range(202610205000, 202610205050))
    heldout_seeds = list(range(202610206000, 202610206100))
    assert lock["heldout_seeds"] == heldout_seeds == analysis["heldout_seeds"]
    baselines = config["selection"]["target_anchor"]["modes"]
    libraries, outcomes = manifest["libraries"], manifest["outcomes"]
    assert len(outcomes) == 20 and len(lock["choices"]) == 20
    modes = baselines + ["llm_semantic_" + skill["skill_id"]
                         for library in libraries.values() for skill in library]
    assert len(modes) == len(set(modes))
    assert all(len(library) == 5 for library in libraries.values())
    calibration = table(base / "calibration_metrics.csv", "calibration", modes, calibration_seeds)
    heldout = table(base / "heldout_metrics.csv", "heldout", modes, heldout_seeds)
    for index in (calibration, heldout):
        seeds = calibration_seeds if index is calibration else heldout_seeds
        for mode, representative in manifest["execution_aliases"].items():
            for seed in seeds:
                assert index[(mode, seed)] == index[(representative, seed)], "execution alias metrics differ"
    anchor, anchor_means, choices = selection_from_calibration(
        calibration, libraries, outcomes, calibration_seeds, baselines, config)
    assert anchor == lock["target_anchor_mode"] == analysis["target_anchor_mode"]
    assert anchor_means == lock["target_anchor_summary"]
    for identifier, expected in choices.items():
        frozen = lock["choices"][identifier]
        assert frozen["primary_mode"] == expected["primary"], f"raw winner: {identifier}"
        assert frozen["selected_mode"] == expected["gated"], f"gate winner: {identifier}"
        assert frozen["selection"]["target_anchor_mode"] == anchor
        assert frozen["selection"]["selected_rule"] == expected["accepted"]
        if outcomes[identifier]["status"] == "VALID":
            detail = frozen["selection"]
            assert detail["eligible_skill_modes"] == expected["eligible"]
            for mode, independent in expected["diagnostics"].items():
                actual = detail["skill_diagnostics"][mode]
                assert actual["eligible"] == independent["eligible"]
                same(actual["risk_adjusted_composite_gain"], independent["risk"], "calibration score")
                same(actual["best_so_far_auc"]["mean"], independent["auc"], "calibration AUC")
                same(actual["fold_composite_means"], independent["fold_means"], "calibration folds")
    rng = np.random.default_rng(2026102004)
    seed_weights = rng.multinomial(100, np.full(100, 0.01), size=10000)
    pair_weights = rng.multinomial(10, np.full(10, 0.1), size=10000)

    def matrix(policy, metric="best_so_far_auc", arm=None):
        return np.array([
            [heldout[(choices[f"pair_{pair:02d}_{arm or 'labeled'}"][policy], seed)][metric]
             - heldout[(anchor if arm else choices[f"pair_{pair:02d}_anonymous"][policy], seed)][metric]
             for seed in heldout_seeds] for pair in range(10)])

    def compare(values, actual, intervals=True):
        same(actual["mean_delta"], values.mean(), "overall mean")
        same(actual["pair_mean_deltas"], values.mean(axis=1), "pair means")
        blocks = [float(block.mean()) for block in np.split(values, 5, axis=1)]
        same([x["mean_delta"] for x in actual["ordered_seed_blocks"]], blocks, "block means")
        if intervals:
            same(actual["delta_matrix"], values, "paired matrix")
            # Different implementation from production einsum: weighted row means,
            # then apply the same shared seed weight vector to all paired rows.
            draws = np.sum((pair_weights @ values) * seed_weights, axis=1) / values.size
            interval = np.quantile(draws, [0.025, 0.975])
            same([actual["interval"]["lower"], actual["interval"]["upper"]], interval, "crossed CI")
        return dict(mean=float(values.mean()), pair_means=values.mean(axis=1).tolist(),
                    five_block_means=blocks,
                    interval=[actual["interval"]["lower"], actual["interval"]["upper"]] if intervals else None)

    primary = matrix("primary")
    comparisons = {"primary": compare(primary, analysis["primary_all_pairs_auc"]),
                   "gated": compare(matrix("gated"), analysis["secondary_gated_auc"])}
    for arm in ARMS:
        for policy in ("primary", "gated"):
            key = f"{arm}_{policy}"
            comparisons[key + "_vs_anchor"] = compare(matrix(policy, arm=arm), analysis["secondary_anchor_auc"][key])
    for policy in ("primary", "gated"):
        for metric in ("final_best", "top10_hit"):
            compare(matrix(policy, metric), analysis["descriptive_other_metrics"][policy][metric], False)
    valid_counts = {arm: sum(outcomes[f"pair_{pair:02d}_{arm}"]["status"] == "VALID" for pair in range(10))
                    for arm in ARMS}
    gate_counts = {arm: sum(choices[f"pair_{pair:02d}_{arm}"]["accepted"] for pair in range(10)) for arm in ARMS}
    assert analysis["valid_library_counts_by_arm"] == valid_counts
    assert analysis["gate_accepted_library_counts_by_arm"] == gate_counts
    statuses = {name: outcome["status"] == "VALID" for name, outcome in outcomes.items()}
    validity_categories, both_valid = [], []
    for pair in range(10):
        labeled, anonymous = [statuses[f"pair_{pair:02d}_{arm}"] for arm in ARMS]
        validity_categories.append("both_valid" if labeled and anonymous else
                                   "both_invalid" if not labeled and not anonymous else
                                   "anonymous_invalid_only" if labeled else "labeled_invalid_only")
        if labeled and anonymous:
            both_valid.append(pair)
    assert analysis["pair_validity_counts"] == dict(Counter(validity_categories))
    subset = analysis["both_valid_pairs_descriptive"]
    assert subset["pair_ids"] == [f"pair_{pair:02d}" for pair in both_valid]
    assert subset["available"] == bool(both_valid) and subset["pair_count"] == len(both_valid)
    if both_valid:
        compare(primary[both_valid, :], subset["descriptive_auc"], False)
        assert "interval" not in subset["descriptive_auc"]
    advantage = comparisons["primary"]["interval"][0] > 0
    stable = advantage and all(value > 0 for value in comparisons["primary"]["five_block_means"])
    assert analysis["primary_mean_advantage"] == summary["primary_mean_advantage"] == advantage
    assert analysis["stable_advantage"] == summary["stable_advantage"] == stable
    same(summary["primary_mean_auc_delta"], primary.mean(), "summary primary")
    assert summary["completed_logical_trajectories"] == len(modes) * 150 == manifest["planned_logical_trajectories"]
    assert summary["model_api_calls"] == manifest["model_api_calls_in_evaluation"] == 0
    return {"status": "PASS", "production_code_imported": False, "replay_runs": 0, "model_api_calls": 0,
            "protocol_lock_sha256": EXPECTED_PROTOCOL, "integrity_files_checked": len(integrity),
            "calibration_cells": len(calibration), "heldout_cells": len(heldout),
            "all_scheduled_pairs_retained": 10, "primary_matrix_shape": list(primary.shape),
            "shared_anchor": anchor, "valid_library_counts_by_arm": valid_counts,
            "gate_accepted_library_counts_by_arm": gate_counts,
            "pair_validity_counts": dict(Counter(validity_categories)),
            "both_valid_subset_pair_ids": subset["pair_ids"], "comparisons": comparisons,
            "primary_mean_advantage": advantage, "stable_advantage": stable,
            "selection_lock_sha256": digest(base / "selection_lock.json"),
            "analysis_sha256": digest(base / "analysis.json"), "summary_sha256": digest(base / "summary.json")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evaluation", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.evaluation)
    with args.output.open("x") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")
    print(json.dumps(result, indent=2))
