"""Confirm publication source bytes and credential patterns without printing values."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path(__file__).resolve().parents[2]
names = subprocess.check_output(
    ["git", "diff", "--cached", "--name-only", "--diff-filter=ACM", "-z"], cwd=root
).decode().strip("\0").split("\0")
patterns = [
    re.compile(rb"\bsk-(?:or-v1-)?[A-Za-z0-9_-]{24,}"),
    re.compile(rb"-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----"),
    re.compile(rb"(?i)authorization[\"'\s]*[:=][\"'\s]*bearer\s+[A-Za-z0-9_.-]{16,}"),
]
report = {"checked_files": [], "byte_mismatches": [], "credential_pattern_paths": []}
for name in filter(None, names):
    data = (root / name).read_bytes()
    staged = subprocess.check_output(["git", "show", ":" + name], cwd=root)
    if name != ".gitattributes" and data != staged:
        report["byte_mismatches"].append(name)
    if any(pattern.search(staged) for pattern in patterns):
        report["credential_pattern_paths"].append(name)
    report["checked_files"].append({"path": name, "sha256": hashlib.sha256(staged).hexdigest()})
report["passed"] = not (report["byte_mismatches"] or report["credential_pattern_paths"])
(Path(__file__).parent / "staged_source_audit.json").write_text(
    json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps({"files": len(report["checked_files"]), "passed": report["passed"],
                  "byte_mismatches": report["byte_mismatches"],
                  "credential_pattern_paths": report["credential_pattern_paths"]}))
raise SystemExit(0 if report["passed"] else 1)
