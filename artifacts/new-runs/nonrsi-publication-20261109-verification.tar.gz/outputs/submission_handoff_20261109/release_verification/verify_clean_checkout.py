"""Exercise the documented evidence restoration in a clean detached checkout."""
from pathlib import Path
import importlib.metadata
import json
import subprocess
import time
import traceback

root = Path(__file__).resolve().parents[2]
out = Path(__file__).parent
checkout = Path('/tmp/care2-handoff-clean-20261109')
python = Path('/tmp/care2-nonrsi-frozen-20261109/bin/python')
ids = [e['id'] for e in json.loads((checkout / 'artifacts/catalog.json').read_text())['archives']
       if e['id'].startswith('nonrsi-publication-20261109-')]
result = {'checkout': str(checkout), 'python': str(python), 'archive_ids': ids,
          'new_model_requests': 0, 'passed': False, 'steps': []}

def command(name, args):
    started = time.monotonic()
    process = subprocess.run(args, cwd=checkout, text=True, capture_output=True)
    (out / (name + '.log')).write_text(process.stdout + process.stderr, encoding='utf-8')
    result['steps'].append({'name': name, 'returncode': process.returncode,
                            'elapsed_seconds': time.monotonic() - started})
    print(name, process.returncode, flush=True)
    if process.returncode:
        raise RuntimeError(name + ' failed; inspect ' + name + '.log')
    return process.stdout

try:
    result['commit'] = command('clean_checkout_commit', ['git', 'rev-parse', 'HEAD']).strip()
    result['initial_status'] = command('clean_checkout_initial_status', ['git', 'status', '--porcelain'])
    assert result['initial_status'] == '', 'Checkout was not initially clean'
    assert len(ids) == 14
    command('clean_checkout_restore', [str(python), 'care.py', 'artifacts', 'restore', *ids])
    command('clean_checkout_verify', [str(python), '-B', 'tools/verify_nonrsi_handoff.py',
             '--output', str(out / 'clean_checkout_verification')])
    result['tracked_diff'] = command('clean_checkout_tracked_diff', ['git', 'diff', '--name-only'])
    assert result['tracked_diff'] == '', 'Restoration changed tracked bytes'
    command('clean_checkout_repository_check', [str(python), 'care.py', 'check'])
    result['passed'] = True
except BaseException as exc:
    result.update(error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
(out / 'clean_checkout_audit.json').write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'passed': result['passed'], 'archive_count': len(ids)}), flush=True)
raise SystemExit(0 if result['passed'] else 1)
