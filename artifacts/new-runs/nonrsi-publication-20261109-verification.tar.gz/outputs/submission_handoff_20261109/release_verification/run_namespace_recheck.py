"""Recheck the one namespace-sensitive case under canonical module imports."""
from pathlib import Path
import contextlib
import datetime
import hashlib
import json
import os
import sys
import tempfile
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
BASE = ROOT / 'experiments/care_replay'
sys.dont_write_bytecode = True
sys.path.insert(0, str(BASE))
os.chdir(BASE)
for name in tuple(os.environ):
    if name.endswith(('_API_KEY', '_AUTH_TOKEN')):
        os.environ.pop(name)
os.environ.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
                  OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
                  MPLCONFIGDIR=str(OUT / 'matplotlib-config'))
tempfile.tempdir = str(OUT / 'test-tmp')
import pytest
from protocols.nonrsi_cross_model_v1.common import offline
started = time.monotonic()
node = 'protocols/nonrsi_cross_model_resume_v9/test_recovery.py::RecoveryTests::test_pipeline_is_experiment_one_only'
args = ['-q', '-p', 'no:cacheprovider', '--import-mode=importlib',
        '-o', 'consider_namespace_packages=true', '--rootdir', str(BASE),
        '--basetemp', str(OUT / 'pytest-namespace-work'),
        '--junitxml', str(OUT / 'namespace_recheck.junit.xml'), node]
with (OUT / 'namespace_recheck.log').open('w', encoding='utf-8') as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log), offline():
        code = int(pytest.main(args))
report = {'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'elapsed_seconds': time.monotonic() - started, 'exit_code': code, 'passed': code == 0,
          'network_disabled': True, 'new_model_requests': 0, 'test_node': node,
          'pytest_arguments': args, 'protocol_sources_changed': False,
          'initial_collection_issue': 'Default pytest prepend import named package without protocols. prefix; production uses protocols.*.'}
(OUT / 'namespace_recheck.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report), flush=True)
raise SystemExit(code)
