"""Run existing non-RSI tests with network blocked and isolated output paths."""
from pathlib import Path
import contextlib
import datetime
import json
import os
import sys
import tempfile
import time
import traceback

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'experiments/care_replay'
sys.dont_write_bytecode = True
sys.path.insert(0, str(BASE))
os.chdir(BASE)
for name in tuple(os.environ):
    if name.endswith(('_API_KEY', '_AUTH_TOKEN')):
        os.environ.pop(name)
os.environ.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
                  OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
                  MPLCONFIGDIR=str(OUT / 'matplotlib-config'))
(OUT / 'test-tmp').mkdir(exist_ok=True)
tempfile.tempdir = str(OUT / 'test-tmp')
started = time.monotonic()
report = {'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'network_disabled': True, 'new_model_requests': 0}
tests = sorted(p for folder in (BASE / 'protocols').glob('nonrsi_*')
               for p in folder.glob('test*.py'))
report['test_files'] = [str(p.relative_to(ROOT)) for p in tests]
args = ['-q', '-p', 'no:cacheprovider', '--basetemp', str(OUT / 'pytest-work'),
        '--junitxml', str(OUT / 'nonrsi_tests.junit.xml'), *map(str, tests)]
try:
    import pytest
    from protocols.nonrsi_cross_model_v1.common import offline
    with (OUT / 'nonrsi_tests.log').open('w', encoding='utf-8') as log:
        with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log), offline():
            code = int(pytest.main(args))
    report.update(exit_code=code, passed=(code == 0))
except BaseException as exc:
    report.update(exit_code=1, passed=False, error_type=type(exc).__name__, error=str(exc),
                  traceback=traceback.format_exc())
report['elapsed_seconds'] = time.monotonic() - started
report['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT / 'nonrsi_tests.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k not in ('test_files', 'traceback')}), flush=True)
raise SystemExit(report['exit_code'])
