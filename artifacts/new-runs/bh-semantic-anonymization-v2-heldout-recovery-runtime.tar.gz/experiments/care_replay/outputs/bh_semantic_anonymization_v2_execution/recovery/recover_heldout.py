"""External, offline-only recovery of the interrupted v2 heldout phase.

Default: verify only. The original frozen protocol and interrupted output are
never modified. --execute requires a separately sealed recovery evidence lock.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
from datetime import datetime, timezone
import gzip
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
BASE = ROOT / "experiments/care_replay"
ORIGINAL = BASE / "results/2026-10-20-bh-semantic-anonymization-v2-evaluation"
OUTPUT = BASE / "results/2026-10-20-bh-semantic-anonymization-v2-evaluation-recovery-1"
CONFIG = BASE / "configs/bh_semantic_anonymization_v2.json"
FREEZE = BASE / "outputs/bh_semantic_anonymization_v2_frozen"
PROTOCOL_LOCK = FREEZE / "protocol_lock.json"
GENERATION = BASE / "results/2026-10-20-bh-semantic-anonymization-v2-generation"
STATE = HERE.parent / "interrupted_state.json"
STATE_HASH = "e6602e8b117d8f1a6d09229c1d9db234b1f777fd3c4df5b6843b8214c9681167"
PROTOCOL_HASH = "4b35575db7a47ac36e2cace37cb65224c6596fdc8e7c9f5eb592595862cbe516"
SELECTION_HASH = "8d5b211b2c723bf15e8135dccfedca51e37e0a5dfde4b75bf8d724a1be2ae31f"
EMPTY_TRACE = "heldout_traces.jsonl.gz"
RECOVERY_LOCK = HERE / "recovery_lock.json"
TEST_REPORT = HERE / "recovery_test_report.txt"
RECOVERY_FILES = ("recover_heldout.py", "test_recover_heldout.py", "recovery_test_report.txt")


def runtime():
    # Set only named numerical-runtime variables; never inspect credentials.
    for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ[key] = "1"
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    sys.dont_write_bytecode = True
    path = str(BASE / "protocols/bh_semantic_anonymization_v2")
    if path not in sys.path:
        sys.path.insert(0, path)
    return importlib.import_module("evaluation")


def digest(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"Expected ordinary file: {path}")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(directory):
    directory = Path(directory)
    if directory.is_symlink() or not directory.is_dir():
        raise ValueError(f"Expected ordinary directory: {directory}")
    found = {}
    for path in sorted(directory.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"Symlink forbidden: {path}")
        if path.is_file():
            found[path.relative_to(directory).as_posix()] = digest(path)
    return found


def equal_json(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_calibration(path):
    with Path(path).open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["seed"] = int(row["seed"])
        for key in ("best_so_far_auc", "final_best", "simple_regret", "top10_hit"):
            row[key] = float(row[key])
    return rows


def verify_original():
    """Read-only full provenance check; selection recomputation is comparison only."""
    ev = runtime()
    with ev.matched.offline_guard():
        require(digest(STATE) == STATE_HASH, "Interrupted-state evidence changed")
        state = ev.common.load(STATE)
        original_hashes = inventory(ORIGINAL)
        require(original_hashes == state["original_directory_files_sha256"], "Original interrupted directory changed")
        require(digest(PROTOCOL_LOCK) == PROTOCOL_HASH, "Unexpected v2 protocol lock")
        require(digest(ORIGINAL / "selection_lock.json") == SELECTION_HASH, "Original selection lock changed")
        require((ORIGINAL / EMPTY_TRACE).stat().st_size == 0, "Persisted heldout trace is not empty")
        for name in ("heldout_metrics.csv", "analysis.json", "summary.json", "failure.json", "integrity.json"):
            require(not (ORIGINAL / name).exists(), "Heldout/final artifact already exists: " + name)
        config, lock = ev.common.verify_freeze(CONFIG, PROTOCOL_LOCK, FREEZE)
        calibration, heldout = ev.validate_config(config, 4)
        require(ORIGINAL.resolve() == (ROOT / config["evaluation_output_directory"]).resolve(), "Original output path differs from frozen config")
        require(GENERATION.resolve() == (ROOT / config["generation_output_directory"]).resolve(), "Generation directory differs from frozen config")
        outcomes, payloads, generation_hashes = ev.verify_generation(CONFIG, PROTOCOL_LOCK, GENERATION, config, lock)
        adapter = ev.matched.replay.DATASET_BUILDERS[config["target_dataset"]]()
        require(len(adapter.candidates) == config["expected_candidate_count"], "Candidate pool changed")
        catalog = ev.matched.semantic.semantic_field_catalog(adapter)
        libraries, normalization = {}, {}
        for identifier in ev.names(config):
            if identifier in payloads:
                outcome = outcomes[identifier]
                libraries[identifier], normalization[identifier] = ev.v1.normalize_without_loss(
                    payloads[identifier], catalog, outcome["pair_index"], outcome["arm"])
        skills = tuple(skill for bank in libraries.values() for skill in bank)
        representatives, aliases = ev.matched.execution_plan(skills, config["exact_execution_reuse"])
        manifest = ev.common.load(ORIGINAL / "manifest.json")
        expected_manifest = {
            "config": config, "config_sha256": lock["config_sha256"], "protocol_lock_sha256": PROTOCOL_HASH,
            "source_sha256": lock["source_sha256"], "data_sha256": lock["data_sha256"],
            "input_sha256": lock["input_sha256"], "generation_sha256": generation_hashes,
            "outcomes": outcomes, "libraries": {name: [asdict(skill) for skill in bank] for name, bank in libraries.items()},
            "normalization_and_id_provenance": normalization, "execution_aliases": aliases,
            "scheduled_library_slots": 20, "valid_library_count": len(libraries),
            "invalid_library_count": 20 - len(libraries), "logical_skill_count": len(skills),
            "unique_execution_skills": len(representatives),
            "planned_logical_trajectories": (len(ev.matched.BASELINES) + len(skills)) * (len(calibration) + len(heldout)),
            "planned_physical_trajectories": (len(ev.matched.BASELINES) + len(representatives)) * (len(calibration) + len(heldout)),
            "model_api_calls_in_evaluation": 0,
        }
        require(equal_json(manifest, expected_manifest), "Archived manifest disagrees with verified frozen inputs/generation")
        for group, folder in (("source_sha256", "source_snapshot"), ("data_sha256", "input_snapshot"),
                              ("input_sha256", "input_snapshot")):
            for relative, expected in lock[group].items():
                require(digest(ORIGINAL / folder / relative) == expected, "Archived source/input changed: " + relative)
        for relative, expected in generation_hashes.items():
            require(digest(ORIGINAL / "generation_snapshot" / relative) == expected, "Archived generation changed: " + relative)
        require(digest(ORIGINAL / "config.json") == lock["config_sha256"], "Archived config changed")
        require(digest(ORIGINAL / "protocol_lock.json") == PROTOCOL_HASH, "Archived protocol lock changed")
        selection = ev.common.load(ORIGINAL / "selection_lock.json")
        require(selection["manifest_sha256"] == digest(ORIGINAL / "manifest.json"), "Manifest/selection hash mismatch")
        require(selection["protocol_lock_sha256"] == PROTOCOL_HASH, "Selection/protocol mismatch")
        require(selection["calibration_metrics_sha256"] == digest(ORIGINAL / "calibration_metrics.csv"), "Calibration/selection hash mismatch")
        require(selection["heldout_started"] is False and selection["heldout_seeds"] == sorted(heldout), "Selection timing/heldout seed mismatch")
        start = ev.common.load(ORIGINAL / "heldout_start.json")
        require(start["selection_lock_sha256"] == SELECTION_HASH, "Original heldout start refers to another selection")
        rows = read_calibration(ORIGINAL / "calibration_metrics.csv")
        modes = (*ev.matched.BASELINES, *(ev.matched.semantic.skill_mode(skill) for skill in skills))
        ev.matched.validate_rows(rows, modes, calibration, "calibration")
        require(len(rows) == 4400 and len(calibration) == 50 and len(heldout) == 100, "Unexpected completed calibration or planned heldout size")
        # This replays only the deterministic selection calculation for equality.
        # Neither this return value nor a replacement lock is used for heldout.
        recomputed, anchor, anchor_summary = ev.freeze_choices(rows, libraries, outcomes, calibration, config)
        require(equal_json(recomputed, selection["choices"]) and anchor == selection["target_anchor_mode"]
                and equal_json(anchor_summary, selection["target_anchor_summary"]), "Recomputed calibration choice differs from original lock")
        trace_modes = (*ev.matched.BASELINES, *(ev.matched.semantic.skill_mode(skill) for skill in representatives))
        expected_trace = {(mode, seed, turn) for mode in trace_modes for seed in calibration
                          for turn in range(config["reveal_rounds"])}
        with gzip.open(ORIGINAL / "calibration_traces.jsonl.gz", "rt", encoding="utf-8") as handle:
            traces = [json.loads(line) for line in handle]
        cells = [(row["mode"], row["seed"], row["round_index"]) for row in traces]
        require(len(cells) == len(set(cells)) and set(cells) == expected_trace, "Calibration traces incomplete/duplicate")
        require(inventory(ORIGINAL) == original_hashes, "Original changed during verification")
        return {"config": config, "lock": lock, "outcomes": outcomes, "libraries": libraries,
                "skills": skills, "calibration": calibration, "heldout": heldout,
                "selection": selection, "generation_hashes": generation_hashes,
                "original_hashes": original_hashes, "calibration_rows": len(rows),
                "calibration_trace_events": len(cells), "state": state}


def seal_recovery_lock():
    """Root-only explicit preparation after reviewing a passing offline test log."""
    context = verify_original()
    ev = runtime()
    report = TEST_REPORT.read_text(encoding="utf-8")
    require("passed" in report and "failed" not in report.lower() and "error" not in report.lower(), "Require a passing offline pytest report")
    require(TEST_REPORT.stat().st_mtime_ns >= max((HERE / name).stat().st_mtime_ns
            for name in RECOVERY_FILES if name != TEST_REPORT.name), "Offline test report predates recovery sources")
    evidence = {name: digest(HERE / name) for name in RECOVERY_FILES}
    lock = {"status": "recovery_locked_before_heldout", "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "source_and_validation_sha256": evidence, "interrupted_state_sha256": STATE_HASH,
            "original_directory": str(ORIGINAL), "recovery_directory": str(OUTPUT),
            "selection_lock_sha256": SELECTION_HASH, "protocol_lock_sha256": PROTOCOL_HASH,
            "reused_calibration_logical_rows": context["calibration_rows"], "heldout_seeds": sorted(context["heldout"]),
            "workers": 4, "model_api_calls": 0, "scientific_config_changed": False}
    ev.common.save(RECOVERY_LOCK, lock, exclusive=True)
    return lock


def verify_recovery_lock(context):
    ev = runtime()
    lock = ev.common.load(RECOVERY_LOCK)
    require(lock["status"] == "recovery_locked_before_heldout", "Recovery lock status invalid")
    require(lock["source_and_validation_sha256"] == {name: digest(HERE / name) for name in RECOVERY_FILES}, "Recovery source/test evidence changed")
    checks = {"interrupted_state_sha256": STATE_HASH, "original_directory": str(ORIGINAL),
              "recovery_directory": str(OUTPUT), "selection_lock_sha256": SELECTION_HASH,
              "protocol_lock_sha256": PROTOCOL_HASH, "reused_calibration_logical_rows": context["calibration_rows"],
              "heldout_seeds": sorted(context["heldout"]), "workers": 4, "model_api_calls": 0,
              "scientific_config_changed": False}
    require(all(lock.get(key) == value for key, value in checks.items()), "Recovery lock scope differs")
    return lock


def check_copied(output, original_hashes):
    for relative, expected in original_hashes.items():
        if relative != EMPTY_TRACE:
            require(digest(output / relative) == expected, "Copied original evidence changed: " + relative)


def check_recovery_snapshot(output, recovery_lock, sealed_hash):
    require(digest(RECOVERY_LOCK) == sealed_hash, "Recovery lock changed during run")
    require(digest(output / "recovery_snapshot/recovery_lock.json") == sealed_hash,
            "Copied recovery lock changed")
    for name, expected in recovery_lock["source_and_validation_sha256"].items():
        require(digest(output / "recovery_snapshot" / name) == expected,
                "Recovery snapshot changed: " + name)
    require(digest(output / "recovery_snapshot/interrupted_state.json") == STATE_HASH,
            "Copied interruption state changed")


def execute():
    """Exactly one fresh heldout phase in the unique recovery destination."""
    started = time.perf_counter()
    require(not OUTPUT.exists(), "Recovery output already exists; no retries or overwrite")
    context = verify_original()
    recovery_lock = verify_recovery_lock(context)
    sealed_hash = digest(RECOVERY_LOCK)
    ev = runtime()
    OUTPUT.mkdir(parents=True, exist_ok=False)
    try:
        for relative, expected in context["original_hashes"].items():
            if relative == EMPTY_TRACE:
                continue
            destination = OUTPUT / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ORIGINAL / relative, destination)
            require(digest(destination) == expected, "Copy mismatch: " + relative)
        for name in (*RECOVERY_FILES, "recovery_lock.json"):
            destination = OUTPUT / "recovery_snapshot" / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(HERE / name, destination)
            require(digest(destination) == digest(HERE / name), "Recovery snapshot mismatch")
        shutil.copyfile(STATE, OUTPUT / "recovery_snapshot/interrupted_state.json")
        ev.common.save(OUTPUT / "recovery_provenance.json", {
            "original_directory": str(ORIGINAL), "recovery_directory": str(OUTPUT),
            "original_directory_files_sha256": context["original_hashes"],
            "interrupted_state_sha256": STATE_HASH, "recovery_lock_sha256": digest(RECOVERY_LOCK),
            "interrupted_archive_id": context["state"]["interrupted_archive_id"],
            "interrupted_archive_sha256": context["state"]["interrupted_archive_sha256"],
            "runtime_only_output_directory_override": True,
            "frozen_config_evaluation_output_directory": context["config"]["evaluation_output_directory"],
            "scientific_config_changed": False, "selection_recomputed_for_comparison_only": True,
            "selection_used": "byte-identical original selection_lock.json choices",
            "no_persisted_heldout_results_at_recovery": True,
            "unpersisted_inflight_work_before_interruption": "unknown; excluded from completed counts and timings",
            "calibration_worker_seconds": None, "model_api_calls": 0,
        }, exclusive=True)
        # Revalidate immediately before the phase; preserve old heldout_start bytes.
        current = verify_original()
        require(current["original_hashes"] == context["original_hashes"], "Original evidence changed before heldout")
        verify_recovery_lock(context)
        check_copied(OUTPUT, context["original_hashes"])
        check_recovery_snapshot(OUTPUT, recovery_lock, sealed_hash)
        ev.common.save(OUTPUT / "recovery_start.json", {
            "started_at_utc": datetime.now(timezone.utc).isoformat(),
            "selection_lock_sha256": SELECTION_HASH, "recovery_lock_sha256": digest(RECOVERY_LOCK),
            "workers": 4, "heldout_seeds": sorted(context["heldout"]),
        }, exclusive=True)
        with ev.matched.offline_guard():
            heldout_rows, heldout_seconds = ev.matched.run_phase(
                "heldout", context["heldout"], context["config"], context["skills"], 4, OUTPUT)
            modes = (*ev.matched.BASELINES, *(ev.matched.semantic.skill_mode(skill) for skill in context["skills"]))
            ev.matched.validate_rows(heldout_rows, modes, context["heldout"], "heldout")
            require(len(heldout_rows) == 8800, "Incomplete heldout logical rows")
            check_copied(OUTPUT, context["original_hashes"])
            analysis = ev.analyze(heldout_rows, context["libraries"], context["outcomes"],
                                  context["selection"]["choices"], context["heldout"], context["config"])
            final = verify_original()
            require(final["original_hashes"] == context["original_hashes"], "Original evidence changed during recovery")
            verify_recovery_lock(context)
        check_copied(OUTPUT, context["original_hashes"])
        check_recovery_snapshot(OUTPUT, recovery_lock, sealed_hash)
        ev.common.save(OUTPUT / "analysis.json", analysis, exclusive=True)
        summary = {"status": "complete", "model_api_calls": 0, "generation_pair_count": 10,
                   "valid_library_count": len(context["libraries"]), "invalid_library_count": 20 - len(context["libraries"]),
                   "selection_lock_sha256": SELECTION_HASH, "recovery_lock_sha256": digest(RECOVERY_LOCK),
                   "recovery_wall_seconds": time.perf_counter() - started,
                   "heldout_summed_seed_worker_seconds": heldout_seconds,
                   "reused_calibration_logical_trajectories": context["calibration_rows"],
                   "new_heldout_logical_trajectories": len(heldout_rows),
                   "unique_completed_logical_trajectories": context["calibration_rows"] + len(heldout_rows),
                   "completed_logical_trajectories": context["calibration_rows"] + len(heldout_rows),
                   "prior_calibration_and_interrupted_work_seconds": None,
                   "primary_mean_auc_delta": analysis["primary_all_pairs_auc"]["mean_delta"],
                   "primary_95_interval": analysis["primary_all_pairs_auc"]["interval"],
                   "primary_mean_advantage": analysis["primary_mean_advantage"],
                   "stable_advantage": analysis["stable_advantage"],
                   "all_invalid_constructed_zero": analysis["all_invalid_constructed_zero"],
                   "interpretation": analysis["primary_interpretation"]}
        ev.common.save(OUTPUT / "summary.json", summary, exclusive=True)
        ev.common.save(OUTPUT / "integrity.json", inventory(OUTPUT), exclusive=True)
        return summary
    except BaseException as error:
        ev.common.save(OUTPUT / "failure.json", {"status": "failed", "error": repr(error), "model_api_calls": 0}, exclusive=True)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--seal-recovery-lock", action="store_true")
    action.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if args.execute:
        result = execute()
    elif args.seal_recovery_lock:
        result = seal_recovery_lock()
    else:
        context = verify_original()
        result = {"status": "verified_only_no_replay", "calibration_logical_rows": context["calibration_rows"],
                  "calibration_trace_events": context["calibration_trace_events"], "heldout_seeds": len(context["heldout"]),
                  "selection_lock_sha256": SELECTION_HASH, "model_api_calls": 0,
                  "recovery_output_exists": OUTPUT.exists()}
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
