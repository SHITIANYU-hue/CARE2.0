import contextlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import pytest

spec = importlib.util.spec_from_file_location("recovery_subject", Path(__file__).with_name("recover_heldout.py"))
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


def test_actual_frozen_evidence_verification_only():
    context = r.verify_original()
    assert context["calibration_rows"] == 4400
    assert context["calibration_trace_events"] == 40500
    assert len(context["heldout"]) == 100
    assert not r.OUTPUT.exists()
    assert r.digest(r.ORIGINAL / "selection_lock.json") == r.SELECTION_HASH


def test_changed_interruption_state_halts(monkeypatch, tmp_path):
    changed = tmp_path / "state.json"
    changed.write_text("{}")
    monkeypatch.setattr(r, "STATE", changed)
    with pytest.raises(ValueError, match="Interrupted-state evidence changed"):
        r.verify_original()


def test_existing_destination_halts_before_work(monkeypatch, tmp_path):
    monkeypatch.setattr(r, "OUTPUT", tmp_path)
    monkeypatch.setattr(r, "verify_original", lambda: pytest.fail("must refuse before work"))
    with pytest.raises(ValueError, match="already exists"):
        r.execute()


def test_copy_hash_tamper_is_rejected(tmp_path):
    p = tmp_path / "selection_lock.json"
    p.write_text("original")
    expected = {p.name: r.digest(p)}
    r.check_copied(tmp_path, expected)
    p.write_text("tampered")
    with pytest.raises(ValueError, match="Copied original evidence changed"):
        r.check_copied(tmp_path, expected)


def test_inventory_rejects_symlinks(tmp_path):
    target = tmp_path / "target"
    target.write_text("data")
    (tmp_path / "link").symlink_to(target)
    with pytest.raises(ValueError, match="Symlink forbidden"):
        r.inventory(tmp_path)


def test_offline_guard_blocks_network():
    import socket
    ev = r.runtime()
    with ev.matched.offline_guard():
        with pytest.raises(RuntimeError):
            socket.create_connection(("example.com", 443))


@pytest.fixture
def fake_runtime(monkeypatch, tmp_path):
    original, output, here = tmp_path / "original", tmp_path / "resumed", tmp_path / "runtime"
    original.mkdir(); here.mkdir()
    for name in ["selection_lock.json", "manifest.json", "heldout_start.json", "calibration_metrics.csv"]:
        (original / name).write_text('{"preserved": true}')
    (original / r.EMPTY_TRACE).write_bytes(b"")
    for name in [*r.RECOVERY_FILES, "recovery_lock.json"]:
        (here / name).write_text("test fixture")
    state = here / "state.json"; state.write_text("{}")
    monkeypatch.setattr(r, "ORIGINAL", original)
    monkeypatch.setattr(r, "OUTPUT", output)
    monkeypatch.setattr(r, "HERE", here)
    monkeypatch.setattr(r, "STATE", state)
    monkeypatch.setattr(r, "RECOVERY_LOCK", here / "recovery_lock.json")
    context = {"original_hashes": r.inventory(original), "config": {"evaluation_output_directory": "original"},
               "selection": {"choices": {"original_locked_choice": True}}, "calibration_rows": 4400,
               "heldout": set(range(202610206000, 202610206100)), "skills": (),
               "libraries": {str(i): [] for i in range(17)}, "outcomes": {},
               "state": {"interrupted_archive_id": "original", "interrupted_archive_sha256": "fixed"}}
    monkeypatch.setattr(r, "verify_original", lambda: context)
    monkeypatch.setattr(r, "STATE_HASH", r.digest(state))
    monkeypatch.setattr(r, "verify_recovery_lock", lambda c: {"source_and_validation_sha256": {name: r.digest(here / name) for name in r.RECOVERY_FILES}})
    def save(path, value, exclusive=False):
        with Path(path).open("x" if exclusive else "w") as f:
            json.dump(value, f)
    calls = []
    def phase(split, seeds, config, skills, workers, destination):
        calls.append((split, seeds, config, skills, workers, destination))
        (destination / r.EMPTY_TRACE).write_bytes(b"new heldout fixture")
        return [{} for _ in range(8800)], 3.0
    def analyze(rows, libraries, outcomes, choices, heldout, config):
        assert choices is context["selection"]["choices"]
        return {"primary_all_pairs_auc": {"mean_delta": 0.0, "interval": {"lower": -1, "upper": 1}},
                "primary_mean_advantage": False, "stable_advantage": False,
                "all_invalid_constructed_zero": False, "primary_interpretation": "test"}
    matched = SimpleNamespace(offline_guard=contextlib.nullcontext, run_phase=phase, BASELINES=(),
                              validate_rows=lambda *args: None, semantic=SimpleNamespace(skill_mode=lambda x: x))
    ev = SimpleNamespace(common=SimpleNamespace(save=save), matched=matched, analyze=analyze)
    monkeypatch.setattr(r, "runtime", lambda: ev)
    return context, calls, original, output, ev


def test_handoff_only_runs_original_heldout_and_preserves_original(fake_runtime):
    context, calls, original, output, ev = fake_runtime
    before = r.inventory(original)
    result = r.execute()
    assert len(calls) == 1
    split, seeds, config, skills, workers, destination = calls[0]
    assert split == "heldout" and seeds == context["heldout"] and workers == 4
    assert destination == output and config is context["config"]
    assert r.inventory(original) == before
    assert result["model_api_calls"] == 0
    assert result["reused_calibration_logical_trajectories"] == 4400
    assert result["new_heldout_logical_trajectories"] == 8800
    assert result["unique_completed_logical_trajectories"] == 13200
    assert result["prior_calibration_and_interrupted_work_seconds"] is None
    provenance = json.loads((output / "recovery_provenance.json").read_text())
    assert provenance["runtime_only_output_directory_override"] is True
    assert provenance["scientific_config_changed"] is False
    assert (output / "heldout_start.json").read_bytes() == (original / "heldout_start.json").read_bytes()
    integrity = json.loads((output / "integrity.json").read_text())
    assert all(r.digest(output / name) == value for name, value in integrity.items())


def test_phase_failure_is_not_misreported_complete(fake_runtime):
    context, calls, original, output, ev = fake_runtime
    def fail(*args):
        raise RuntimeError("injected phase failure")
    ev.matched.run_phase = fail
    with pytest.raises(RuntimeError, match="injected phase failure"):
        r.execute()
    assert (output / "failure.json").exists()
    assert not (output / "summary.json").exists()
    assert not (output / "analysis.json").exists()
