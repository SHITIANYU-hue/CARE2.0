"""Independent PMF calculation and full-row output checks; no policy/API calls."""
from pathlib import Path
import sys,json,gzip,math,hashlib
B=Path('/home/tangchao/projects/care2.0/experiments/care_replay');P=B/'protocols/auc_reanalysis_v1';O=Path(__file__).parent;sys.path.insert(0,str(P));import offline

def independent_gap(values,k):
 x=sorted(values);den=math.comb(len(x),k);top=x[-1]
 return math.fsum((top-x[j-1])*(math.comb(j-1,k-1)/den) for j in range(k,len(x)+1))
refs=json.loads((O/'references.json').read_text());cert={x['id']:x for x in json.loads((B/'outputs/auc_reanalysis_v1/certification_report.json').read_text())['certified']};maxerr=0.;total=0;conditionalNA=0
for ref in refs:
 label=ref['id'];pool=json.loads((B/cert[label]['pool_file']).read_text());x=pool['values'];m=ref['initial'];T=ref['rounds'];expected=math.fsum(independent_gap(x,k) for k in range(m+1,m+T+1))/T;err=abs(expected-ref['headroom']);maxerr=max(maxerr,err/max(1,abs(expected)))
 assert math.isclose(expected,ref['headroom'],rel_tol=1e-11,abs_tol=1e-10)
 out=json.loads(gzip.decompress((O/'normalized'/f'{label}.json.gz').read_bytes()));ids={v:i for i,v in enumerate(pool['ordered_ids'])};initials=json.loads((B/'outputs/auc_reanalysis_v1/initials'/f'{label}.json').read_text())
 seed=sorted(initials)[0];start={ids[i] for i in initials[seed]};floor=max(x[i] for i in start);remaining=[max(floor,v) for i,v in enumerate(x) if i not in start];eh=math.fsum(independent_gap(remaining,k) for k in range(1,T+1))/T
 assert math.isclose(eh,out['conditional_references'][seed]['headroom'],rel_tol=1e-11,abs_tol=1e-10)
 for row in out['rows']:
  total+=1;h=ref['headroom'];s=row['full_process_score'];assert s is not None and math.isfinite(s) and s<=1+1e-10
  assert math.isclose(s,(row['raw_auc']-ref['random_auc'])/h,rel_tol=1e-9,abs_tol=1e-10)
  cr=out['conditional_references'][str(row['seed'])];q=row['conditional_same_initial_score']
  if q is None:assert cr['zero_headroom'];conditionalNA+=1
  else:assert not cr['zero_headroom'] and math.isfinite(q) and q<=1+1e-9
res=json.loads((O/'panel_results.json').read_text())
for c in res['contrasts']:
 assert (c['raw_low']>0)==(c['normalized_low']>0)
 assert (c['raw_high']<0)==(c['normalized_high']<0)
assert total==254160
freeze=json.loads((P/'FREEZE.json').read_text())
for rel,h in freeze['artifacts'].items():assert hashlib.sha256((B/rel).read_bytes()).hexdigest()==h
checks={'status':'passed','independent_exact_integer_order_statistic_PMF_checks':32,'conditional_PMF_checks':32,'max_relative_primary_headroom_error':maxerr,'normalized_rows_checked':total,'conditional_NA_logical_rows':conditionalNA,'inherited_interval_sign_checks':len(res['contrasts']),'frozen_artifacts_unchanged':True,'model_api_calls':0,'new_policy_runs':0}
(O/'results_audit.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
