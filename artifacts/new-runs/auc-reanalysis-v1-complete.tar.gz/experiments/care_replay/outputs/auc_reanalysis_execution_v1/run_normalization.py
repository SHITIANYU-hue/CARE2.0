"""Thin execution wrapper over frozen normalization primitives; no scientific edits."""
from pathlib import Path
import sys,json,gzip,hashlib,datetime,math
B=Path('/home/tangchao/projects/care2.0/experiments/care_replay');P=B/'protocols/auc_reanalysis_v1';SOURCE=B/'outputs/auc_reanalysis_v1';OUT=Path(__file__).parent
sys.path.insert(0,str(P))
import offline
from table_analysis import transform_rows
from freeze import digest,verify_inputs

def save(path,data):
 raw=(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode();path=Path(path);path.parent.mkdir(exist_ok=True,parents=True)
 if path.suffix=='.gz':raw=gzip.compress(raw,mtime=0)
 if path.exists() and path.read_bytes()!=raw:raise RuntimeError('Immutable output differs: '+str(path))
 if not path.exists():path.write_bytes(raw)

def main():
 lock=json.loads((P/'FREEZE.json').read_text());h=digest(P/'FREEZE.json')
 if h!=(P/'FREEZE.sha256').read_text().strip():raise RuntimeError('Freeze lock hash mismatch')
 for rel,expected in lock['artifacts'].items():
  if digest(B/rel)!=expected:raise RuntimeError('Frozen artifact changed: '+rel)
 verify_inputs()
 save(OUT/'EXECUTION_LOCK.json',{'user_authorization':'2026-10-21 user explicitly requested executing frozen AUC reanalysis, panels and claim assessment, no API; stop for design amendments.','preparation_freeze_sha256':h,'wrapper_sha256':digest(__file__),'model_api_calls':0,'new_policy_runs':0,'frozen_config_execution_false_note':'Records the previous preparation phase boundary; new explicit user authorization permits this execution without modifying the frozen scientific config.'})
 cert=json.loads((SOURCE/'certification_report.json').read_text());tables={x['id']:x for x in json.loads((SOURCE/'prepared_tables_report.json').read_text())['tables']};summaries=[];mode_summaries=[]
 for c in cert['certified']:
  label=c['id'];pool=json.loads((B/c['pool_file']).read_text());pool['certified_binding']=c['ordered_ID_value_sha256'];rows=json.loads(gzip.decompress((B/tables[label]['prepared_file']).read_bytes()));initials=json.loads((SOURCE/'initials'/f'{label}.json').read_text())
  file=OUT/'normalized'/f'{label}.json.gz'
  if file.exists():out=json.loads(gzip.decompress(file.read_bytes()))
  else:
   out=transform_rows(pool,rows,initials,c['initial'],c['rounds']);save(file,out)
  ref=out['full_reference'];zero=[s for s,r in out['conditional_references'].items() if r['zero_headroom']]
  by={}
  for row in out['rows']:by.setdefault(row['mode'],[]).append(row)
  for mode,rs in by.items():
   a=[x['full_process_score'] for x in rs];q=[x['conditional_same_initial_score'] for x in rs];good=[v for v in q if v is not None]
   mode_summaries.append({'id':label,'mode':mode,'n':len(rs),'mean_raw_auc':math.fsum(x['raw_auc'] for x in rs)/len(rs),'mean_full_score':None if any(x is None for x in a) else math.fsum(a)/len(a),'mean_conditional_score':None if len(good)!=len(q) else math.fsum(good)/len(q),'conditional_NA_count':len(q)-len(good)})
  summaries.append({'id':label,**ref,'conditional_zero_seed_count':len(zero),'conditional_zero_seeds':zero,'logical_rows':len(rows),'normalized_file_sha256':digest(file)})
  print(json.dumps({'id':label,'headroom':ref['headroom'],'near_saturation':ref['near_saturation'],'conditional_zero_seeds':len(zero)},ensure_ascii=False),flush=True)
 save(OUT/'references.json',summaries);save(OUT/'mode_summaries.json',mode_summaries)
 for rel,expected in lock['artifacts'].items():
  if digest(B/rel)!=expected:raise RuntimeError('Frozen artifact changed during execution')
 save(OUT/'NORMALIZATION_COMPLETE.json',{'records':len(summaries),'logical_rows':sum(x['logical_rows'] for x in summaries),'model_api_calls':0,'new_policy_runs':0,'freeze_unchanged':True,'zero_primary_denominators':sum(x['zero_headroom'] for x in summaries),'near_saturation_primary':sum(x['near_saturation'] for x in summaries),'wrapper_sha256':digest(__file__)})
if __name__=='__main__':main()
