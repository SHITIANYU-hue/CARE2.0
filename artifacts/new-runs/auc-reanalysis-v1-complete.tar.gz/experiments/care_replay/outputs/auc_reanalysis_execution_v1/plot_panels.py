from pathlib import Path
import json,csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).parent;d=json.loads((O/'panel_results.json').read_text())
fig,axes=plt.subplots(1,3,figsize=(15,5.4),layout='constrained')
a=[(x['panel'].replace('Fixed_',''),x['normalized_mean'],x['normalized_low'],x['normalized_high']) for x in d['original_fixed']]
b=[]
for x in d['contrasts']:
 if x['role']!='primary' or x['panel'] not in ['BH_coverage','BH_anon_v2','Suzuki_v1']:continue
 label=x['contrast'].replace(' / primary','').replace('labeled_minus_','label - ').replace('_valid_parents','').replace('_all_pairs','').replace('anonymous','anon')
 b.append((x['panel'].replace('_v1','').replace('_v2','').replace('_coverage',' coverage')+': '+label,x['normalized_mean'],x['normalized_low'],x['normalized_high']))
c=[(key.replace('_minus_',' - '),v['mean'],v['low'],v['high']) for key,v in d['protein_equal_group'].items()]
for ax,rows,title in zip(axes,[a,b,c],['A  Original four tasks\nInherited 95% intervals','B  Chemistry controls\nOriginal multiplicity-adjusted intervals*','C  Protein transfer: 13 groups\nDescriptive group-bootstrap 95% intervals']):
 for i,(label,m,lo,hi) in enumerate(rows):
  color='#167d8d' if lo>0 else '#ba4c41' if hi<0 else '#6b7280'
  ax.errorbar(m,i,xerr=[[m-lo],[hi-m]],fmt='o',color=color,capsize=3,markersize=5)
 ax.set_yticks(range(len(rows)),[r[0] for r in rows],fontsize=8);ax.invert_yaxis();ax.axvline(0,color='black',lw=.8);ax.grid(axis='x',alpha=.18);ax.set_xlabel('Difference in normalized AUC');ax.set_title(title,fontsize=11);ax.spines[['top','right']].set_visible(False)
fig.suptitle('AUC reanalysis: random search = 0, frozen-pool optimum = 1',fontsize=14)
fig.supxlabel('* BH coverage: 97.5%; BH label ablation: 95%; Suzuki: 98.33%. Different panels are not pooled.',fontsize=9)
fig.savefig(O/'auc_panels.png',dpi=190);fig.savefig(O/'auc_panels.pdf');plt.close(fig)
rows=list(csv.DictReader((O/'protein_route_effects.csv').open()));rows=[r for r in rows if r['contrast']=='Always_minus_Never']
fig,ax=plt.subplots(figsize=(10,9),layout='constrained')
for i,r in enumerate(rows):
 m,lo,hi=map(float,[r['delta_score'],r['low'],r['high']]);color={'beneficial':'#167d8d','harmful':'#ba4c41','uncertain':'#777777','near_zero':'#999999'}[r['old_truth']]
 ax.errorbar(m,i,xerr=[[m-lo],[hi-m]],fmt='o',color=color,capsize=2)
labels=[r['route'].replace('__hash_domain',' | hash/shift').replace('__order_extrapolation',' | extrapolation') for r in rows]
ax.set_yticks(range(len(rows)),labels,fontsize=8);ax.invert_yaxis();ax.axvline(0,color='black',lw=.8);ax.grid(axis='x',alpha=.2);ax.set_xlabel('Always - Never: normalized AUC difference');ax.set_title('23 frozen protein routes\nColor retains original source-IQR classification; pointwise 95% intervals')
fig.savefig(O/'protein_routes.png',dpi=190);fig.savefig(O/'protein_routes.pdf');plt.close(fig)
print('Saved panel and route figures as PNG/PDF')
