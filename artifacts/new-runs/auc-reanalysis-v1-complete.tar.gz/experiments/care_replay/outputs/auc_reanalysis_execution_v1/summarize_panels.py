"""Reporting assembly using frozen positive scaling and equal-group bootstrap."""
from pathlib import Path
import json,csv,io,gzip,tarfile,hashlib,sys,math
from statistics import mean
B=Path('/home/tangchao/projects/care2.0/experiments/care_replay');P=B/'protocols/auc_reanalysis_v1';O=Path(__file__).parent
sys.path.insert(0,str(P));import offline
from table_analysis import transform_existing_interval,equal_group_summary
INPUTS={}
def read(p):
 d=Path(p).read_bytes();INPUTS[str(p)]=hashlib.sha256(d).hexdigest();return d
def jd(p):return json.loads(read(p))
def save(name,d): (O/name).write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def csvout(name,rows):
 with (O/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
refs={x['id']:x for x in jd(O/'references.json')};modes={(x['id'],x['mode']):x for x in jd(O/'mode_summaries.json')};contrasts=[]
def contrast(label,name,m,lo,hi,level=.95,role='primary',source='',method='inherited interval; same positive fixed denominator'):
 s=transform_existing_interval(m,lo,hi,refs[label]);r={'panel':label,'contrast':name,'role':role,'raw_mean':m,'raw_low':lo,'raw_high':hi,'normalized_mean':s['mean'],'normalized_low':s['low'],'normalized_high':s['high'],'confidence_level':level,'method':method,'source':source};contrasts.append(r);return r
# Original four headline comparisons; comparator names inherited from original records.
a=B.parents[1]/'artifacts/replay-results/replay-2026-07-21-cross-domain-semantic-skills.tar.gz';read(a)
with tarfile.open(a) as t:
 member=next(m for m in t.getmembers() if m.name.endswith('/pair_summary.csv'));pairs=list(csv.DictReader(io.StringIO(t.extractfile(member).read().decode())))
original=[]
for label,run,anchor in [('Fixed_FreeSolv','freesolv_kernel_500','target_acquisition_portfolio'),('Fixed_Lipophilicity','universal_lipophilicity_300','target_acquisition_portfolio'),('Fixed_BH','bh_semantic_confirm500','mixed_kernel_gp_ei'),('Fixed_bandgap','materials_semantic_confirm500','mixed_kernel_gp_ei')]:
 r=next(x for x in pairs if x['run']==run and x['metric']=='best_so_far_auc');c=contrast(label,r['comparison'],float(r['mean_delta']),float(r['ci95_low']),float(r['ci95_high']),source=str(a)+'::'+member.name)
 lm=modes[(label,'llm_calibrated_selector')];bm=modes[(label,anchor)]
 if abs(lm['mean_raw_auc']-bm['mean_raw_auc']-c['raw_mean'])>1e-4:raise ValueError('Original contrast mapping mismatch')
 original.append({**c,'anchor':anchor,'random_auc':refs[label]['random_auc'],'oracle':refs[label]['oracle'],'llm_score':lm['mean_full_score'],'anchor_score':bm['mean_full_score'],'raw_full_precision_delta':lm['mean_raw_auc']-bm['mean_raw_auc']})
recent=[]
for label,folder in [('BH_pilot','2026-10-18-bh-random-rule-controls-pilot-v1-rerun'),('BH_scale','2026-10-18-bh-random-rule-controls-scale-v1'),('BH_coverage','2026-10-19-bh-coverage-matched-rule-controls-v1')]:
 d=B/'results'/folder;summary=jd(d/'summary.json');choice=summary['libraries']['llm'];anchor=choice['target_anchor_mode'];lm=choice['ungated_calibration_winner'];a=modes[(label,lm)];bm=modes[(label,anchor)]
 r=choice['ungated_winner_vs_anchor']['best_so_far_auc'];contrast(label,'LLM raw winner minus '+anchor,r['mean'],r['normal_95ci_low'],r['normal_95ci_high'],role='anchor_secondary',source=str(d/'summary.json'))
 recent.append({'id':label,'llm_score':a['mean_full_score'],'anchor_score':bm['mean_full_score'],'anchor':anchor,'llm_mode':lm,'deployed_score':modes[(label,choice['selected_mode'])]['mean_full_score']})
 if label=='BH_pilot':
  for name,rec in summary['libraries'].items():
   if name=='llm':continue
   r=rec['llm_deployed_minus_library']['best_so_far_auc'];contrast(label,'deployed LLM minus '+name,r['mean'],r['normal_95ci_low'],r['normal_95ci_high'],role='pilot_descriptive',source=str(d/'summary.json'))
 else:
  stability=jd(d/'stability.json');lock=jd(d/'selection_lock.json')
  for fam,f in stability['families'].items():
   for key,role,choicekey in [('primary_ungated_auc','primary','ungated_calibration_winner'),('secondary_deployed_auc','deployed_secondary','selected_mode')]:
    r=f[key];v=r['interval'];c=contrast(label,'LLM minus '+fam+' / '+role,r['mean_delta'],v['lower'],v['upper'],v['confidence_level'],role,str(d/'stability.json'),v['method'])
    llmmode=lock['selections']['llm'][choicekey];randommean=mean(modes[(label,lock['selections'][name][choicekey])]['mean_raw_auc'] for name in f['bank_ids'])
    if abs(modes[(label,llmmode)]['mean_raw_auc']-randommean-r['mean_delta'])>1e-4:raise ValueError('BH bank contrast mismatch')
    c['all_blocks_positive']=r['all_block_means_positive'];c['normalized_random_mean']=(randommean-refs[label]['random_auc'])/refs[label]['headroom']
d=B/'results/2026-10-20-bh-semantic-anonymization-v2-evaluation-recovery-1';anon=jd(d/'analysis.json');lock=jd(d/'selection_lock.json');choices=lock['choices']
for key,name,role in [('primary_all_pairs_auc','labeled minus anonymous','primary'),('secondary_gated_auc','gated labeled minus anonymous','deployed_secondary')]:
 r=anon[key];v=r['interval'];contrast('BH_anon_v2',name,r['mean_delta'],v['lower'],v['upper'],v['confidence_level'],role,str(d/'analysis.json'),v['method'])
for name,r in anon['secondary_anchor_auc'].items():
 v=r['interval'];contrast('BH_anon_v2',name+' minus anchor',r['mean_delta'],v['lower'],v['upper'],v['confidence_level'],'anchor_secondary',str(d/'analysis.json'),v['method'])
for arm in ['labeled','anonymous']:
 rs=[modes[('BH_anon_v2',v['primary_mode'])] for k,v in choices.items() if k.endswith('_'+arm)]
 recent.append({'id':'BH_anon_v2_'+arm,'llm_score':mean(r['mean_full_score'] for r in rs),'anchor_score':modes[('BH_anon_v2',lock['target_anchor_mode'])]['mean_full_score'],'anchor':lock['target_anchor_mode'],'llm_mode':'primary including invalid fallback','deployed_score':mean(modes[('BH_anon_v2',v['selected_mode'])]['mean_full_score'] for k,v in choices.items() if k.endswith('_'+arm))})
d=B/'results/2026-10-20-suzuki-continuation-amendment2-evaluation';suz=jd(d/'analysis.json')
for name,r in suz['primary'].items():
 contrast('Suzuki_v1',name,r['mean_delta'],*r['interval_adjusted'],r['confidence_level'],'primary',str(d/'analysis.json'),'inherited paired parent/shared seed bootstrap; Bonferroni 3 contrasts')
for arm in ['labeled','anonymous']:
 raw=suz['secondary_descriptive'][arm+'_primary_mode']['mean_auc'];dep=suz['secondary_descriptive'][arm+'_selected_mode']['mean_auc'];ref=refs['Suzuki_v1']
 recent.append({'id':'Suzuki_v1_'+arm,'llm_score':(raw-ref['random_auc'])/ref['headroom'],'anchor_score':(suz['anchor_mean_auc']-ref['random_auc'])/ref['headroom'],'anchor':suz['anchor'],'llm_mode':'primary including invalid fallback','deployed_score':(dep-ref['random_auc'])/ref['headroom']})
# Protein paired effects, same original per-route CI convention; new frozen equal-group summaries.
rawroutes=list(csv.DictReader(io.StringIO(read(B/'outputs/experiment3_execution_v1/route_results.csv').decode())));routeeffects=[];aggregate={};policy_pairs=[('Always','Never'),('G0','Never'),('G1','Never'),('G1','G0'),('G0','Always'),('G1','Always')]
for route in rawroutes:
 label=route['route'];r=refs[label];data=json.loads(gzip.decompress(read(O/'normalized'/f'{label}.json.gz')));by={}
 for x in data['rows']:by.setdefault(x['mode'],{})[x['seed']]=x['raw_auc']
 for a,b in policy_pairs:
  vals=[by[a][seed]-by[b][seed] for seed in sorted(by[a])];m=mean(vals);sd=math.sqrt(mean((v-m)**2 for v in vals));se=sd/math.sqrt(len(vals));low=m-1.96*se;high=m+1.96*se
  if abs(m/100-float(route[a+'_minus_'+b]))>1e-9:raise ValueError('Protein original raw effect mismatch')
  s=transform_existing_interval(m,low,high,r)
  routeeffects.append({'route':label,'group':route['group'],'kind':route['kind'],'contrast':a+'_minus_'+b,'old_truth':route['truth'],'source_iqr_delta':m/100,'delta_score':s['mean'],'low':s['low'],'high':s['high'],'headroom':r['headroom'],'conditional_zero_seeds':r['conditional_zero_seed_count']})
for a,b in policy_pairs:
 key=a+'_minus_'+b;rows=[r for r in routeeffects if r['contrast']==key];aggregate[key]=equal_group_summary(rows)
 # Same group weighting, old source-IQR units: diagnostic only, does not replace original main.
 old=[dict(r,delta_score=r['source_iqr_delta']) for r in rows];aggregate[key]['same_weight_source_iqr_mean']=equal_group_summary(old)['mean']
primary=[r for r in routeeffects if r['contrast']=='Always_minus_Never'];groups={}
for r in primary:groups.setdefault(r['group'],[]).append(r)
group_effects=[{'group':g,'delta_score':mean(x['delta_score'] for x in rs),'source_iqr_delta':mean(x['source_iqr_delta'] for x in rs),'routes':len(rs)} for g,rs in groups.items()]
spg_group=next(r['group'] for r in primary if r['route']=='SPG1_STRSG_Wu_2016__hash_domain')
spg=next(x for x in group_effects if x['group']==spg_group)
share={name:abs(spg[name])/sum(abs(x[name]) for x in group_effects) for name in ['delta_score','source_iqr_delta']}
result={'original_fixed':original,'original_equal_task_mean_delta_score':mean(x['normalized_mean'] for x in original),'recent_policy_scores':recent,'contrasts':contrasts,'protein_equal_group':aggregate,'protein_group_effects':group_effects,'SPG1_absolute_group_contribution_share':share,'protein_truth_counts':{k:sum(x['truth']==k for x in rawroutes) for k in ['beneficial','harmful','near_zero','uncertain']},'all_comparisons_scale_positive':all(refs[c['panel']]['headroom']>0 for c in contrasts),'original_primary_unchanged':True,'all_conditional_zero_seed_occurrences':sum(r['conditional_zero_seed_count'] for r in refs.values())}
save('panel_results.json',result);csvout('original_fixed.csv',original);csvout('chemistry_contrasts.csv',[{k:v for k,v in c.items() if k not in ['all_blocks_positive','normalized_random_mean']} for c in contrasts]);csvout('protein_route_effects.csv',routeeffects);csvout('protein_group_effects.csv',group_effects);save('analysis_sources.json',{'files_sha256':INPUTS,'summary_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'api_calls':0})
print(json.dumps({'original':[(r['panel'],r['normalized_mean'],r['normalized_low'],r['normalized_high']) for r in original],'protein_equal_group':aggregate,'spg_absolute_share':share},ensure_ascii=False,indent=2))
