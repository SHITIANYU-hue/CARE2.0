"""Reproduce every supplementary point from normalized rows and original locks."""
from pathlib import Path
import json,gzip,math,sys
from statistics import mean
O=Path(__file__).parent;B=O.parents[1];sys.path.insert(0,str(B/'protocols/auc_reanalysis_v1'));import offline
records=json.loads((O/'same_initial_supplement.json').read_text());cache={}
for row in records:
 label=row['panel'];name=row['contrast']
 if label not in cache:
  data=json.loads(gzip.decompress((O/'normalized'/f'{label}.json.gz').read_bytes()));by={}
  for r in data['rows']:by.setdefault(r['mode'],{})[r['seed']]=r
  cache[label]=(data,by)
 data,by=cache[label]
 if label.startswith('Fixed_'):
  a=['llm_calibrated_selector'];b=['mixed_kernel_gp_ei' if label in ['Fixed_BH','Fixed_bandgap'] else 'target_acquisition_portfolio']
 elif label in ['BH_scale','BH_coverage']:
  folder='2026-10-18-bh-random-rule-controls-scale-v1' if label=='BH_scale' else '2026-10-19-bh-coverage-matched-rule-controls-v1';choices=json.loads((B/'results'/folder/'selection_lock.json').read_text())['selections'];a=[choices['llm']['ungated_calibration_winner']]
  b=[choices['llm']['selection']['target_anchor_mode']] if name.endswith('anchor') else [v['ungated_calibration_winner'] for k,v in choices.items() if k.startswith(name[-2:]+'_')]
 elif label in ['BH_anon_v2','Suzuki_v1']:
  folder='2026-10-20-bh-semantic-anonymization-v2-evaluation-recovery-1' if label=='BH_anon_v2' else '2026-10-20-suzuki-continuation-amendment2-evaluation';choices=json.loads((B/'results'/folder/'selection_lock.json').read_text())['choices']
  if name.endswith('anonymous'):
   a=[v['primary_mode'] for k,v in choices.items() if k.endswith('_labeled')];b=[v['primary_mode'] for k,v in choices.items() if k.endswith('_anonymous')]
  else:
   parents=json.loads((B/'results'/folder/'analysis.json').read_text())['valid_labeled_parent_indices'];a=[choices[f'pair_{i:02d}_labeled']['primary_mode'] for i in parents];b=[v['primary_mode'] for k,v in choices.items() if k.startswith(name[-2:]+'_')]
 else:a=['Always'];b=['Never']
 raw=[];conditional=[];na=0
 for seed in sorted(next(iter(by.values()))):
  delta=mean(by[m][seed]['raw_auc'] for m in a)-mean(by[m][seed]['raw_auc'] for m in b);raw.append(delta);h=data['conditional_references'][str(seed)]['headroom']
  if h==0:na+=1
  else:conditional.append(delta/h)
 assert len(raw)==row['seed_count'] and na==row['zero_headroom_seeds']
 assert math.isclose(mean(raw),row['shared_initial_raw_delta'],rel_tol=1e-12,abs_tol=1e-12)
 if na:assert row['conditional_delta_score'] is None
 else:assert math.isclose(mean(conditional),row['conditional_delta_score'],rel_tol=1e-12,abs_tol=1e-12)
print('Verified',len(records),'same-initial supplementary contrasts; no discarded seeds.')
