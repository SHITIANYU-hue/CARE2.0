#!/usr/bin/env python3
"""Offline public-metadata inventory only; no replay, imports of execution code, or API."""
import ast, collections, csv, gzip, hashlib, io, json, socket, subprocess, tarfile
from pathlib import Path
BASE = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
ROOT = BASE.parent.parent

def blocked(*args, **kwargs):
    raise RuntimeError("Network disabled in experiment-three preparation")
socket.socket = blocked
socket.create_connection = blocked

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name, obj):
    (OUT/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')
def partition(r):
    return 'validation' if r['validation'].lower() == 'true' else r['set']
def projected(text):
    # CSV bytes necessarily contain target strings; discard at the parser boundary.
    # No outcome is converted to a number, used to select a route, or exported.
    return [{k:r[k] for k in ('sequence','set','validation')} for r in csv.DictReader(io.StringIO(text))]
def consensus(rows):
    seqs=[r['sequence'] for r in rows if partition(r) in ('train','validation')]
    assert len({len(s) for s in seqs}) == 1
    return ''.join(sorted(collections.Counter(col),key=lambda aa:(-collections.Counter(col)[aa],aa))[0] for col in zip(*seqs))
def ids(rows): return {hashlib.sha256(r['sequence'].encode()).hexdigest() for r in rows}

audit_paths = sorted(set(list((BASE/'scripts').glob('*.py'))+list((BASE/'configs').glob('*.json'))+list((BASE/'data/raw').glob('flip2*'))+[p for p in (BASE/'protocols').rglob('*') if p.is_file()]))
before={str(p.relative_to(ROOT)):sha(p) for p in audit_paths}
(OUT/'git_status_before.txt').write_text(subprocess.run(['git','status','--short'],cwd=ROOT,capture_output=True,text=True,check=True).stdout)
inventory=[]; datasets={}; checks=[]
for p in sorted((BASE/'data/raw').glob('flip2*.csv.gz')):
    with gzip.open(p,'rt') as f: text=f.read()
    rows=projected(text)
    # Noninterference check: corrupt every outcome, preserve public columns.
    parsed=list(csv.DictReader(io.StringIO(text)))
    buffer=io.StringIO(); writer=csv.DictWriter(buffer,fieldnames=list(parsed[0]));writer.writeheader()
    writer.writerows({**r,'target':'NOT_AN_OUTCOME'} for r in parsed)
    assert projected(buffer.getvalue()) == rows
    checks.append({'file':p.name,'outcome_replacement_preserves_projection':True})
    item={'file':p.name,'sha256':sha(p),'rows':len(rows),'public_columns':['sequence','set','validation'],'duplicates_by_sequence':len(rows)-len(ids(rows)),'partition_counts':dict(collections.Counter(partition(r) for r in rows)),'length_counts':dict(collections.Counter(len(r['sequence']) for r in rows)),'outcome_analysis_performed':False}
    if any(x in p.name for x in ('ired','amylase')):
        ref=consensus(rows)
        for r in rows:r['order']=sum(a!=b for a,b in zip(ref,r['sequence']))
        item.update(reference_sha256=hashlib.sha256(ref.encode()).hexdigest(),reference_is_observed_sequence=any(r['sequence']==ref for r in rows),mutation_orders={part:dict(sorted(collections.Counter(r['order'] for r in rows if partition(r)==part).items())) for part in ['train','validation','test']})
    inventory.append(item);datasets[p.name]=rows
routes=[]
def add(route_id,family,source,calibration,target,definition,method,blocker):
    si,ci,ti=ids(source),ids(calibration),ids(target)
    assert not (si&ci or si&ti or ci&ti),route_id
    routes.append({'id':route_id,'family':family,'dependency_cluster':family,'definition':definition,'source_fit_pool_n':len(source),'source_calibration_pool_n':len(calibration),'target_pool_n':len(target),'target_pool_sha256':hashlib.sha256('\n'.join(sorted(ti)).encode()).hexdigest(),'development_only':True,'eligible_as_new_confirmatory_route':False,'within_route_sequence_overlap':0,'transfer_policy_candidate':method,'blocker':blocker,'_target_ids':ti})
ired=datasets['flip2_ired_two_to_many.csv.gz']
for label,orders in [('S01',{0,1}),('S02',{0,1,2}),('S2',{2})]:
    source=[r for r in ired if partition(r)=='train' and r['order'] in orders]
    cal=[r for r in ired if partition(r)=='validation' and r['order'] in orders]
    for target_label,accept in [('3',lambda k:k==3),('4',lambda k:k==4),('5',lambda k:k==5),('6',lambda k:k==6),('7plus',lambda k:k>=7)]:
        target=[r for r in ired if partition(r)=='test' and accept(r['order'])]
        add(f'IRED-{label}-T{target_label}','IRED',source,cal,target,f'official train order {sorted(orders)}; calibration official validation same orders; target official test order {target_label}','source_additive_mutation_prior','Historically exposed family; target mutation orders absent in source-only calibration; no exact composition matching support.')
hydro=datasets['flip2_hydro_to_P06241.csv.gz'];backbones={'P06241':57,'P01053':63,'P0A9X9':65}
for s,sl in backbones.items():
    source_all=sorted([r for r in hydro if len(r['sequence'])==sl],key=lambda r:hashlib.sha256(r['sequence'].encode()).hexdigest())
    # Proposed custom source holdout, not an official FLIP2 partition.
    calibration=source_all[::5];source=[r for i,r in enumerate(source_all) if i%5]
    for t,tl in backbones.items():
        if s==t:continue
        target=[r for r in hydro if len(r['sequence'])==tl]
        add(f'HYDRO-{s}-{t}','Hydro',source,calibration,target,f'{s} -> {t}; custom SHA256-sorted source every fifth row reserved for calibration (proposal)','multisource_skill_prior (classical secondary stratum)','Historical development; cross-backbone aggregate descriptors, not aligned additive mutation tokens; custom split needs approval; source holdout is not original cross-backbone gate.')
assert len(routes)==21 and len({r['id'] for r in routes})==21
intersections=[]
for i,a in enumerate(routes):
    for c in routes[i+1:]:
        overlap=len(a['_target_ids']&c['_target_ids'])
        if overlap:intersections.append({'route_a':a['id'],'route_b':c['id'],'shared_target_sequences':overlap})
for r in routes:del r['_target_ids']
archive_inventory=[]
for p in sorted((ROOT/'artifacts/replay-results').glob('*trpb*.tar.gz')):
    with tarfile.open(p) as t:
        raw=[m.name for m in t.getmembers() if '/data/raw/' in m.name or '.csv.gz' in m.name]
        archive_inventory.append({'archive':p.name,'sha256':sha(p),'member_count':len(t.getmembers()),'raw_data_members':raw})
assert all(not a['raw_data_members'] for a in archive_inventory)
assert not (BASE/'data/raw/flip2_trpb_one_to_many.csv.gz').exists()
dump('data_inventory.json',inventory);dump('candidate_routes.json',routes);dump('target_overlap.json',intersections);dump('trpb_archive_inventory.json',archive_inventory)
header='| 路线 | 源拟合池 | 源校准池 | 目标池 | 用途 |\n|---|---:|---:|---:|---|\n'
(OUT/'CANDIDATE_ROUTES.md').write_text('# 实验三：21 条本地开发候选路线\n\n全部为候选，未冻结、未执行、未获正式新增验证资格。池大小不等于拟使用的观测预算。IRED 阶数相对源 train+validation 共识序列计算。Hydro 自定义校准拆分仅为待审方案。完整定义、哈希和限制见 candidate_routes.json。\n\n'+header+''.join(f"| {r['id']} | {r['source_fit_pool_n']} | {r['source_calibration_pool_n']} | {r['target_pool_n']} | 开发／回顾性 |\n" for r in routes)+'\nIRED 的三组源条件共享五个目标池；Hydro 的六条有向路线共享三个骨架目标池。合计仅两个数据集簇、八个不同目标池；不能把 21 条路线当作 21 个独立家族。\n')
after={str(p.relative_to(ROOT)):sha(p) for p in audit_paths}
assert before==after
validation={'status':'offline_inventory_complete_not_scientific_freeze','network_blocked':True,'model_api_calls':0,'new_downloads':0,'outcome_projection_checks':checks,'candidate_route_count':len(routes),'new_confirmatory_eligible_route_count':0,'development_dataset_clusters':2,'distinct_target_pools':len({r['target_pool_sha256'] for r in routes}),'within_route_overlap_checks_passed':21,'protected_input_file_count':len(before),'protected_input_hashes_unchanged':True}
dump('input_manifest.json',before);dump('validation.json',validation)
print(json.dumps(validation,ensure_ascii=False))
