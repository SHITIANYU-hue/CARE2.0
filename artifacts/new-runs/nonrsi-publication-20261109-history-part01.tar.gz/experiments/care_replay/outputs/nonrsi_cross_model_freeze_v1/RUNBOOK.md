# 冻结协议运行说明

WSL：Ubuntu-24.04。仓库：`/home/tangchao/projects/care2.0`。

只校验冻结，不读取 key，不调用 API：

```bash
cd /home/tangchao/projects/care2.0/experiments/care_replay
/home/tangchao/projects/care2.0/.venv/bin/python -B -m protocols.nonrsi_cross_model_v1 verify --lock outputs/nonrsi_cross_model_freeze_v1/FROZEN_PROTOCOL.json
```

当前没有本轮的 execution authorization 或新鲜 account/route attestation；不能启动 generate。将来单独获得执行授权后再创建绑定此冻结 SHA256 的授权记录，使用本轮独立 ledger/output 目录，不复用 BH/Suzuki 的旧授权或账本。

流程顺序为 generate → prepare → calibrate → heldout → analyze。除 generate 外，全程网络阻断；所有入口检查正式冻结，完整生成账本才能进入本地评估。默认 workers=1；增加并行度不改变科学预算。

执行器禁用重试与 HTTP 跳转；任一未结算尝试保留 $1 预留并停止。不要手改账本或冻结文件来绕过停止。停机后先核查证据；需要补发、换模型或改科学方案时由用户决定。
