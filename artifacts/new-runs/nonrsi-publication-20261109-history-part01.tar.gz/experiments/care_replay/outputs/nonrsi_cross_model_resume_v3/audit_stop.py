from pathlib import Path
import sys,collections,fcntl
from decimal import Decimal
from datetime import datetime,timezone
from protocols.nonrsi_cross_model_resume_v3 import runner as r
from protocols.nonrsi_cross_model_v1.common import *
p=BASE/'outputs/nonrsi_cross_model_resume_v3';j=p/'journal';science=j/'science_ledger'
with offline():
 config,lock=r.verify(p/'FROZEN_RETRY.json',p/'RETRY_AUTHORIZATION.json',p/'preflight/ATTESTATION.json')
 with (p/'generation.process.lock').open('a') as guard:
  fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
  rows=load(j/'ATTEMPTS.json')['attempts']; records=load(science/'ledger.json')['attempts'];order=slots(config)
  assert len(rows)==198 and len(records)==242
  assert rows[-1]['status']=='HALTED' and rows[-1]['error_evidence']['exception_type']=='URLError'
  assert rows[-1]['total_attempt_index']==247 and rows[-1]['logical_index']==242
  assert load(j/'0197.interruption.json')==rows[-1]['error_evidence']
  assert not r.qualifying(rows[-1]['slot'],rows[-1]['error_evidence'])
  assert not (j/'0197.response.json').exists() and not (j/'0197.response.txt').exists() and not (j/'0197.http.json').exists()
  journal=r.Journal(j,ROOT/lock['original_ledger'],config)
  try:journal.audit()
  except Halt as exc:
   assert str(exc)=='Unresolved or non-retryable attempt; stopped',str(exc)
  else:raise AssertionError('Halted attempt unexpectedly resumable')
  models={m['id']:m for m in config['models']};cats={};ids=set();fps={};counts={};costs={};reasoncounts={}
  for i,a in enumerate(records):
   assert a['slot']==order[i] and a['status'] in r.TERMINAL and not a['test_only']
   raw=load(science/f'{i:04d}.response.json');body=load(science/f'{i:04d}.request.json')
   assert digest(raw)==a['response_sha256'] and digest(body)==a['request_sha256'] and load(science/f'{i:04d}.response.txt')==raw
   prompt=load(BASE/'outputs/nonrsi_cross_model_preparation_v1/prompts'/(a['slot']['cell']+'.json'))
   assert body==r.request_contract.build(config,a['slot'],prompt)
   target=a['slot']['target'];model=a['slot']['model']
   if target not in cats:cats[target]=r.inputs.catalog(r.inputs.adapter(target))
   decision=r.generation.classify(raw,models[model],cats[target],'1')
   assert all(a[k]==v for k,v in decision.items())
   assert raw['id'] not in ids;ids.add(raw['id'])
   fp=raw.get('system_fingerprint');assert fp==a['fingerprint']
   if fp:
    assert model not in fps or fps[model]==fp
    fps[model]=fp
   counts.setdefault(model,collections.Counter())[a['status']]+=1
   costs[model]=costs.get(model,Decimal(0))+Decimal(a['cost_usd'])
   if a['reasons']:reasoncounts.setdefault(model,collections.Counter())[a['reasons'][0]]+=1
  known,holds=journal.totals(rows)
  assert known==Decimal('1.00369190') and holds==6
  assert sum(costs.values())==known
  report={'created_at_utc':datetime.now(timezone.utc).isoformat(),'state':'STOPPED_AWAITING_USER_DECISION','offline_only':True,'api_calls_for_audit':0,'freeze_chain_verified':True,'freeze_sha256':r.freeze.file_hash(p/'FROZEN_RETRY.json'),'process_lock_available':True,'total_http_attempts':248,'settled_logical_slots':242,'remaining_logical_slots':418,'statuses':dict(collections.Counter(x['status'] for x in records)),'by_model':{k:dict(v) for k,v in counts.items()},'known_cost_by_model_usd':{k:str(v) for k,v in costs.items()},'invalid_first_reason_counts':{k:dict(v) for k,v in reasoncounts.items()},'known_model_cost_usd':str(known),'unknown_charge_holds_usd':str(holds),'conservative_accounted_usd':str(known+holds),'replacement_attempts_used_in_v3':3,'replacement_attempts_remaining_in_v3':3,'failed_attempt':rows[-1],'failure_http_status_and_root_cause':'Not recorded; URLError alone cannot determine whether request reached provider or whether charged.','all_242_requests_raw_responses_classifications_costs_and_provenance_verified':True,'all_new_attempt_ordering_and_backoff_records_verified_until_expected_nonqualifying_stop':True,'no_response_or_http_envelope_for_failed_attempt':True,'calibration_started':False,'heldout_started':False,'generation_incomplete':True}
  assert not (p/'evaluation').exists()
  report['journal_file_hashes']={str(f.relative_to(j)):r.freeze.file_hash(f) for f in sorted(j.rglob('*')) if f.is_file() and not f.name.endswith('.lock')}
  save(p/'STOP_AUDIT.json',report)
  proposal={'state':'PROPOSED_NOT_AUTHORIZED_NOT_IMPLEMENTED','language':'zh-CN','request':'仅例外补发当前第248次请求一次，不普遍放开URLError自动重试。','failed_slot':rows[-1]['slot'],'failed_request_sha256':rows[-1]['request_sha256'],'preserve_settled_slots':242,'preserve_unknown_holds_usd':'6','max_total_http_calls':668,'max_model_spend_usd':'15','count_this_exception_within_existing_six_additional_replacements':True,'additional_replacements_already_used':3,'after_this_exception_total_used':4,'remaining_429_replacements_after_exception':2,'minimum_total_calls_if_all_remaining_succeed':666,'remaining_logical_slots_including_current':418,'scope':'当前补发使用完全相同请求，至少等待60秒；若当前补发发生任何异常，立即停止，不对该槽位再次自动补发。当前槽位结算后，未来其他槽位保留既有明确Qwen/Parasail共享池429有限退避，每槽位最多2次，总额剩余最多2次。其他异常仍停。','failed_charge_remains_unknown':True,'next_attempt_max_conservative_accounting_usd':str(known+holds+1),'scientific_settings_unchanged':True,'implementation_after_approval':['新增独立续跑适配器，不改旧账本及冻结文件','验证242条结果及所有历史失败/预留，绑定该具体失败请求','离线测试全局额度衔接、只允许当前一次例外、再次异常停止、未知费用及重复发送防护','单独冻结后重新核验路由和价格，再执行'],'alternative':'保持停止，不新增模型调用；当前只是未完成的生成批次，不进行正式校准/留出分析。'}
  save(p/'RESUME_TRANSPORT_PROPOSAL.json',proposal)
  print(__import__('json').dumps({k:v for k,v in report.items() if k not in ['journal_file_hashes','failed_attempt','invalid_first_reason_counts']},ensure_ascii=False,indent=2))
