"""Offline amendment checks using the preserved, already-billed first receipt.

Only fake transports are used. No credentials are loaded and original evidence
is read-only. Temporary audit/receipt files are isolated by pytest's tmp_path.
"""
from copy import deepcopy
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import socket
import sys
from unittest.mock import patch
import urllib.request

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import proposed_generation_runner as runner
import receipt_reuse as reuse

ORIGINAL = runner.ROOT / "experiments/care_replay/results/2026-10-20-bh-semantic-anonymization-v1-generation"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


@pytest.fixture(autouse=True)
def prohibit_network_and_credentials(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Network and credential access are forbidden in this offline test")
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr(socket.socket, "connect_ex", forbidden)
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(urllib.request, "urlopen", forbidden)
    monkeypatch.setattr(runner, "load_key", forbidden)


@pytest.fixture
def evidence():
    paths = {
        "request": ORIGINAL / "receipts/pair_00_labeled/request.json",
        "response": ORIGINAL / "receipts/pair_00_labeled/response.json",
        "lookup": ORIGINAL / "post_stop_generation_lookup.json",
        "reconciliation": ORIGINAL / "cost_reconciliation.json",
        "audit": ORIGINAL / "post_stop_audit.json",
        "failure": ORIGINAL / "failure.json",
        "ledger": ORIGINAL / "ledger.json",
    }
    return {name: {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            for name, path in paths.items()}


@pytest.fixture
def sequence():
    config = read(ORIGINAL / "config.json")
    result = []
    for slot in config["generation_order"]:
        identifier = f"pair_{slot['pair_index']:02d}_{slot['arm']}"
        messages = read(ORIGINAL / "input_snapshot/messages" / (identifier + ".json"))
        payload = {"model": config["model"]["id"], "messages": messages,
                   "temperature": config["model"]["temperature"],
                   "max_tokens": config["model"]["max_tokens"],
                   "response_format": {"type": "json_object"}, "stream": False,
                   "provider": config["api"]["provider"]}
        result.append({"identifier": identifier, "payload": payload})
    assert result[0]["payload"] == read(ORIGINAL / "receipts/pair_00_labeled/request.json")
    return result


class FakeTransport:
    def __init__(self, *, lookup=None, fail_post=False, lookup_404=False):
        self.calls = []
        self.lookup, self.fail_post, self.lookup_404 = lookup, fail_post, lookup_404

    def request(self, path, payload=None):
        self.calls.append((path, deepcopy(payload)))
        if path.startswith("/generation?id="):
            if self.lookup_404:
                raise runner.TransportError(404, "offline not-found fixture")
            if self.lookup is None:
                raise AssertionError("Unexpected billing lookup")
            return deepcopy(self.lookup)
        if path == "/models":
            return {"data": [read(ORIGINAL / "preflight.json")["catalog_model"]]}
        if path == "/key":
            return {"data": {"limit_remaining": None}}
        if path == "/chat/completions":
            if self.fail_post:
                raise runner.TransportError(503, "offline failure fixture")
            return {"id": "offline-fake-response", "usage": {"cost": 0, "is_byok": False}}
        raise AssertionError("Unexpected fake operation: " + path)

    @property
    def post_count(self):
        return sum(path == "/chat/completions" for path, _ in self.calls)


def test_direct_verified_usage_cost_needs_no_get(tmp_path, evidence):
    response = read(evidence["response"]["path"])
    transport = FakeTransport()
    cost = runner.response_cost(response, transport, tmp_path, sleep=lambda _: None)
    assert cost == Decimal("0.0012393")
    assert transport.calls == []
    record = read(tmp_path / "response_usage_billing.json")
    assert record["is_byok"] is False and record["generation_lookup_required"] is False


def test_unknown_response_byok_falls_back_to_original_get(tmp_path, evidence):
    response = read(evidence["response"]["path"])
    response["usage"].pop("is_byok")
    transport = FakeTransport(lookup=read(evidence["lookup"]["path"]))
    cost = runner.response_cost(response, transport, tmp_path, sleep=lambda _: None)
    assert cost == Decimal("0.0012393")
    assert len(transport.calls) == 1
    assert transport.calls[0][0].startswith("/generation?id=")
    assert transport.post_count == 0


def test_true_or_unresolved_byok_stops_without_generation(tmp_path, evidence):
    response = read(evidence["response"]["path"])
    response["usage"]["is_byok"] = True
    transport = FakeTransport()
    with pytest.raises(ValueError, match="BYOK"):
        runner.response_cost(response, transport, tmp_path, sleep=lambda _: None)
    assert transport.calls == []
    response["usage"].pop("is_byok")
    transport = FakeTransport(lookup_404=True)
    with pytest.raises(ValueError, match="unknown"):
        runner.response_cost(response, transport, tmp_path, sleep=lambda _: None)
    assert len(transport.calls) == 3 and transport.post_count == 0


def test_first_slot_returns_exact_saved_receipt_without_post(tmp_path, sequence, evidence):
    transport = FakeTransport()
    api = reuse.ReceiptReuseAPI(transport, sequence, evidence, tmp_path / "audit")
    response = api.request("/chat/completions", sequence[0]["payload"])
    assert response == read(evidence["response"]["path"])
    assert transport.calls == []
    assert api.reused_count == 1 and api.new_post_attempts == 0 and api.next_slot == 1
    response["id"] = "caller mutation"
    assert api.response["id"] != "caller mutation"
    report = read(tmp_path / "audit/receipt_reuse_accounting.json")
    assert report["cumulative_model_api_calls"] == 1
    assert report["previously_incurred_cost_usd"] == "0.0012393"
    assert report["old_cost_is_not_new_spend"] is True


def test_second_request_is_first_post_and_total_new_posts_cannot_exceed_19(tmp_path, sequence, evidence):
    transport = FakeTransport()
    api = reuse.ReceiptReuseAPI(transport, sequence, evidence, tmp_path / "audit")
    api.request("/chat/completions", sequence[0]["payload"])
    api.request("/chat/completions", sequence[1]["payload"])
    assert transport.post_count == api.new_post_attempts == 1
    for slot in sequence[2:]:
        api.request("/chat/completions", slot["payload"])
    assert transport.post_count == api.new_post_attempts == 19
    assert api.reused_count == 1 and api.next_slot == 20
    with pytest.raises(ValueError, match="already consumed"):
        api.request("/chat/completions", sequence[-1]["payload"])
    assert api.halted and transport.post_count == 19
    with pytest.raises(RuntimeError, match="halted"):
        api.request("/chat/completions", sequence[0]["payload"])
    report = read(tmp_path / "audit/receipt_reuse_accounting.json")
    assert report["cumulative_model_api_calls"] == 20


def test_payload_mismatch_rejects_without_post_and_permanently_halts(tmp_path, sequence, evidence):
    transport = FakeTransport()
    api = reuse.ReceiptReuseAPI(transport, sequence, evidence, tmp_path / "audit")
    mismatch = deepcopy(sequence[0]["payload"])
    mismatch["temperature"] = 0.46
    with pytest.raises(ValueError, match="differs from its frozen slot"):
        api.request("/chat/completions", mismatch)
    assert api.halted and api.next_slot == 0 and transport.calls == []
    with pytest.raises(RuntimeError, match="halted"):
        api.request("/chat/completions", sequence[0]["payload"])
    assert transport.calls == []


def test_transport_failure_is_one_attempt_and_never_retried(tmp_path, sequence, evidence):
    transport = FakeTransport(fail_post=True)
    api = reuse.ReceiptReuseAPI(transport, sequence, evidence, tmp_path / "audit")
    api.request("/chat/completions", sequence[0]["payload"])
    with pytest.raises(runner.TransportError):
        api.request("/chat/completions", sequence[1]["payload"])
    assert api.halted and api.new_post_attempts == transport.post_count == 1
    with pytest.raises(RuntimeError, match="halted"):
        api.request("/chat/completions", sequence[1]["payload"])
    assert transport.post_count == 1
    report = read(tmp_path / "audit/receipt_reuse_accounting.json")
    assert report["events"][-1]["outcome"] == "transport_failed_no_retry"
    assert report["cumulative_model_api_calls"] == 2


def test_runner_validation_failure_after_reuse_does_not_dispatch_second_slot(tmp_path, sequence, evidence):
    transport = FakeTransport()
    api = reuse.ReceiptReuseAPI(transport, sequence, evidence, tmp_path / "audit")
    config_path, lock_path = ORIGINAL / "config.json", ORIGINAL / "protocol_lock.json"
    config, lock = read(config_path), read(lock_path)
    freeze_dir = runner.ROOT / lock["freeze_directory"]
    # This test targets stop behavior, not source-inventory verification (covered
    # separately by the frozen runner tests); avoid copying all source files.
    execution_lock = deepcopy(lock)
    execution_lock["source_sha256"] = {}
    def reject_library(*args):
        raise ValueError("offline deliberate validation failure")
    output = tmp_path / "run"
    with patch.object(runner, "verify_freeze", return_value=(config, execution_lock)):
        with pytest.raises(RuntimeError, match="deliberate validation failure"):
            runner.execute(config_path, lock_path, freeze_dir, output, api=api, validator=reject_library)
    assert api.reused_count == 1 and api.next_slot == 1
    assert transport.post_count == 0
    assert [path for path, _ in transport.calls] == ["/models", "/key"]
    assert not (output / "completion.json").exists()
    assert list((output / "libraries").iterdir()) == []
    failure = read(output / "failure.json")
    assert failure["valid_library_count"] == 0 and failure["retry_performed"] is False
    assert failure["known_cost_usd"] == "0.0012393"
