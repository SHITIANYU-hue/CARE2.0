"""Review-only receipt reuse; no credential loading or API calls at import time."""
import argparse
from copy import deepcopy
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
import proposed_generation_runner as runner


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def request_bytes(payload):
    """Same serialization used for the frozen request.json receipt."""
    return (json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def read_pinned(spec):
    raw = Path(spec["path"]).read_bytes()
    if digest(raw) != spec["sha256"]:
        raise ValueError("Pinned amendment evidence changed")
    return json.loads(raw)


def money(value):
    if value is None or isinstance(value, bool):
        raise ValueError("Missing/invalid reconciled cost")
    value = Decimal(str(value))
    if not value.is_finite() or value < 0:
        raise ValueError("Invalid reconciled cost")
    return value


class ReceiptReuseAPI:
    """Reuse exactly slot zero; at most nineteen new POST attempts thereafter.

    Every payload must match its frozen slot, including all generation/routing
    parameters. A transport failure or payload mismatch permanently halts this
    instance. Later identical labeled prompts are fresh, prespecified draws:
    only slot zero uses a receipt. Never infer reuse from prompt similarity.
    """
    def __init__(self, transport, sequence, evidence, audit_dir):
        self.transport = transport
        self.sequence = deepcopy(sequence)
        self.audit_dir = Path(audit_dir)
        self.evidence = deepcopy(evidence)
        expected = {f"pair_{p:02d}_{a}" for p in range(10) for a in ("labeled", "anonymous")}
        if (len(sequence) != 20 or {s["identifier"] for s in sequence} != expected
                or sequence[0]["identifier"] != "pair_00_labeled"):
            raise ValueError("Receipt reuse requires the original twenty-slot order")
        old = {name: read_pinned(spec) for name, spec in evidence.items()}
        required = {"request", "response", "lookup", "reconciliation", "audit",
                    "failure", "ledger"}
        if set(old) != required:
            raise ValueError("Incomplete receipt-reuse evidence")
        response, lookup, reconciliation = old["response"], old["lookup"]["data"], old["reconciliation"]
        usage = response.get("usage", {})
        ids = (response.get("id"), lookup.get("id"), reconciliation.get("generation_id"))
        if not isinstance(ids[0], str) or not ids[0] or len(set(ids)) != 1:
            raise ValueError("Receipt/reconciliation generation IDs disagree")
        if not all(value is False for value in
                   (usage.get("is_byok"), lookup.get("is_byok"), reconciliation.get("is_byok"))):
            raise ValueError("Receipt reuse requires explicit non-BYOK evidence")
        costs = [money(value) for value in
                 (usage.get("cost"), lookup.get("total_cost"), reconciliation.get("actual_cost_usd"))]
        if len(set(costs)) != 1 or costs[0] > Decimal("0.045"):
            raise ValueError("Receipt costs disagree or exceed reservation")
        if reconciliation.get("metadata_sha256") != evidence["lookup"]["sha256"]:
            raise ValueError("Reconciliation does not pin the supplied metadata")
        if (reconciliation.get("model_api_calls_total") != 1
                or reconciliation.get("additional_model_requests_during_reconciliation") != 0
                or reconciliation.get("initial_failure_log_preserved") is not True
                or old["audit"].get("schema_valid") is not True
                or old["audit"].get("strategy_rule_counts") != [2, 1, 1, 1, 1]
                or old["failure"].get("model_api_calls") != 1
                or len(old["ledger"].get("attempts", [])) != 1):
            raise ValueError("Prior call count, failure preservation or validation evidence differs")
        previous = old["ledger"]["attempts"][0]
        if (previous.get("identifier") != "pair_00_labeled"
                or previous.get("request_sha256") != evidence["request"]["sha256"]
                or digest(request_bytes(sequence[0]["payload"])) != evidence["request"]["sha256"]
                or request_bytes(sequence[0]["payload"]) != request_bytes(old["request"])):
            raise ValueError("First frozen request does not exactly match prior receipt")
        if (response.get("model") != old["request"]["model"]
                or lookup.get("model") != old["request"]["model"]
                or response.get("provider") != "OpenAI"
                or lookup.get("provider_name") != "OpenAI"):
            raise ValueError("Reused response identity/routing differs")
        runner.extract_completion(response)  # Full semantic validator still runs in execute().
        self.response = response
        self.prior_cost = costs[0]
        self.next_slot = self.reused_count = self.new_post_attempts = 0
        self.halted = False
        self.events = []
        self.audit_dir.mkdir(parents=True, exist_ok=False)
        self.persist()

    @property
    def key(self):
        # For runner redaction only. Never load a key or serialize this property.
        return getattr(self.transport, "key", None)

    def persist(self, extra=None):
        report = {
            "prior_model_api_calls": 1, "new_model_post_attempts": self.new_post_attempts,
            "cumulative_model_api_calls": 1 + self.new_post_attempts,
            "reused_logical_slots": self.reused_count,
            "logical_slots_dispatched": self.next_slot,
            "previously_incurred_cost_usd": str(self.prior_cost),
            "old_cost_is_not_new_spend": True,
            "max_new_model_post_attempts": 19,
            "max_new_attempt_reservation_usd": "0.855",
            "previous_cost_plus_new_reservations_usd": str(self.prior_cost + Decimal(".855")),
            "halted": self.halted, "events": self.events,
            "evidence": self.evidence,
        }
        if extra:
            report.update(extra)
        runner.save(self.audit_dir / "receipt_reuse_accounting.json", report)

    def request(self, path, payload=None):
        if self.halted:
            raise RuntimeError("Receipt reuse transport is halted; no automatic retry")
        if path != "/chat/completions":
            if payload is not None or (path not in ("/models", "/key")
                                       and not path.startswith("/generation?id=")):
                raise ValueError("Unexpected amendment transport operation")
            return self.transport.request(path)
        if self.next_slot >= 20:
            self.halted = True
            self.persist()
            raise ValueError("All twenty logical slots are already consumed")
        slot = self.sequence[self.next_slot]
        if request_bytes(payload) != request_bytes(slot["payload"]):
            self.halted = True
            self.persist()
            raise ValueError("Request differs from its frozen slot; no POST performed")
        event = {"slot": self.next_slot, "identifier": slot["identifier"],
                 "request_sha256": digest(request_bytes(payload)), "started_at": runner.utc()}
        if self.next_slot == 0:
            # Verify immutable source receipts again immediately before reuse.
            for spec in self.evidence.values():
                read_pinned(spec)
            self.reused_count = 1
            self.next_slot += 1
            event.update(source="prior_verified_receipt", new_model_post=False,
                         response_id=self.response["id"], prior_cost_usd=str(self.prior_cost),
                         response_sha256=self.evidence["response"]["sha256"])
            self.events.append(event)
            self.persist()
            return deepcopy(self.response)
        if self.reused_count != 1 or self.new_post_attempts >= 19:
            raise ValueError("New POST limit exceeded or prior receipt not retained")
        self.new_post_attempts += 1
        self.next_slot += 1
        event.update(source="new_model_post", new_model_post=True,
                     new_post_attempt=self.new_post_attempts,
                     reservation_usd="0.045", outcome="reserved_before_post")
        self.events.append(event)
        self.persist()  # Separate actual-POST count is durable before forwarding.
        try:
            result = self.transport.request(path, payload)
        except BaseException:
            self.halted = True
            event["outcome"] = "transport_failed_no_retry"
            self.persist()
            raise
        event.update(outcome="response_received", response_id=result.get("id"))
        self.persist()
        return result


def prepare_plan(plan_path, expected_plan_sha256):
    """Read-only hash and scientific-protocol validation; never loads credentials."""
    plan_path = Path(plan_path)
    plan = read_pinned({"path": str(plan_path), "sha256": expected_plan_sha256})
    root = runner.ROOT
    if plan.get("status") != "pending_user_approval":
        raise ValueError("Unexpected amendment plan status")
    for relative, expected in plan["artifact_sha256"].items():
        if runner.file_hash(plan_path.parent / relative) != expected:
            raise ValueError("Reviewed runtime amendment artifact changed")
    source = plan["original"]
    config_path, lock_path = root / source["config_path"], root / source["protocol_lock_path"]
    if (runner.file_hash(config_path) != source["config_sha256"]
            or runner.file_hash(lock_path) != source["protocol_lock_sha256"]):
        raise ValueError("Original scientific protocol changed")
    freeze_dir = root / source["freeze_dir"]
    config, lock = runner.verify_freeze(config_path, lock_path, freeze_dir)
    expected_runner = root / source["runner_path"]
    if runner.file_hash(expected_runner) != source["runner_sha256"]:
        raise ValueError("Frozen original runner changed")
    sequence = []
    for slot in config["generation_order"]:
        identifier = f"pair_{slot['pair_index']:02d}_{slot['arm']}"
        messages = read_pinned({
            "path": str(freeze_dir / "messages" / f"{identifier}.json"),
            "sha256": lock["messages_sha256"][identifier],
        })
        payload = {"model": config["model"]["id"], "messages": messages,
                   "temperature": config["model"]["temperature"],
                   "max_tokens": config["model"]["max_tokens"],
                   "response_format": {"type": "json_object"}, "stream": False,
                   "provider": config["api"]["provider"]}
        sequence.append({"identifier": identifier, "payload": payload})
    evidence = {name: {"path": str(root / spec["path"]), "sha256": spec["sha256"]}
                for name, spec in plan["reuse_evidence"].items()}
    return plan, config_path, lock_path, freeze_dir, sequence, evidence


def verify_plan(plan_path, expected_plan_sha256):
    prepared = prepare_plan(plan_path, expected_plan_sha256)
    with tempfile.TemporaryDirectory(prefix="care2-amendment-verify-") as temporary:
        ReceiptReuseAPI(None, prepared[4], prepared[5], Path(temporary) / "audit")
    return prepared[0]


def check_output(plan, output):
    output = Path(output)
    if output.resolve() != (runner.ROOT / plan["proposed_output"]).resolve():
        raise ValueError("Output differs from the unique approved amendment destination")
    if output.exists() or output.with_name(output.name + ".runtime_amendment").exists():
        raise ValueError("Amendment output exists; never auto-resume or repeat")


def run_amended(plan_path, expected_plan_sha256, output, transport, *,
                approved=False, approval_reference=None, validator=None):
    """Execute only after an explicit decision; preserve the original failed run."""
    if approved is not True or not approval_reference:
        raise ValueError("Explicit user decision on this runtime amendment is required")
    plan_path, output = Path(plan_path), Path(output)
    plan, config_path, lock_path, freeze_dir, sequence, evidence = prepare_plan(
        plan_path, expected_plan_sha256)
    source = plan["original"]
    check_output(plan, output)
    sidecar = output.with_name(output.name + ".runtime_amendment")
    if output.exists() or sidecar.exists():
        raise ValueError("Amendment output exists; never auto-resume or repeat")
    api = ReceiptReuseAPI(transport, sequence, evidence, sidecar)
    snapshots = sidecar / "actual_runtime_source_snapshot"
    snapshots.mkdir()
    for relative, expected in plan["artifact_sha256"].items():
        destination = snapshots / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(plan_path.parent / relative, destination)
        if runner.file_hash(destination) != expected:
            raise ValueError("Runtime artifact changed during snapshot")
    shutil.copyfile(plan_path, sidecar / "approved_amendment_plan.json")
    if runner.file_hash(sidecar / "approved_amendment_plan.json") != expected_plan_sha256:
        raise ValueError("Approved amendment plan changed during snapshot")
    runtime = {
        "amendment_plan_sha256": expected_plan_sha256,
        "approval_reference": approval_reference,
        "actual_runner_sha256": runner.file_hash(Path(runner.__file__)),
        "actual_transport_wrapper_sha256": runner.file_hash(Path(__file__)),
        "original_runner_sha256": source["runner_sha256"],
        "original_protocol_lock_sha256": source["protocol_lock_sha256"],
        "scientific_design_changed": False, "original_failure_preserved": True,
        "original_source_snapshot_is_baseline_not_actual_amended_runner": True,
    }
    if runtime["actual_runner_sha256"] != plan["artifact_sha256"]["proposed_generation_runner.py"]:
        raise ValueError("Imported runtime does not match reviewed proposed runner")
    if runtime["actual_transport_wrapper_sha256"] != plan["artifact_sha256"]["receipt_reuse.py"]:
        raise ValueError("Imported wrapper does not match reviewed receipt reuse code")
    runner.save(sidecar / "runtime_provenance.json", runtime, exclusive=True)
    try:
        result = runner.execute(config_path, lock_path, freeze_dir, output,
                                api=api, validator=validator)
        result["runtime_amendment"] = {
            **runtime, "sidecar_path": str(sidecar),
            "prior_model_api_calls": 1,
            "new_model_post_attempts": api.new_post_attempts,
            "cumulative_model_api_calls": 1 + api.new_post_attempts,
            "reused_logical_slots": api.reused_count,
            "archive_both_output_and_sidecar": True,
        }
        runner.save(output / "completion.json", result)
        return result
    finally:
        api.halted = True
        accounting = {"runtime_provenance": runtime}
        if (output / "ledger.json").exists():
            known = money(json.loads((output / "ledger.json").read_text())["known_cost_usd"])
            accounting["run_ledger_cumulative_known_cost_usd"] = str(known)
            accounting["newly_accounted_cost_usd"] = str(max(Decimal(0), known - api.prior_cost))
        api.persist(accounting)
        if output.exists():
            runner.save(output / "runtime_amendment.json", {
                **runtime, "sidecar_path": str(sidecar),
                "accounting_path": str(sidecar / "receipt_reuse_accounting.json"),
                "prior_model_api_calls": 1,
                "new_model_post_attempts": api.new_post_attempts,
                "cumulative_model_api_calls": 1 + api.new_post_attempts,
                "archive_both_output_and_sidecar": True,
            })


def main():
    parser = argparse.ArgumentParser(description="Verify a proposed amendment; execution requires explicit approval.")
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha256", required=True)
    parser.add_argument("--execute-approved", action="store_true")
    parser.add_argument("--approval-reference")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    plan = verify_plan(args.plan, args.plan_sha256)
    if not args.execute_approved:
        print(json.dumps({"status": "verified_without_api", "plan_sha256": args.plan_sha256,
                          "prior_model_api_calls": 1, "max_new_model_post_attempts": 19,
                          "credentials_read": False, "api_calls": 0}))
        return
    if not args.approval_reference or args.output is None:
        parser.error("--execute-approved requires --approval-reference and --output")
    check_output(plan, args.output)
    transport = runner.OpenRouter(runner.load_key(runner.ROOT / ".env"), 120)
    result = run_amended(args.plan, args.plan_sha256, args.output, transport,
                         approved=True, approval_reference=args.approval_reference)
    print(json.dumps({"status": result["status"], "model_api_calls": result["model_api_calls"],
                      "known_cost_usd": result["known_cost_usd"]}))


if __name__ == "__main__":
    main()
