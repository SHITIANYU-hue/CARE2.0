"""Read-only audit of completed supplemental artifacts; no simulations or API calls."""
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from protocols.nonrsi_fence_supplement_v1.runner import OUT, EVAL, source_audit, original, unwrap, text_sha
from protocols.nonrsi_cross_model_v1 import freeze, generation, inputs, pipeline
from protocols.nonrsi_cross_model_v1.common import load, digest, offline, save

with offline():
    status = load(OUT / 'PIPELINE_STATUS.json')
    assert status['state'] == 'complete' and status['exit_code'] == 0, status
    final = load(OUT / 'FINAL_ARTIFACTS.json')
    assert len(final) == 6
    for name, expected in final.items():
        assert freeze.file_hash(EVAL / name) == expected, name
    config, source, ledger = source_audit()
    derived = load(OUT / 'DERIVED_GENERATION.json')
    assert len(source) == len(derived['attempts']) == len(derived['provenance']) == 660
    assert derived['source_attempts_sha256'] == digest(source)
    assert derived['new_model_requests'] == 0
    models = {m['id']: m for m in config['models']}
    counts = {m: Counter() for m in models}
    for i, (old, new, provenance) in enumerate(zip(source, derived['attempts'], derived['provenance'])):
        path = ledger / f'{i:04d}.response.json'
        response = load(path)
        content = response['choices'][0]['message']['content']
        body, applied = unwrap(content)
        modified = deepcopy(response)
        modified['choices'][0]['message']['content'] = body
        decision = generation.classify(modified, models[old['slot']['model']],
            inputs.catalog(inputs.adapter(old['slot']['target'])), old['reservation_usd'])
        expected = deepcopy(old); expected.update(decision)
        assert new == expected, i
        assert provenance['index'] == i and provenance['slot_id'] == old['slot']['slot_id']
        assert provenance['model'] == old['slot']['model']
        assert provenance['source_response_sha256'] == old['response_sha256']
        assert provenance['source_response_file_sha256'] == freeze.file_hash(path)
        assert provenance['source_content_sha256'] == text_sha(content)
        assert provenance['derived_content_sha256'] == text_sha(body)
        assert provenance['outer_fence_removed'] == applied
        assert provenance['original_status'] == old['status']
        assert provenance['supplemental_status'] == decision['status']
        assert provenance['supplemental_reasons'] == decision['reasons']
        if applied:
            assert (OUT / provenance['derived_content_path']).read_bytes().decode('utf-8') == body
        if old['status'] == generation.VALID:
            assert not applied and new == old
        c = counts[old['slot']['model']]
        c['slots'] += 1; c[decision['status']] += 1
        c['outer_fences_removed'] += int(applied)
        c['newly_valid'] += int(old['status'] != generation.VALID and decision['status'] == generation.VALID)
    assert {m:dict(c) for m,c in counts.items()} == derived['counts']
    definition = load(EVAL / 'definition.json')
    assert definition['generation_sha256'] == digest(derived['attempts'])
    lock = load(EVAL / 'CALIBRATION_LOCK.json')
    held = load(EVAL / 'HELDOUT_COMPLETE.json')
    assert lock['config_sha256'] == held['config_sha256'] == digest(config)
    assert lock['definition_sha256'] == held['definition_sha256'] == digest(definition)
    assert held['calibration_lock_sha256'] == digest(lock)
    assert len(lock['checkpoints']) == 300
    for name, expected in lock['checkpoints'].items():
        assert digest(load(EVAL/name)) == expected, name
    checkpoint_counts = {}; reused_rows = 0; baseline_checks = 0
    for target in definition['targets']:
        checkpoint_counts[target] = {}
        assert load(EVAL/target/'selection.json') == lock['selections'][target]
        for split, expected in [('calibration',50),('heldout',100)]:
            paths = sorted((EVAL/target/split).glob('*.json'))
            assert {int(p.stem) for p in paths} == set(pipeline.seed_set(config,target,split))
            assert len(paths) == expected
            checkpoint_counts[target][split] = len(paths)
            for path in paths:
                row = load(path)
                oldpath = original.OUTPUT/target/split/path.name
                old = load(oldpath)
                assert row['source_checkpoint_sha256'] == freeze.file_hash(oldpath)
                assert row['source_binding'] == old['binding']
                assert row['rows_sha256'] == digest(row['rows'])
                old_modes = {r['mode']:r for r in old['rows']}
                new_modes = {r['mode']:r for r in row['rows']}
                assert old_modes.keys() <= new_modes.keys()
                assert all(new_modes[k] == v for k,v in old_modes.items())
                assert row['reused_modes'] == len(old_modes)
                assert row['new_modes'] == len(new_modes)-len(old_modes)
                assert row['baseline_consistency_checked'] == bool(row['new_modes'])
                reused_rows += len(old_modes); baseline_checks += int(row['baseline_consistency_checked'])
                assert path.with_suffix('.traces.json.gz').is_file()
        assert held['metrics'][target] == digest(load(EVAL/target/'heldout_metrics.json'))
    analysis = load(EVAL/'analysis.json'); before = load(original.OUTPUT/'analysis.json')
    assert len(analysis['primary']) == 36
    assert analysis['draws_sha256'] == before['draws_sha256']
    unchanged = {m for m,c in derived['counts'].items() if c['newly_valid'] == 0}
    for section in ['primary','secondary','random_controls']:
        select = lambda rows: [r for r in rows if all(m in unchanged for m in r['model'].split(' minus '))]
        assert select(analysis[section]) == select(before[section]), section
    for key,value in before['cells'].items():
        if any(key.startswith(m+'__') for m in unchanged):
            assert analysis['cells'][key] == value, key
    accounting = load(OUT/'SUPPLEMENT_ACCOUNTING.json')
    assert accounting['new_model_requests'] == 0 and accounting['new_model_cost_usd'] == '0'
    assert accounting['historical_accounting'] == load(OUT/'SOURCE_AUDIT.json')
    assert accounting['report_sha256'] == freeze.file_hash(EVAL/'SUPPLEMENT_REPORT.txt')
    assert accounting['analysis_sha256'] == freeze.file_hash(EVAL/'analysis.json')
    assert set(accounting['unchanged_model_primary_results_verified']) == unchanged
    capsule = load(OUT/'SUPPLEMENT_PROTOCOL.json')
    original.verify_hashes(capsule['preserved_original_files'])
    original.verify_hashes(capsule['code_files'])
    review = {'completed_review_utc':datetime.now(timezone.utc).isoformat(),
        'scientific_slots_independently_reclassified':660,'derived_counts':derived['counts'],
        'original_files_hash_verified':len(capsule['preserved_original_files']),
        'final_artifacts_hash_verified':len(final),'checkpoint_counts':checkpoint_counts,
        'original_metric_rows_reused_exactly':reused_rows,
        'new_mode_checkpoints_with_matching_baseline':baseline_checks,
        'unchanged_models_all_cells_primary_secondary_random_controls_verified':sorted(unchanged),
        'new_model_requests':0,'new_model_cost_usd':'0','original_results_preserved':True}
    assert not (OUT/'FINAL_REVIEW.json').exists()
    save(OUT/'FINAL_REVIEW.json',review)
    print(review,flush=True)
